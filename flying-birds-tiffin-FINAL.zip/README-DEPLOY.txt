╔══════════════════════════════════════════════════════════════╗
║        FLYING BIRDS TIFFIN — FINAL PACKAGE (v6)               ║
║        Deploy Guide + Launch Checklist                        ║
╚══════════════════════════════════════════════════════════════╝

Is zip me 3 folder hain:
  📁 website/   → Netlify pe daalne wali files (frontend)
  📁 backend/   → Google Apps Script me paste karne wali file
  📁 mockup/    → Demo (dikhane ke liye, deploy nahi karna)


═══════════════════════════════════════════════════════════════
STEP 1 — BACKEND (Google Apps Script)
═══════════════════════════════════════════════════════════════
1. backend/apps-script-v6.js poora copy karo
2. Apps Script editor kholo → purana code hata ke ye paste karo → Save
3. Deploy → Manage deployments → pencil ✏️ → "New version" → Deploy
   ⚠️ "New deployment" MAT dabao — hamesha "New version"
   (warna backend URL badal jayega aur site toot jayegi)


═══════════════════════════════════════════════════════════════
STEP 2 — FRONTEND (Netlify)
═══════════════════════════════════════════════════════════════
1. website/ folder KHOLO (index.html, styles.css, app.js, _headers, images/)
2. Netlify pe jao → POORA website FOLDER drag-and-drop karo
   ⚠️ Sirf ek file nahi — poora folder (images bhi jaani chahiye)
3. Phone/laptop pe site kholo → HARD REFRESH (Ctrl+Shift+R ya pull-to-refresh)


═══════════════════════════════════════════════════════════════
STEP 3 — EK-BAAR KE SETUP (launch se pehle, ~20 min)
═══════════════════════════════════════════════════════════════
Apps Script editor me:
  □ ADMIN_PASS badlo (line ~17)  — 'CHANGE_THIS_PASSWORD_123' hata ke apna
  □ PEPPER badlo    (security ke liye) — 'CHANGE-THIS-RANDOM-STRING...' hata ke koi random
  □ sendTestEmail function → Run → Google "Allow" (warna reset-email nahi jayenge)
  □ uploadImage function → Run → Allow (image upload ke liye Drive permission)

App ke Admin panel me:
  □ Setup → UPI ID daalo (abhi 9924937939@ybl hai)
  □ Setup → FSSAI number daalo
  □ Setup → Telegram bot token + chat ID (naye-order alert ke liye)
  □ Setup → Delivery modes ON/OFF (Home/Office)
  □ Variants → asli food photos upload karo (abhi lunch/dinner me placeholder thali hai)
  □ Menu → poore hafte ka menu bharo


═══════════════════════════════════════════════════════════════
✅ FEATURES (is version me kya-kya hai)
═══════════════════════════════════════════════════════════════
CUSTOMER:
  • Pre-login landing page (menu dekhne se pehle hook + comparison)
  • Google + email login, password reset
  • 4 languages (English / Hinglish / हिन्दी / ગુજરાતી)
  • Home/Office delivery chooser (order se pehle poochta hai)
  • Teeno meal (Breakfast/Lunch/Dinner), Full/Mini size, 1-tap ADD
  • 1 meal = 1 order (alag cancel/track), delivery fee once/day
  • Coupon/promo system, UPI QR + COD payment
  • 3-tap fast reorder, subscription
  • Refresh pe cart+coupon+page yaad rehta hai

ADMIN:
  • Order dashboard, location/company filter, bulk status update
  • New-order ringtone alert, Telegram/email notify
  • Menu editor, variants, promos, delivery-mode config
  • Image upload (max 5MB in, ~1MB stored — auto compress)

SECURITY:
  • Duplicate-order block, ownership check, race protection
  • Formula-injection guard, XSS escape, admin brute-force lockout
  • Server-side price/coupon (frontend ka total trust nahi)


═══════════════════════════════════════════════════════════════
⚠️ ZAROORI — MANUAL SHEET ROWS
═══════════════════════════════════════════════════════════════
Orders sheet me row kabhi HAATH se delete/sort MAT karo.
Order cancel karna ho to app ke andar se karo. Row-based actions
toot jaate hain agar rows manually badle jayein.


═══════════════════════════════════════════════════════════════
KEY IDs (reference)
═══════════════════════════════════════════════════════════════
Site       : https://flying-birds-nest.netlify.app
Sheet ID   : 1T6tTy_I-C8VH8JKOsB8wyUW7h1NgbPmy0eFjCrmMGPo
Admin user : raj
Owner WA   : 919924937939

Deploy dono? → Backend badla ho tabhi backend deploy karo.
              Sirf frontend change ho to sirf website/ Netlify pe daalo.
