  // ═══════ CONFIG ═══════
  const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwdMXlSwNdqO84OspsUe2jAEeDL-hbwjwLcKL-fo6YObB6Se-dvTxX2iS5BMz2t8bV6/exec';
  const OWNER_WHATSAPP = '919924937939';
  // Google Cloud Console → APIs & Services → Credentials → OAuth Client ID (Web application)
  // → Authorized JavaScript origins me apna Netlify domain add karo → yahan paste karo.
  // ⚠️ Backend (apps-script) mein GOOGLE_CLIENT_ID bhi EXACTLY yehi hona chahiye.
  const GOOGLE_CLIENT_ID = '326762302482-d6c9l5k804u0oavcrrrqik7cadsvdneq.apps.googleusercontent.com';

  // Dynamic config (admin editable, synced from backend)
  function defaultVariantsFE(){
    const mk=(id,name,price,items)=>({id:id,name:name,price:price,items:items,img:''});
    const ld=[ mk('mini','Mini Tiffin',60,['🫓 Roti (4)','🍛 1 Sabzi','🥗 Salad']),
               mk('full','Full Tiffin',80,['🫓 Roti (5)','🍛 1 Sabzi','🍲 Daal','🍚 Chawal','🥛 Chaas','🥒 Achar','🥗 Salad','🍬 Sweet']) ];
    return { breakfast:[mk('std','Breakfast',80,['🍚 Poha / Paratha (daily varies)','🍵 Chai'])],
             lunch:JSON.parse(JSON.stringify(ld)), dinner:JSON.parse(JSON.stringify(ld)) };
  }
  let CFG = {
    prices: { breakfast:30, lunch:80, dinner:80, tiffinMini:60, extraRotiPlain:12, extraRotiButter:16, dahi:20, extraSabzi:30 },
    deliveryNear:10, deliveryFar:20, farSocieties:[],
    township: 'Godrej Garden City',
    societies: ['Vrindavan','Eden'],
    closedDates: [], capacity: { breakfast:0, lunch:0, dinner:0 },
    variants: defaultVariantsFE(),
    banners: { breakfast:'', lunch:'', dinner:'' },
    upiId: '', upiName: 'Flying Birds Tiffin', fssai: ''
  };
  // Variant helpers
  function variantsFor(m){ return (CFG.variants&&CFG.variants[m]&&CFG.variants[m].length)?CFG.variants[m]:defaultVariantsFE()[m]; }
  function findVariant(m,id){ const vs=variantsFor(m); return vs.find(v=>v.id===id)||vs[0]; }
  function priceRange(m){ const vs=variantsFor(m); const ps=vs.map(v=>v.price); return {min:Math.min(...ps),max:Math.max(...ps)}; }

  let MENU = {
    monday:    { breakfast:['🍚 Poha','🫓 Paratha (2)','🥣 Curd','🍵 Chai'], lunch:{sabziOptions:['Paneer Butter Masala','Dal Tadka','Mix Veg'],fixedItems:['🍚 Jeera Rice','🫓 Roti (4)','🥗 Salad','🥣 Dal Fry']}, dinner:{sabziOptions:['Aloo Gobi','Rajma Masala','Chole'],fixedItems:['🍚 Steam Rice','🫓 Roti (4)','🥒 Raita','🥗 Salad']} },
    tuesday:   { breakfast:['🥣 Upma','🫓 Paratha (2)','🍯 Chutney','🍵 Chai'], lunch:{sabziOptions:['Dal Makhani','Shahi Paneer','Mix Veg'],fixedItems:['🍚 Peas Pulao','🫓 Roti (4)','🥗 Salad','🧈 Papad']}, dinner:{sabziOptions:['Rajma Masala','Aloo Matar','Paneer Tikka Masala'],fixedItems:['🍚 Rice','🫓 Roti (4)','🥗 Onion Salad','🍋 Lemon']} },
    wednesday: { breakfast:['🍘 Idli (2)','🥣 Sambar','🌶️ Chutney','🍵 Chai'], lunch:{sabziOptions:['Mix Veg','Paneer Butter Masala','Dal Fry'],fixedItems:['🍚 Veg Biryani','🫓 Roti (4)','🥗 Salad','🥣 Dal']}, dinner:{sabziOptions:['Chole','Aloo Gobi','Rajma Masala'],fixedItems:['🍚 Rice','🫓 Roti (2)','🥒 Raita','🥗 Salad']} },
    thursday:  { breakfast:['🫓 Aloo Paratha','🥣 Curd','🍯 Pickle','🍵 Chai'], lunch:{sabziOptions:['Aloo Gobi','Paneer Tikka Masala','Dal Tadka'],fixedItems:['🍚 Jeera Rice','🫓 Roti (4)','🥗 Salad','🥣 Dal Tadka']}, dinner:{sabziOptions:['Paneer Tikka Masala','Mix Veg','Dal Fry'],fixedItems:['🍚 Steam Rice','🫓 Roti (4)','🥗 Green Salad','🥒 Raita']} },
    friday:    { breakfast:['🍚 Sabudana Khichdi','🫓 Paratha (2)','🥣 Curd','🍵 Chai'], lunch:{sabziOptions:['Rajma Masala','Shahi Paneer','Mix Veg'],fixedItems:['🍚 Rice','🫓 Roti (4)','🥗 Salad','🧈 Papad']}, dinner:{sabziOptions:['Dal Makhani','Aloo Matar','Chole'],fixedItems:['🍚 Peas Pulao','🫓 Roti (4)','🥒 Raita','🥗 Salad']} },
    saturday:  { breakfast:['🥣 Dosa','🥣 Sambar','🌶️ Chutney','🍵 Chai'], lunch:{sabziOptions:['Chole','Paneer Butter Masala','Dal Tadka'],fixedItems:['🍚 Rice','🫓 Roti (2)','🥗 Salad','🥒 Raita']}, dinner:{sabziOptions:['Paneer Butter Masala','Rajma Masala','Mix Veg'],fixedItems:['🍚 Veg Biryani','🫓 Roti (2)','🥒 Raita','🥗 Salad']} },
    sunday:    { breakfast:['🫓 Paneer Paratha','🥣 Curd','🍯 Pickle','🍵 Chai'], lunch:{sabziOptions:['Dal Makhani','Shahi Paneer','Chole'],fixedItems:['🍚 Veg Pulao','🫓 Naan (2)','🥗 Salad','🍮 Gulab Jamun (1)']}, dinner:{sabziOptions:['Rajma Masala','Paneer Tikka Masala','Aloo Gobi'],fixedItems:['🍚 Steam Rice','🫓 Roti (4)','🥗 Onion Salad','🥒 Raita']} }
  };

  // ═══════ i18n ═══════
  const LANGS = { en:'English', hinglish:'Hinglish', hi:'हिन्दी', gu:'ગુજરાતી' };
  const T = {
    en: {
      errNetwork:'❌ Network error. Please check your connection and try again.', sessionExpired:'⚠️ Your session has expired — please sign in again.', completeFields:'⚠️ Please complete all required fields.', orderFailed:'❌ Your order could not be placed. Please try again.', selectDate:'⚠️ Please select a date first.', orderCancelled:'✅ Your order has been cancelled.', resetLinkBad:'❌ This reset link is invalid or has expired.', confirmCancel:'Cancel this order?', welcomeUser:'🎉 Welcome,', errLogin:'Please sign in to continue.',
      tagline:'Fresh • Homemade • Doorstep Delivery', secureLogin:'🔐 Secure Login', signInTitle:'Welcome Back', emailLabel:'Email', passwordLabel:'Password', passwordPh:'Apna password daalein', passwordPh6:'Kam se kam 6 characters', confirmPwLabel:'Password Confirm Karein', confirmPwPh:'Password dobara daalein', errEmail:'Valid email address daalein.', errPassword:'Apna password daalein.', errPassword6:'Password kam se kam 6 characters ka ho.', errConfirmPw:'Password match nahi ho raha.', forgotPw:'Password Bhool Gaye?', signInBtn:'Sign In', signUpTitle:'Account Banayein', signUpSub:'Roz ka tiffin order karne ke liye sign up karein.', phoneDeliveryHint:'Delivery contact ke liye use hoga.', createAccountBtn:'Account Banayein', switchToSignUp:'Account nahi hai? <b onclick="showAuthMode(\'signup\')">Sign Up</b>', switchToSignIn:'Pehle se account hai? <b onclick="showAuthMode(\'signin\')">Sign In</b>', backToSignIn:'← Sign In par wapas', forgotTitle:'Password Reset Karein', forgotSub:'Apna email daalein, hum reset link bhej denge.', sendResetBtn:'Reset Link Bhejein', resetTitle:'Naya Password Set Karein', resetSub:'Apne account ke liye naya password chunein.', newPasswordLabel:'Naya Password', resetBtn:'Password Reset Karein', orDivider:'ya', resetLinkSent:'Agar ye email registered hai, reset link bhej diya gaya hai.', passwordResetDone:'Password update ho gaya — ab sign in kar sakte hain.', signInTitle:'Welcome Back', emailLabel:'Email', passwordLabel:'Password', passwordPh:'Enter your password', passwordPh6:'At least 6 characters', confirmPwLabel:'Confirm Password', confirmPwPh:'Re-enter your password', errEmail:'Please enter a valid email address.', errPassword:'Please enter your password.', errPassword6:'Password must be at least 6 characters.', errConfirmPw:'Passwords do not match.', forgotPw:'Forgot Password?', signInBtn:'Sign In', signUpTitle:'Create an Account', signUpSub:'Sign up to start ordering your daily tiffin.', phoneDeliveryHint:'Used for delivery contact.', createAccountBtn:'Create Account', switchToSignUp:'Don\'t have an account? <b onclick="showAuthMode(\'signup\')">Sign Up</b>', switchToSignIn:'Already have an account? <b onclick="showAuthMode(\'signin\')">Sign In</b>', backToSignIn:'← Back to Sign In', forgotTitle:'Reset Password', forgotSub:'Enter your email and we will send you a reset link.', sendResetBtn:'Send Reset Link', resetTitle:'Set New Password', resetSub:'Choose a new password for your account.', newPasswordLabel:'New Password', resetBtn:'Reset Password', orDivider:'or', resetLinkSent:'If that email is registered, a reset link has been sent.', passwordResetDone:'Password updated — you can sign in now.',
      loginTitle:'Login or Sign Up', mobileLabel:'Mobile Number', mobilePh:'Enter 10-digit mobile number',
      continueBtn2:'Continue', loginHint:'Choose from your Google accounts.', phoneFirstHint:'Needed only the first time — for delivery contact.', completeSignup:'✓ Complete Sign Up',
      verifyTitle:'One Last Step', googleWelcome:'✅ Signed in with Google. Add your mobile number for delivery contact.', nameLabel:'Your Name', namePh:'Enter your full name',
      otpLabel:'Enter Verification Code', verifyBtn:'Verify & Continue', changeNum:'Use a different Google account', errName:'Please enter a valid name (letters only).', errPhone:'Please enter a valid 10-digit mobile number.', errPickGoogle:'Please tap the Google button to pick an account first.',
      badgeFresh:'🌿 No Frozen Food', badgeCustom:'🍳 Customizable', badgeCOD:'💵 Cash on Delivery',
      freshStrip:'🌿 Freshly Prepared: Your meal is cooked only after you order — never frozen, never stale.',
      deliveryDate:'📅 Delivery Date',
      cutoffNote:'🕒 Order Cut-off Times (IST)\n• Breakfast — order by 10:00 PM the night before\n• Lunch — order by 9:00 AM same day\n• Dinner — order by 3:00 PM same day\nAfter cut-off, order for the next available day.',
      selectMeals:'🍽️ Select Your Meals', yourCart:'🛒 Your Cart', clearCart:'Clear', cartEmpty:'Your cart is empty. Add meals above to get started.',
      myOrders:'📋 My Orders', refresh:'🔄 Refresh', viewPast:'🗓️ View orders from a previous date', view:'View',
      cartTotal:'CART TOTAL', checkout:'Checkout →', viewCart:'View Cart →', logout:'Logout',
      checkoutTitle:'📦 Delivery Details', checkoutSub:'Final step — confirm your order', backMenu:'← Back to Menu',
      autofillNote:'✓ Your saved address has been auto-filled', township:'🏢 Township', society:'🏘️ Society', flat:'🏠 Flat Number',
      fullName:'👤 Full Name', verifiedMobile:'📱 Mobile Number (verified ✓)', payMethod:'💰 Payment Method',
      payCOD:'💵 Cash on Delivery', payCODsub:'Pay cash when you receive your tiffin', payUPI:'💳 Pay Online (UPI)', payUPIsub:'QR code appears right after you place the order', codNote:'Cash on Delivery — please pay when your tiffin arrives.',
      errSociety:'Please select your society.', errFlat:'Please enter your block and flat number, e.g. D-706.',
      placeOrder:'📤 Place Order', successTitle:'Order Confirmed', promoHave:'Have a coupon? Enter code', promoApply:'Apply', promoApplied:'applied', discountLbl:'Discount', promoFirstDateNote:'(applies to the first delivery date)', promoEditNote:'Discounted orders cannot be edited — please cancel and place a new order.', promoUseAtCheckout:'Tap a code in your cart to apply', promoNewTag:'new customers', policyTitle:'Cancellation & Refund Policy', policyBody:'• Orders can be cancelled until 10:00 PM on the night before delivery. Orders placed after this window can be cancelled within 30 minutes of placing them. Orders cannot be edited — please cancel and place a fresh order instead.<br>• If you paid online via UPI and your order is cancelled — by you within the allowed window, or by us for any reason — the full amount is refunded to the same UPI account within 24 hours.<br>• Orders placed with a discount coupon cannot be edited; please cancel and place a fresh order instead.<br>• Any issue with your meal? WhatsApp us a photo within 2 hours of delivery — we will arrange a replacement or a full refund.<br>• Support: 📞 +91 99249 37939 (WhatsApp available).', waFallback:'Share order details on WhatsApp (optional) →', newOrder:'Place Another Order', trackOrderBtn:'Track Your Order', successConfirmNote:'Your order has been confirmed. You can view and track it anytime in the My Orders section.',
      addToCart:'🛒 Add to Cart', addedShort:'added to cart', addToCart2:'ADD', payNowUpi:'PAY ONLINE', payRefLbl:'Payment reference', srv_dup_date:'You already have an order for this date.', srv_qty_limit:'You can order 1 tiffin per meal per day. For larger quantities, please contact the kitchen.', srv_cancel_window:'The cancellation window for this order has closed.', srv_already_cancelled:'This order is already cancelled.', srv_cancel_delivered:'A delivered order cannot be cancelled.', srv_not_yours:'This order does not belong to your account.', srv_no_meal:'Your order is empty — please select at least one meal.', srv_office_off:'Office delivery is not available right now.', srv_home_off:'Home delivery is not available right now.', srv_company_req:'Please select your company from the list.', srv_empid_req:'Employee ID is required.', srv_blocked:'Your account is blocked. Support: 99249 37939', srv_wrong_pw:'Incorrect password.', srv_no_account:'No account found with this email.', srv_email_exists:'An account with this email already exists — please sign in.', srv_phone_taken:'This mobile number is already linked to another account.', srv_use_google:'This account uses Google Sign-In — please use "Sign in with Google".', srv_reset_sent:'If this email is registered, a reset link has been sent.', srv_reset_bad:'This reset link is invalid or has expired.', srv_reset_expired:'This reset link has expired — please request a new one.', scanToPay:'Scan the QR with any UPI app', copyId:'COPY', pleaseWait:'Please wait…', cancelWindowOver:'The cancellation window for this order has closed. For any help, please contact the kitchen.', limitTitle:'One Tiffin Per Meal', limitBody:'Each customer can order 1 breakfast, 1 lunch and 1 dinner per day. For a larger quantity, please connect with our kitchen — we will be happy to arrange it.', limitCta:'Connect to Kitchen', limitClose:'Got it', subtotalLbl:'Subtotal', deliveryLbl:'Delivery', infoStripText:'Order timings — Breakfast: by 10 PM previous night · Lunch: by 9 AM · Dinner: by 3 PM', subPushLine:'Order daily? Set up a subscription', reorderBtn:'Reorder', reorderDone:'Items added to your cart', reorderNoSlot:'These meals are not available in the next 3 days', lpTagline:'Fresh, homemade meals — delivered to your doorstep, every day.', lpOrderNow:'Order Now', lpTodays:'Today&#39;s Meals', lpOpen:'Open', lpClosed:'Closed', lpWhy:'Why Flying Birds', lpU1t:'Fresh Daily Batches', lpU1s:'Cooked in small batches every day — never stored or frozen.', lpU2t:'Home-Style Ingredients', lpU2s:'Freshly ground masalas — no packet mixes, no shortcuts.', lpU3t:'Safe, Hygienic Packaging', lpU3s:'Certified food-grade containers for every single meal.', lpSubT:'Daily Tiffin Subscription', lpSubS:'Set once — your tiffin arrives every day automatically.', lpHow:'How It Works', lpH1:'Pick your meal & customise it', lpH2:'Choose delivery date & time slot', lpH3:'Pay online or at delivery', pubLogin:'Login', pubBack:'← Back', dtypeQ:'Where should we deliver?', modeTitle:'Where would you like your tiffin?', modeSub:'Choose once — you can change it any time.', modeChange:'Change', dtHome:'Home', dtHomeSub:'Society / Flat', dtOffice:'Office', dtOfficeSub:'Company / Employee', companyLbl:'Select Your Company', companyHint:'Company not listed? Contact the kitchen — we will add it.', empIdLbl:'Employee ID', errCompany:'Please select your company', errEmpId:'Please enter your Employee ID', pubCta:'See Menu & Order', pubCutoffLine:'Lunch closes at <b>9:00 AM</b> · Dinner at <b>3:00 PM</b>', pubHookQ:'Can healthy food really be cooked in a <em>20-minute delivery</em>?', pubHookA:'It can\'t. Food that fast was <b>cooked long before you ordered</b> — reheated, and rushed.', cmpUs:'Our Kitchen', cmpThem:'Delivery Apps', cmpU1:'Freshly ground masala', cmpT1:'Bulk packet masala', cmpU2:'Fresh oil, every day', cmpT2:'Oil reused all day', cmpU3:'Limited orders daily', cmpT3:'Unlimited, mass-cooked', cmpU4:'Same cook, same taste', cmpT4:'A new kitchen each time', cmpU5:'Fixed price, no extras', cmpT5:'Surge + platform fees', cmpU6:'Light, everyday food', cmpT6:'Heavy restaurant fare', cmpU7:'A kitchen you can visit', cmpT7:'A kitchen you\'ll never see', cmpQualT:'Quality, not quantity.', cmpQualS:'We cap our orders and serve one township — so every tiffin gets the time it deserves.', cmpChip:'📍 Only for Godrej Garden City', lpPosT:'This Is Not a Quick-Delivery App', lpPosS:'It is your everyday kitchen — planned, fresh and always on time.', lpPos1:'Delivery in fixed time slots — no 10-minute race, no rush.', lpPos2:'Light, nourishing home-style food — not heavy restaurant fare.', lpPos3:'Simple fixed prices — no surge, no hidden or platform charges.', lpPos4:'One trusted kitchen every day — the same care in every tiffin.', navMenuShort:'Menu', navProfileShort:'Profile', pfTitle:'👤 My Profile', pfAddr:'Saved Delivery Address', pfFlatLbl:'Flat / Block No.', pfSave:'Save Address', addrSaved:'Address saved', pfQuick:'Quick Links', pfLang:'Language', payWithUpiBtn:'Pay Now', orScan:'or scan the QR code', upiPayNote:'🔒 Secure payment via UPI. Amount is pre-filled — just approve in your UPI app.', copied:'UPI ID copied', updateCart:'✓ Update in Cart', addedToCart:'added to cart', customizable:'customizable', chooseSize:'Choose Size', sizeRequired:'Required · Select any 1 option', addOns:'Add-ons', dahiShort:'Dahi', extraSabziShort:'Extra Sabzi', freshCookedDesc:'Prepared fresh in small daily batches — never stored, never frozen.', selectSabzi:'Select sabzi', rotiType:'Roti type', plain:'Plain', butter:'Butter', deliveryTime:'⏰ Delivery Time', tiffinType:'🍱 Choose Your Tiffin', miniTiffin:'Mini Tiffin', fullTiffin:'Full Tiffin',
      extraRoti:'Extra Roti', addDahi:'Add Curd', extraSabzi:'Extra Sabzi portion', howMany:'How many tiffins?', unitPrice:'Unit price',
      perTiffin:'/ tiffin', specialInstr:'📝 Special instructions (optional)', notePh:'e.g. Less spicy, no onion...',
      backApp:'← Back to App', remove:'Remove', cancelOrder:'✖ Cancel', editOrder:'Edit', editLoaded:'Order loaded — make changes & checkout',
      closedBreakfast:'Same-day breakfast is not available — please order a day in advance.', kitchenClosedMsg:'Kitchen is closed on this date — please choose another day.', happyCustomers:'Happy Customers Served', orderedForThisMeal:'tiffins ordered so far', beingPrepared:'being prepared right now', onlyLeftToday:'Only {n} remaining for today', soldOutToday:'Sold out for today', soldOutTitle:"We're Sold Out for This Meal", soldOutSub:'To keep every tiffin fresh, we only cook a limited batch. Please try another meal or day.',
      closedLunch:'Today\'s lunch booking is closed (was open till 9:00 AM).',
      closedDinner:'Today\'s dinner booking is closed (was open till 3:00 PM).', closedBkTom:'Tomorrow\'s breakfast booking is closed (was open till 10:00 PM last night).',
      closedTomorrow:'Tomorrow\'s booking is closed (was open till 10:00 PM).',
      cancelClosed:'Cancellation window has been closed.',
      dupMsg:'An order already exists for this date. To make changes, please contact Store Support at 99249 37939.',
      noUpcoming:'No upcoming orders yet. Add meals from the menu to place your first order.', noHistory:'No orders found for this date.', navHome:'Home', navCart:'Cart', navPast:'Past Orders', navAbout:'About Us', navSub:'Subscription', navHomeShort:'Home', navCartShort:'Cart', navSubShort:'Subscribe', navOrdersShort:'Orders', navHomeShort:'Home', navCartShort:'Cart', navSubShort:'Subscribe', navOrdersShort:'Orders', subTitle:'🔁 Subscription', subSub:'Ek baar set karein — aapka daily tiffin apne aap order ho jayega.', subActive:'Active Plan', subDaysWeek:'din/hafta', subSkipped:'Skip kiye', subSkipBtn:'Din skip karein', subCancelBtn:'Plan Cancel', subEditNote:'Neeche edit karke Update dabayein', subPickMeals:'Meals chunein', subPickDays:'Din chunein', subWeekdays:'Som–Shukra', subAllDays:'Saaton din', subClear:'Clear', subDateRange:'Date range', subStart:'Shuru', subEnd:'Khatam', subDelivery:'Delivery', subUpdate:'Plan Update', subStart2:'Subscription Shuru', subAnySabzi:'Chef\'s choice', subSaved:'Subscription successfully save ho gaya.', subCancelled:'Subscription cancel ho gaya', subCancelConfirm:'Subscription cancel karein?', subSkipDone:'Din skip ho gaya', subUnskipDone:'Skip hata diya', subPickSkipDate:'Skip ke liye date chunein', subEndAfter:'End date start ke baad honi chahiye', subStartInfo:'Kal se aage', navSub:'Subscription', subTitle:'🔁 Subscription', subSub:'Set it once — your daily tiffin is placed automatically.', subActive:'Active Plan', subDaysWeek:'days/week', subSkipped:'Skipped', subSkipBtn:'Skip a day', subCancelBtn:'Cancel Plan', subEditNote:'Edit below & Update to change your plan', subPickMeals:'Pick meals', subPickDays:'Pick days', subWeekdays:'Mon–Fri', subAllDays:'All 7', subClear:'Clear', subDateRange:'Date range', subStart:'Start', subEnd:'End', subDelivery:'Delivery', subUpdate:'Update Plan', subStart2:'Start Subscription', subAnySabzi:'Chef\'s choice', subSaved:'Subscription saved successfully.', subCancelled:'Subscription cancelled', subCancelConfirm:'Cancel your subscription?', subSkipDone:'Day skipped', subUnskipDone:'Skip removed', subPickSkipDate:'Pick a date to skip', subEndAfter:'End date must be after start', subStartInfo:'From tomorrow onwards', navContact:'Contact Karein', contactTitle:'📞 Contact Karein', contactSub:'Aapki baat sunna hamesha achha lagta hai', contactInfoTitle:'ℹ️ Jaankari', contactAddrLbl:'Location', contactAreaLbl:'Delivery Area', contactHoursLbl:'Delivery Time', navContact:'Contact Us', contactTitle:'📞 Contact Us', contactSub:'We would love to hear from you', contactInfoTitle:'ℹ️ Info', contactAddrLbl:'Location', contactAreaLbl:'Delivery Area', contactHoursLbl:'Delivery Hours',
      aboutTitle:'ℹ️ About Us', aboutSub:'Why our tiffin is different', aboutSwipe:'← Swipe to see more →',
      aboutContact:'📞 Questions? We\'re just a call away.'
    },
    hinglish: {
      errNetwork:'❌ Network error. Connection check karke dobara try karein.', sessionExpired:'⚠️ Session expire ho gaya — kripya dobara sign in karein.', completeFields:'⚠️ Kripya saari zaroori details bharein.', orderFailed:'❌ Order place nahi ho paya. Kripya dobara try karein.', selectDate:'⚠️ Pehle ek date chunein.', orderCancelled:'✅ Aapka order cancel ho gaya.', resetLinkBad:'❌ Ye reset link invalid ya expire ho chuka hai.', confirmCancel:'Ye order cancel karein?', welcomeUser:'🎉 Swagat hai,', errLogin:'Aage badhne ke liye sign in karein.',
      // ── Auth (sign in / sign up / password reset) ──
      signInTitle:'Wapas Aapka Swagat Hai', signInBtn:'Sign In', signUpTitle:'Naya Account Banayein', signUpSub:'Roz ka tiffin order karne ke liye sign up karein.',
      createAccountBtn:'Account Banayein', emailLabel:'Email', passwordLabel:'Password', passwordPh:'Apna password daalein', passwordPh6:'Kam se kam 6 characters',
      confirmPwLabel:'Password Confirm Karein', confirmPwPh:'Password dobara daalein', newPasswordLabel:'Naya Password',
      errEmail:'Kripya sahi email address daalein.', errPassword:'Kripya apna password daalein.', errPassword6:'Password kam se kam 6 characters ka hona chahiye.', errConfirmPw:'Dono password match nahi ho rahe.',
      orDivider:'ya', forgotPw:'Password bhool gaye?', forgotTitle:'Password Reset Karein', forgotSub:'Apna email daalein — hum reset link bhej denge.',
      sendResetBtn:'Reset Link Bhejein', resetLinkSent:'Agar ye email registered hai to reset link bhej diya gaya hai.',
      resetTitle:'Naya Password Set Karein', resetSub:'Apne account ke liye naya password chunein.', resetBtn:'Password Reset Karein', passwordResetDone:'Password update ho gaya — ab sign in kar sakte hain.',
      backToSignIn:'← Sign In par wapas', switchToSignIn:'Pehle se account hai? <b onclick="showAuthMode(\'signin\')">Sign In</b>', switchToSignUp:'Account nahi hai? <b onclick="showAuthMode(\'signup\')">Sign Up</b>',
      phoneDeliveryHint:'Delivery ke liye isi number par sampark karenge.',
      // ── Bottom nav ──
      navHomeShort:'Home', navCartShort:'Cart', navOrdersShort:'Orders', navSub:'Subscription', navSubShort:'Subscribe',
      // ── Subscription ──
      subTitle:'🔁 Subscription', subActive:'Active Plan', subPickMeals:'Meals chunein', subPickDays:'Din chunein',
      subWeekdays:'Som–Shukra', subAllDays:'Saaton din', subClear:'Clear', subAnySabzi:'Chef ki pasand',
      subStart:'Shuru', subEnd:'Khatam', subStart2:'Subscription Shuru Karein', subUpdate:'Plan Update Karein', subCancelBtn:'Plan Cancel Karein',
      subCancelConfirm:'Subscription cancel karein?', subCancelled:'Subscription cancel ho gaya', subSaved:'Subscription save ho gaya.',
      subSkipBtn:'Ek din skip karein', subPickSkipDate:'Skip karne ke liye date chunein', subSkipDone:'Din skip ho gaya', subUnskipDone:'Skip hata diya', subSkipped:'Skipped',
      subDateRange:'Date range', subDaysWeek:'din/hafta', subDelivery:'Delivery', subEditNote:'Neeche edit karke Update dabayein — plan badal jayega', subEndAfter:'End date, start ke baad honi chahiye', subStartInfo:'Kal se shuru',
      // ── Contact ──
      navContact:'Contact Karein', contactTitle:'📞 Contact Karein', contactSub:'Aapki baat sunna hamesha achha lagta hai',
      contactInfoTitle:'ℹ️ Jaankari', contactAddrLbl:'Location', contactAreaLbl:'Delivery Area', contactHoursLbl:'Delivery Time',
      tagline:'Fresh • Homemade • Doorstep Delivery', secureLogin:'🔐 Secure Login',
      loginTitle:'Login ya Sign Up', mobileLabel:'Mobile Number', mobilePh:'10-digit mobile number daalein',
      continueBtn2:'Aage Badhein', loginHint:'Apna Google account chunein.', phoneFirstHint:'Sirf pehli baar zaroori — delivery contact ke liye.', completeSignup:'✓ Sign Up Poora Karein',
      verifyTitle:'Ek Aakhri Step', googleWelcome:'✅ Google se sign in ho gaya. Delivery contact ke liye mobile number daalein.', nameLabel:'Aapka Naam', namePh:'Apna pura naam likhein',
      otpLabel:'Verification Code daalein', verifyBtn:'Verify & Continue', changeNum:'Doosra Google account use karein', errName:'Valid naam daalein (sirf letters).', errPhone:'Valid 10-digit mobile number daalein.', errPickGoogle:'Pehle Google button dabakar account chunein.',
      badgeFresh:'🌿 No Frozen Food', badgeCustom:'🍳 Customizable', badgeCOD:'💵 Cash on Delivery',
      freshStrip:'🌿 Bilkul Fresh: Aapka khana order ke baad hi banta hai — na frozen, na baasi.',
      deliveryDate:'📅 Delivery Date',
      cutoffNote:'🕒 Order Cut-off Time (IST)\n• Breakfast — ek raat pehle 10:00 PM tak\n• Lunch — usi din 9:00 AM tak\n• Dinner — usi din 3:00 PM tak\nCut-off ke baad agle available din ke liye order karein.',
      selectMeals:'🍽️ Apne Meals Chunein', yourCart:'🛒 Aapki Cart', clearCart:'Clear', cartEmpty:'Cart khali hai. Upar se meals add karein.',
      myOrders:'📋 Mere Orders', refresh:'🔄 Refresh', viewPast:'🗓️ Purani date ke orders dekhein', view:'View',
      cartTotal:'CART TOTAL', checkout:'Checkout →', viewCart:'Cart Dekhein →', logout:'Logout',
      checkoutTitle:'📦 Delivery Details', checkoutSub:'Last step — order confirm karein', backMenu:'← Menu par wapas',
      autofillNote:'✓ Aapka saved address auto-fill ho gaya', township:'🏢 Township', society:'🏘️ Society', flat:'🏠 Flat Number',
      fullName:'👤 Pura Naam', verifiedMobile:'📱 Mobile Number (verified ✓)', payMethod:'💰 Payment Method',
      payCOD:'💵 Cash on Delivery', payCODsub:'Tiffin milne par cash dein', payUPI:'💳 Pay Online (UPI)', payUPIsub:'Order place karte hi QR code milega', codNote:'Cash on Delivery — tiffin milne par payment karein.',
      errSociety:'Apni society select karein.', errFlat:'Apna block aur flat number daalein, e.g. D-706.',
      placeOrder:'📤 Place Order', successTitle:'Order Confirm Ho Gaya', promoHave:'Coupon code hai? Yahan daalein', promoApply:'Apply', promoApplied:'apply ho gaya', discountLbl:'Discount', promoFirstDateNote:'(pehli delivery date par lagta hai)', promoEditNote:'Discount wale orders edit nahi ho sakte — cancel karke naya order karein.', promoUseAtCheckout:'Cart me code par tap karke apply karein', promoNewTag:'naye customers', policyTitle:'Cancellation & Refund Policy', policyBody:'• Order delivery se ek raat pehle 10:00 PM tak cancel ho sakta hai. Uske baad place kiye gaye orders, place karne ke 30 minute ke andar cancel ho sakte hain. Order edit nahi ho sakta — cancel karke naya order place karein.<br>• Agar aapne UPI se online payment kiya hai aur order cancel hota hai — chahe aapne allowed window me kiya ho ya humne kisi wajah se — poora amount 24 ghante ke andar usi UPI account me refund kar diya jaata hai.<br>• Coupon discount wale orders edit nahi ho sakte; kripya cancel karke naya order place karein.<br>• Khaane me koi bhi problem ho? Delivery ke 2 ghante ke andar photo ke saath WhatsApp karein — hum replacement ya poora refund arrange karenge.<br>• Support: 📞 +91 99249 37939 (WhatsApp par available).', subSub:'Ek baar set karein — aapka daily tiffin apne aap order ho jayega.', subSaved:'Subscription successfully save ho gaya.', waFallback:'Order details WhatsApp par share karein (optional) →', newOrder:'Naya Order Place Karein', trackOrderBtn:'Order Track Karein', successConfirmNote:'Aapka order confirm ho chuka hai. Aap ise kabhi bhi My Orders section mein dekh aur track kar sakte hain.',
      addToCart:'🛒 Cart mein daalein', addedShort:'cart mein add hua', addToCart2:'ADD', payNowUpi:'ONLINE PAYMENT', payRefLbl:'Payment reference', srv_dup_date:'Is date ka order pehle se hai.', srv_qty_limit:'Ek din me har meal ka sirf 1 tiffin. Zyada ke liye kitchen se sampark karein.', srv_cancel_window:'Is order ka cancellation window band ho chuka hai.', srv_already_cancelled:'Ye order pehle se cancelled hai.', srv_cancel_delivered:'Delivered order cancel nahi ho sakta.', srv_not_yours:'Ye order aapke account ka nahi hai.', srv_no_meal:'Order khali hai — kam se kam ek meal chunein.', srv_office_off:'Office delivery abhi available nahi hai.', srv_home_off:'Home delivery abhi available nahi hai.', srv_company_req:'Kripya list me se apni company chunein.', srv_empid_req:'Employee ID zaroori hai.', srv_blocked:'Aapka account block hai. Support: 99249 37939', srv_wrong_pw:'Password galat hai.', srv_no_account:'Is email se koi account nahi mila.', srv_email_exists:'Is email se account pehle se hai — sign in karein.', srv_phone_taken:'Ye mobile number doosre account se juda hai.', srv_use_google:'Ye account Google Sign-In ka hai — "Sign in with Google" use karein.', srv_reset_sent:'Agar ye email registered hai, reset link bhej diya gaya hai.', srv_reset_bad:'Ye reset link invalid ya expire ho chuka hai.', srv_reset_expired:'Reset link expire ho gaya — naya request karein.', scanToPay:'Kisi bhi UPI app se QR scan karein', copyId:'COPY', pleaseWait:'Ek moment…', cancelWindowOver:'Is order ka cancellation window band ho chuka hai. Kisi bhi madad ke liye kitchen se sampark karein.', limitTitle:'Ek Meal Ka Ek Tiffin', limitBody:'Har customer ek din me 1 breakfast, 1 lunch aur 1 dinner order kar sakta hai. Zyada quantity ke liye kripya kitchen se sampark karein — hum khushi se arrange kar denge.', limitCta:'Kitchen Se Sampark Karein', limitClose:'Theek hai', subtotalLbl:'Subtotal', deliveryLbl:'Delivery', infoStripText:'Order timing — Breakfast: ek raat pehle 10 PM tak · Lunch: 9 AM tak · Dinner: 3 PM tak', subPushLine:'Roz order karte hain? Subscription set karein', reorderBtn:'Reorder', reorderDone:'Items aapke cart mein add ho gaye', reorderNoSlot:'Ye meals agle 3 din available nahi hain', lpTagline:'Roz taaza, ghar jaisa khana — seedha aapke doorstep tak.', lpOrderNow:'Order Karein', lpTodays:'Aaj ke Meals', lpOpen:'Open', lpClosed:'Band', lpWhy:'Flying Birds Hi Kyun', lpU1t:'Roz Taaze Batches', lpU1s:'Har din chhote batches mein banta hai — kabhi store ya frozen nahi.', lpU2t:'Ghar Jaise Ingredients', lpU2s:'Taaze pise masale — koi packet mix nahi.', lpU3t:'Safe, Hygienic Packaging', lpU3s:'Har meal certified food-grade container mein.', lpSubT:'Daily Tiffin Subscription', lpSubS:'Ek baar set karein — tiffin roz apne aap aayega.', lpHow:'Kaise Kaam Karta Hai', lpH1:'Meal chunein aur customise karein', lpH2:'Delivery date aur time slot chunein', lpH3:'Online ya delivery par pay karein', pubLogin:'Login', pubBack:'← Wapas', dtypeQ:'Delivery kahan chahiye?', modeTitle:'Tiffin kahan chahiye?', modeSub:'Ek baar chunein — kabhi bhi badal sakte hain.', modeChange:'Badlein', dtHome:'Home', dtHomeSub:'Society / Flat', dtOffice:'Office', dtOfficeSub:'Company / Employee', companyLbl:'Apni Company Chunein', companyHint:'Company list me nahi? Kitchen se sampark karein — hum add kar denge.', empIdLbl:'Employee ID', errCompany:'Kripya apni company chunein', errEmpId:'Kripya Employee ID daalein', pubCta:'Menu Dekhein & Order Karein', pubCutoffLine:'Lunch band <b>9:00 AM</b> · Dinner <b>3:00 PM</b>', pubHookQ:'Kya healthy khana sach me <em>20-minute delivery</em> me ban sakta hai?', pubHookA:'Nahi ban sakta. Itni jaldi aane wala khana <b>aapke order se pehle hi bana hota hai</b> — dobara garam karke bheja jaata hai.', cmpUs:'Hamara Kitchen', cmpThem:'Delivery Apps', cmpU1:'Ghar pe pise taaze masale', cmpT1:'Bulk packet masala', cmpU2:'Roz naya tel', cmpT2:'Wahi tel din bhar', cmpU3:'Roz limited orders', cmpT3:'Unlimited, bulk cooking', cmpU4:'Wahi cook, wahi swaad', cmpT4:'Har baar alag kitchen', cmpU5:'Fixed daam, koi extra nahi', cmpT5:'Surge + platform fees', cmpU6:'Halka, roz ka khana', cmpT6:'Bhaari restaurant food', cmpU7:'Kitchen jo aap dekh sakte hain', cmpT7:'Kitchen jo kabhi nahi dikhega', cmpQualT:'Quality, quantity nahi.', cmpQualS:'Hum roz ke orders limited rakhte hain aur sirf ek township serve karte hain — taaki har tiffin ko poora time mile.', cmpChip:'📍 Sirf Godrej Garden City ke liye', lpPosT:'Ye Fatafat-Delivery App Nahi Hai', lpPosS:'Ye aapka roz ka kitchen hai — planned, taaza aur hamesha time par.', lpPos1:'Fixed time slots par delivery — 10-minute wali race nahi.', lpPos2:'Halka, poshan-bhara ghar jaisa khana — restaurant ka bhaari tel-masala nahi.', lpPos3:'Seedhe fixed daam — na surge, na hidden ya platform charges.', lpPos4:'Roz ek hi bharosemand kitchen — har tiffin mein wahi apnapan.', navMenuShort:'Menu', navProfileShort:'Profile', pfTitle:'👤 Meri Profile', pfAddr:'Saved Delivery Address', pfFlatLbl:'Flat / Block No.', pfSave:'Address Save Karein', addrSaved:'Address save ho gaya', pfQuick:'Quick Links', pfLang:'Language', payWithUpiBtn:'Payment Karein', orScan:'ya QR code scan karein', upiPayNote:'🔒 UPI se secure payment. Amount pehle se bhara hai — bas apne UPI app mein approve karein.', copied:'UPI ID copy ho gayi', updateCart:'✓ Cart update karein', addedToCart:'cart mein add hua', customizable:'customizable', chooseSize:'Size Chunein', sizeRequired:'Zaroori · Koi 1 chunein', addOns:'Add-ons', dahiShort:'Dahi', extraSabziShort:'Extra Sabzi', freshCookedDesc:'Roz chhote batches mein taaza banta hai — kabhi store ya frozen nahi.', selectSabzi:'Sabzi chunein', rotiType:'Roti type', plain:'Plain', butter:'Butter', deliveryTime:'⏰ Delivery Time', tiffinType:'🍱 Apna Tiffin Chunein', miniTiffin:'Mini Tiffin', fullTiffin:'Full Tiffin',
      extraRoti:'Extra Roti', addDahi:'Dahi add karein', extraSabzi:'Extra Sabzi', howMany:'Kitne tiffin?', unitPrice:'Unit price',
      perTiffin:'/ tiffin', specialInstr:'📝 Special instructions (optional)', notePh:'e.g. Kam mirchi, no onion...',
      backApp:'← App par wapas', remove:'Hatayein', cancelOrder:'✖ Cancel', editOrder:'Edit', editLoaded:'Order load ho gaya — badlav karke checkout karein',
      closedBreakfast:'Same-day breakfast available nahi — ek din pehle order karein.', kitchenClosedMsg:'Is date par kitchen band hai — koi doosra din chunein.', happyCustomers:'Happy Customers Served', orderedForThisMeal:'tiffins ab tak order hue', beingPrepared:'abhi ban rahe hain', onlyLeftToday:'Aaj ke liye sirf {n} available hain', soldOutToday:'Aaj ke liye sold out', soldOutTitle:'Is Meal Ke Slots Full Ho Gaye', soldOutSub:'Har tiffin fresh rakhne ke liye hum limited batch hi banate hain. Doosra meal ya din try karein.',
      closedLunch:'Aaj ke lunch ki booking band (9:00 AM tak thi).',
      closedDinner:'Aaj ke dinner ki booking band (3:00 PM tak thi).', closedBkTom:'Kal ke breakfast ki booking band (kal raat 10:00 PM tak thi).',
      closedTomorrow:'Kal ki booking band (10:00 PM tak thi).',
      cancelClosed:'Cancellation window band ho gaya hai.',
      dupMsg:'Is date ke liye order pehle se hai. Change ke liye Store Support ko call karein: 99249 37939.',
      noUpcoming:'Abhi koi upcoming order nahi hai. Menu se meals add karke order place karein.', noHistory:'Is date par koi order nahi mila.', navHome:'Home', navCart:'Cart', navPast:'Purane Orders', navAbout:'About Us',
      aboutTitle:'ℹ️ About Us', aboutSub:'Hamara tiffin alag kyun hai', aboutSwipe:'← Aage dekhne ke liye swipe karein →',
      aboutContact:'📞 Koi sawaal ho to humein call karein.'
    },
    hi: {
      errNetwork:'❌ नेटवर्क त्रुटि। कनेक्शन जाँचकर दोबारा प्रयास करें।', sessionExpired:'⚠️ आपका सेशन समाप्त हो गया — कृपया दोबारा साइन इन करें।', completeFields:'⚠️ कृपया सभी आवश्यक जानकारी भरें।', orderFailed:'❌ ऑर्डर प्लेस नहीं हो सका। कृपया दोबारा प्रयास करें।', selectDate:'⚠️ कृपया पहले एक तारीख़ चुनें।', orderCancelled:'✅ आपका ऑर्डर कैंसल हो गया।', resetLinkBad:'❌ यह रीसेट लिंक अमान्य या समाप्त हो चुका है।', confirmCancel:'क्या यह ऑर्डर कैंसल करें?', welcomeUser:'🎉 स्वागत है,', errLogin:'आगे बढ़ने के लिए साइन इन करें।',
      tagline:'ताज़ा • घर का बना • डोरस्टेप डिलीवरी', secureLogin:'🔐 सुरक्षित लॉगिन', signInTitle:'वापसी पर स्वागत है', emailLabel:'ईमेल', passwordLabel:'पासवर्ड', passwordPh:'अपना पासवर्ड डालें', passwordPh6:'कम से कम 6 अक्षर', confirmPwLabel:'पासवर्ड की पुष्टि करें', confirmPwPh:'पासवर्ड दोबारा डालें', errEmail:'सही ईमेल एड्रेस डालें।', errPassword:'अपना पासवर्ड डालें।', errPassword6:'पासवर्ड कम से कम 6 अक्षर का हो।', errConfirmPw:'पासवर्ड मैच नहीं हो रहा।', forgotPw:'पासवर्ड भूल गए?', signInBtn:'साइन इन करें', signUpTitle:'अकाउंट बनाएं', signUpSub:'रोज़ का टिफ़िन ऑर्डर करने के लिए साइन अप करें।', phoneDeliveryHint:'डिलीवरी संपर्क के लिए इस्तेमाल होगा।', createAccountBtn:'अकाउंट बनाएं', switchToSignUp:'अकाउंट नहीं है? <b onclick="showAuthMode(\'signup\')">साइन अप करें</b>', switchToSignIn:'पहले से अकाउंट है? <b onclick="showAuthMode(\'signin\')">साइन इन करें</b>', backToSignIn:'← साइन इन पर वापस', forgotTitle:'पासवर्ड रीसेट करें', forgotSub:'अपना ईमेल डालें, हम रीसेट लिंक भेज देंगे।', sendResetBtn:'रीसेट लिंक भेजें', resetTitle:'नया पासवर्ड सेट करें', resetSub:'अपने अकाउंट के लिए नया पासवर्ड चुनें।', newPasswordLabel:'नया पासवर्ड', resetBtn:'पासवर्ड रीसेट करें', orDivider:'या', resetLinkSent:'अगर ये ईमेल रजिस्टर्ड है, रीसेट लिंक भेज दिया गया है।', passwordResetDone:'पासवर्ड अपडेट हो गया — अब साइन इन कर सकते हैं।',
      loginTitle:'लॉगिन या साइन अप', mobileLabel:'मोबाइल नंबर', mobilePh:'10 अंकों का मोबाइल नंबर डालें',
      continueBtn2:'आगे बढ़ें', loginHint:'अपना Google अकाउंट चुनें।', phoneFirstHint:'सिर्फ़ पहली बार ज़रूरी — डिलीवरी संपर्क के लिए।', completeSignup:'✓ साइन अप पूरा करें',
      verifyTitle:'एक आख़िरी क़दम', googleWelcome:'✅ Google से साइन इन हो गया। डिलीवरी संपर्क के लिए मोबाइल नंबर डालें।', nameLabel:'आपका नाम', namePh:'अपना पूरा नाम लिखें',
      otpLabel:'वेरिफ़िकेशन कोड डालें', verifyBtn:'वेरिफ़ाई करें', changeNum:'दूसरा Google अकाउंट इस्तेमाल करें', errName:'सही नाम डालें (केवल अक्षर)।', errPhone:'सही 10 अंकों का मोबाइल नंबर डालें।', errPickGoogle:'पहले Google बटन दबाकर अकाउंट चुनें।',
      badgeFresh:'🌿 कोई फ़्रोज़न नहीं', badgeCustom:'🍳 कस्टमाइज़ेबल', badgeCOD:'💵 कैश ऑन डिलीवरी',
      freshStrip:'🌿 एकदम ताज़ा: आपका खाना ऑर्डर के बाद ही बनता है — न फ़्रोज़न, न बासी।',
      deliveryDate:'📅 डिलीवरी की तारीख़',
      cutoffNote:'🕒 ऑर्डर कट-ऑफ समय (IST)\n• नाश्ता — एक रात पहले 10:00 PM तक\n• लंच — उसी दिन 9:00 AM तक\n• डिनर — उसी दिन 3:00 PM तक\nकट-ऑफ के बाद अगले उपलब्ध दिन के लिए ऑर्डर करें।',
      selectMeals:'🍽️ अपने मील चुनें', yourCart:'🛒 आपकी कार्ट', clearCart:'खाली करें', cartEmpty:'कार्ट खाली है। ऊपर से मील जोड़ें।',
      myOrders:'📋 मेरे ऑर्डर', refresh:'🔄 रिफ़्रेश', viewPast:'🗓️ पुरानी तारीख़ के ऑर्डर देखें', view:'देखें',
      cartTotal:'कुल राशि', checkout:'चेकआउट →', viewCart:'कार्ट देखें →', logout:'लॉगआउट',
      checkoutTitle:'📦 डिलीवरी जानकारी', checkoutSub:'आख़िरी कदम — ऑर्डर कन्फ़र्म करें', backMenu:'← मेन्यू पर वापस',
      autofillNote:'✓ आपका सेव किया पता अपने-आप भर गया', township:'🏢 टाउनशिप', society:'🏘️ सोसायटी', flat:'🏠 फ़्लैट नंबर',
      fullName:'👤 पूरा नाम', verifiedMobile:'📱 मोबाइल नंबर (वेरिफ़ाइड ✓)', payMethod:'💰 भुगतान का तरीका',
      payCOD:'💵 कैश ऑन डिलीवरी', payCODsub:'टिफ़िन मिलने पर कैश दें', payUPI:'💳 ऑनलाइन पेमेंट (UPI)', payUPIsub:'ऑर्डर करते ही QR कोड मिलेगा', codNote:'कैश ऑन डिलीवरी — टिफ़िन मिलने पर भुगतान करें।',
      errSociety:'अपनी सोसायटी चुनें।', errFlat:'कृपया ब्लॉक और फ़्लैट नंबर डालें, जैसे D-706।',
      placeOrder:'📤 ऑर्डर करें', successTitle:'ऑर्डर कन्फर्म हो गया', promoHave:'कूपन कोड है? यहाँ डालें', promoApply:'लगाएँ', promoApplied:'लागू हुआ', discountLbl:'छूट', promoFirstDateNote:'(पहली डिलीवरी तारीख़ पर लागू)', promoEditNote:'छूट वाले ऑर्डर एडिट नहीं हो सकते — कैंसल करके नया ऑर्डर करें।', promoUseAtCheckout:'कार्ट में कोड पर टैप करके लागू करें', promoNewTag:'नए ग्राहक', policyTitle:'कैंसलेशन और रिफ़ंड नीति', policyBody:'• ऑर्डर डिलीवरी से एक रात पहले 10:00 PM तक कैंसल किया जा सकता है। इसके बाद किए गए ऑर्डर, ऑर्डर करने के 30 मिनट के भीतर कैंसल किए जा सकते हैं। ऑर्डर एडिट नहीं हो सकता — कृपया कैंसल करके नया ऑर्डर करें।<br>• यदि आपने UPI से ऑनलाइन भुगतान किया है और ऑर्डर कैंसल होता है — चाहे आपने अनुमत समय में किया हो या हमने किसी कारण से — पूरी राशि 24 घंटे के भीतर उसी UPI खाते में रिफ़ंड कर दी जाती है।<br>• कूपन छूट वाले ऑर्डर एडिट नहीं हो सकते; कृपया कैंसल करके नया ऑर्डर करें।<br>• खाने में कोई समस्या हो? डिलीवरी के 2 घंटे के भीतर फ़ोटो के साथ WhatsApp करें — हम रिप्लेसमेंट या पूरा रिफ़ंड देंगे।<br>• सहायता: 📞 +91 99249 37939 (WhatsApp उपलब्ध)।', waFallback:'ऑर्डर WhatsApp पर साझा करें (optional) →', newOrder:'नया ऑर्डर करें', trackOrderBtn:'ऑर्डर ट्रैक करें', successConfirmNote:'आपका ऑर्डर कन्फर्म हो चुका है। आप इसे कभी भी My Orders सेक्शन में देख और ट्रैक कर सकते हैं।',
      addToCart:'🛒 कार्ट में जोड़ें', addedShort:'कार्ट में जुड़ा', addToCart2:'जोड़ें', payNowUpi:'ऑनलाइन भुगतान', payRefLbl:'पेमेंट रेफ़रेंस', srv_dup_date:'इस तारीख़ का ऑर्डर पहले से है।', srv_qty_limit:'एक दिन में हर मील का सिर्फ़ 1 टिफ़िन। ज़्यादा के लिए किचन से संपर्क करें।', srv_cancel_window:'इस ऑर्डर की कैंसलेशन विंडो बंद हो चुकी है।', srv_already_cancelled:'यह ऑर्डर पहले से कैंसल है।', srv_cancel_delivered:'डिलीवर हुआ ऑर्डर कैंसल नहीं हो सकता।', srv_not_yours:'यह ऑर्डर आपके अकाउंट का नहीं है।', srv_no_meal:'ऑर्डर खाली है — कम से कम एक मील चुनें।', srv_office_off:'ऑफ़िस डिलीवरी अभी उपलब्ध नहीं है।', srv_home_off:'होम डिलीवरी अभी उपलब्ध नहीं है।', srv_company_req:'कृपया लिस्ट से अपनी कंपनी चुनें।', srv_empid_req:'एम्प्लॉई ID ज़रूरी है।', srv_blocked:'आपका अकाउंट ब्लॉक है। सपोर्ट: 99249 37939', srv_wrong_pw:'पासवर्ड ग़लत है।', srv_no_account:'इस ईमेल से कोई अकाउंट नहीं मिला।', srv_email_exists:'इस ईमेल से अकाउंट पहले से है — साइन इन करें।', srv_phone_taken:'यह मोबाइल नंबर दूसरे अकाउंट से जुड़ा है।', srv_use_google:'यह अकाउंट Google Sign-In का है — "Sign in with Google" चुनें।', srv_reset_sent:'अगर यह ईमेल रजिस्टर्ड है, रीसेट लिंक भेज दिया गया है।', srv_reset_bad:'यह रीसेट लिंक अमान्य या समाप्त है।', srv_reset_expired:'रीसेट लिंक समाप्त हो गया — नया अनुरोध करें।', scanToPay:'किसी भी UPI ऐप से QR स्कैन करें', copyId:'कॉपी', pleaseWait:'एक क्षण…', cancelWindowOver:'इस ऑर्डर का कैंसलेशन विंडो बंद हो चुका है। किसी भी मदद के लिए किचन से संपर्क करें।', limitTitle:'एक मील का एक टिफ़िन', limitBody:'हर ग्राहक एक दिन में 1 नाश्ता, 1 लंच और 1 डिनर ऑर्डर कर सकता है। ज़्यादा मात्रा के लिए कृपया किचन से संपर्क करें — हम खुशी से व्यवस्था कर देंगे।', limitCta:'किचन से संपर्क करें', limitClose:'ठीक है', subtotalLbl:'सबटोटल', deliveryLbl:'डिलीवरी', infoStripText:'ऑर्डर समय — नाश्ता: एक रात पहले 10 PM तक · लंच: 9 AM तक · डिनर: 3 PM तक', subPushLine:'रोज़ ऑर्डर करते हैं? सब्सक्रिप्शन सेट करें', reorderBtn:'फिर ऑर्डर करें', reorderDone:'आइटम आपके कार्ट में जुड़ गए', reorderNoSlot:'ये मील अगले 3 दिन उपलब्ध नहीं हैं', lpTagline:'रोज़ ताज़ा, घर जैसा खाना — सीधे आपके doorstep तक।', lpOrderNow:'ऑर्डर करें', lpTodays:'आज के मील', lpOpen:'उपलब्ध', lpClosed:'बंद', lpWhy:'Flying Birds ही क्यों', lpU1t:'रोज़ ताज़े बैच', lpU1s:'हर दिन छोटे बैच में बनता है — कभी स्टोर या फ़्रोज़न नहीं।', lpU2t:'घर जैसी सामग्री', lpU2s:'ताज़े पिसे मसाले — कोई पैकेट मिक्स नहीं।', lpU3t:'सुरक्षित पैकेजिंग', lpU3s:'हर मील सर्टिफ़ाइड फ़ूड-ग्रेड कंटेनर में।', lpSubT:'डेली टिफ़िन सब्सक्रिप्शन', lpSubS:'एक बार सेट करें — टिफ़िन रोज़ अपने आप आएगा।', lpHow:'कैसे काम करता है', lpH1:'मील चुनें और कस्टमाइज़ करें', lpH2:'डिलीवरी की तारीख़ और समय चुनें', lpH3:'ऑनलाइन या डिलीवरी पर भुगतान करें', pubLogin:'लॉगिन', pubBack:'← वापस', dtypeQ:'डिलीवरी कहाँ चाहिए?', modeTitle:'टिफ़िन कहाँ चाहिए?', modeSub:'एक बार चुनें — कभी भी बदल सकते हैं।', modeChange:'बदलें', dtHome:'घर', dtHomeSub:'सोसाइटी / फ़्लैट', dtOffice:'ऑफ़िस', dtOfficeSub:'कंपनी / एम्प्लॉई', companyLbl:'अपनी कंपनी चुनें', companyHint:'कंपनी लिस्ट में नहीं? किचन से संपर्क करें — हम जोड़ देंगे।', empIdLbl:'एम्प्लॉई ID', errCompany:'कृपया अपनी कंपनी चुनें', errEmpId:'कृपया एम्प्लॉई ID डालें', pubCta:'मेन्यू देखें और ऑर्डर करें', pubCutoffLine:'लंच बंद <b>9:00 AM</b> · डिनर <b>3:00 PM</b>', pubHookQ:'क्या हेल्दी खाना सच में <em>20-मिनट डिलीवरी</em> में बन सकता है?', pubHookA:'नहीं बन सकता। इतनी जल्दी आने वाला खाना <b>आपके ऑर्डर से पहले ही बना होता है</b> — दोबारा गरम करके भेजा जाता है।', cmpUs:'हमारा किचन', cmpThem:'डिलीवरी ऐप्स', cmpU1:'घर पर पिसे ताज़े मसाले', cmpT1:'बल्क पैकेट मसाला', cmpU2:'रोज़ नया तेल', cmpT2:'वही तेल दिन भर', cmpU3:'रोज़ सीमित ऑर्डर', cmpT3:'अनलिमिटेड, बल्क कुकिंग', cmpU4:'वही रसोइया, वही स्वाद', cmpT4:'हर बार अलग किचन', cmpU5:'फ़िक्स्ड दाम, कोई एक्स्ट्रा नहीं', cmpT5:'सर्ज + प्लेटफ़ॉर्म फ़ीस', cmpU6:'हल्का, रोज़ का खाना', cmpT6:'भारी रेस्टोरेंट फ़ूड', cmpU7:'किचन जो आप देख सकते हैं', cmpT7:'किचन जो कभी नहीं दिखेगा', cmpQualT:'क्वालिटी, क्वांटिटी नहीं।', cmpQualS:'हम रोज़ के ऑर्डर सीमित रखते हैं और सिर्फ़ एक टाउनशिप सर्व करते हैं — ताकि हर टिफ़िन को पूरा समय मिले।', cmpChip:'📍 सिर्फ़ Godrej Garden City के लिए', lpPosT:'यह फटाफट-डिलीवरी ऐप नहीं है', lpPosS:'यह आपका रोज़ का किचन है — planned, ताज़ा और हमेशा समय पर।', lpPos1:'Fixed time slots पर डिलीवरी — 10-मिनट वाली रेस नहीं।', lpPos2:'हल्का, पोषण-भरा घर जैसा खाना — रेस्टोरेंट का भारी तेल-मसाला नहीं।', lpPos3:'सीधे fixed दाम — ना surge, ना hidden या platform charges।', lpPos4:'रोज़ एक ही भरोसेमंद किचन — हर टिफ़िन में वही अपनापन।', navMenuShort:'मेनू', navProfileShort:'प्रोफ़ाइल', pfTitle:'👤 मेरी प्रोफ़ाइल', pfAddr:'सेव किया गया पता', pfFlatLbl:'फ़्लैट / ब्लॉक नं.', pfSave:'पता सेव करें', addrSaved:'पता सेव हो गया', pfQuick:'क्विक लिंक', pfLang:'भाषा', payWithUpiBtn:'भुगतान करें', orScan:'या QR कोड स्कैन करें', upiPayNote:'🔒 UPI से सुरक्षित भुगतान। राशि पहले से भरी है — बस अपने UPI ऐप में अप्रूव करें।', copied:'UPI ID कॉपी हो गई', updateCart:'✓ कार्ट अपडेट करें', addedToCart:'कार्ट में जुड़ा', customizable:'कस्टमाइज़ेबल', chooseSize:'साइज़ चुनें', sizeRequired:'ज़रूरी · कोई 1 चुनें', addOns:'ऐड-ऑन', dahiShort:'दही', extraSabziShort:'एक्स्ट्रा सब्ज़ी', freshCookedDesc:'रोज़ छोटे बैच में ताज़ा बनता है — कभी स्टोर या फ़्रोज़न नहीं।', selectSabzi:'सब्ज़ी चुनें', rotiType:'रोटी टाइप', plain:'प्लेन', butter:'बटर', deliveryTime:'⏰ डिलीवरी समय', tiffinType:'🍱 अपना टिफ़िन चुनें', miniTiffin:'मिनी टिफ़िन', fullTiffin:'फ़ुल टिफ़िन',
      extraRoti:'एक्स्ट्रा रोटी', addDahi:'दही जोड़ें', extraSabzi:'एक्स्ट्रा सब्ज़ी', howMany:'कितने टिफ़िन?', unitPrice:'यूनिट प्राइस',
      perTiffin:'/ टिफ़िन', specialInstr:'📝 विशेष निर्देश (वैकल्पिक)', notePh:'जैसे कम मिर्च, बिना प्याज़...',
      backApp:'← ऐप पर वापस', remove:'हटाएँ', cancelOrder:'✖ कैंसिल', editOrder:'बदलें', editLoaded:'ऑर्डर लोड हुआ — बदलाव करके चेकआउट करें',
      closedBreakfast:'सेम-डे ब्रेकफ़ास्ट उपलब्ध नहीं — एक दिन पहले ऑर्डर करें।', kitchenClosedMsg:'इस तारीख़ को किचन बंद है — कोई और दिन चुनें।', happyCustomers:'खुश ग्राहकों ने ऑर्डर किया', orderedForThisMeal:'टिफ़िन अब तक ऑर्डर हुए', beingPrepared:'अभी बन रहे हैं', onlyLeftToday:'आज के लिए केवल {n} उपलब्ध हैं', soldOutToday:'आज के लिए सोल्ड आउट', soldOutTitle:'इस मील के स्लॉट फुल हो गए', soldOutSub:'हर टिफ़िन ताज़ा रखने के लिए हम सीमित मात्रा में ही बनाते हैं। कोई और मील या दिन आज़माएँ।',
      closedLunch:'आज के लंच की बुकिंग बंद (9:00 AM तक थी)।',
      closedDinner:'आज के डिनर की बुकिंग बंद (3:00 PM तक थी)।', closedBkTom:'कल के ब्रेकफ़ास्ट की बुकिंग बंद (कल रात 10:00 PM तक थी)।',
      closedTomorrow:'कल की बुकिंग बंद (10:00 PM तक थी)।',
      cancelClosed:'कैंसिलेशन का समय समाप्त हो गया है।',
      dupMsg:'इस तारीख़ के लिए ऑर्डर पहले से है। बदलाव के लिए स्टोर सपोर्ट को कॉल करें: 99249 37939।',
      noUpcoming:'अभी कोई आगामी ऑर्डर नहीं है। मेनू से मील जोड़कर ऑर्डर करें।', noHistory:'इस तारीख़ पर कोई ऑर्डर नहीं मिला।', navHome:'होम', navCart:'कार्ट', navPast:'पुराने ऑर्डर', navAbout:'हमारे बारे में', navSub:'सब्सक्रिप्शन', navHomeShort:'होम', navCartShort:'कार्ट', navSubShort:'सब्सक्राइब', navOrdersShort:'ऑर्डर', subTitle:'🔁 सब्सक्रिप्शन', subSub:'एक बार सेट करें — आपका डेली टिफ़िन अपने आप ऑर्डर हो जाएगा।', subActive:'चालू प्लान', subDaysWeek:'दिन/हफ़्ता', subSkipped:'स्किप किए', subSkipBtn:'दिन स्किप करें', subCancelBtn:'प्लान रद्द करें', subEditNote:'नीचे बदलकर अपडेट दबाएँ', subPickMeals:'मील चुनें', subPickDays:'दिन चुनें', subWeekdays:'सोम–शुक्र', subAllDays:'सातों दिन', subClear:'साफ़', subDateRange:'तारीख़ रेंज', subStart:'शुरू', subEnd:'ख़त्म', subDelivery:'डिलीवरी', subUpdate:'प्लान अपडेट', subStart2:'सब्सक्रिप्शन शुरू', subAnySabzi:'शेफ़ की पसंद', subSaved:'सब्सक्रिप्शन सफलतापूर्वक सेव हुआ।', subCancelled:'सब्सक्रिप्शन रद्द हुआ', subCancelConfirm:'सब्सक्रिप्शन रद्द करें?', subSkipDone:'दिन स्किप हुआ', subUnskipDone:'स्किप हटा', subPickSkipDate:'स्किप के लिए तारीख़ चुनें', subEndAfter:'एंड डेट स्टार्ट के बाद हो', subStartInfo:'कल से आगे', navContact:'संपर्क करें', contactTitle:'📞 संपर्क करें', contactSub:'आपकी बात सुनना हमें अच्छा लगता है', contactInfoTitle:'ℹ️ जानकारी', contactAddrLbl:'लोकेशन', contactAreaLbl:'डिलीवरी क्षेत्र', contactHoursLbl:'डिलीवरी समय',
      aboutTitle:'ℹ️ हमारे बारे में', aboutSub:'हमारा टिफ़िन अलग क्यों है', aboutSwipe:'← आगे देखने के लिए स्वाइप करें →',
      aboutContact:'📞 कोई सवाल? हम एक कॉल दूर हैं।'
    },
    gu: {
      errNetwork:'❌ નેટવર્ક ભૂલ. કનેક્શન તપાસીને ફરી પ્રયાસ કરો.', sessionExpired:'⚠️ તમારું સેશન સમાપ્ત થયું — કૃપા કરીને ફરી સાઇન ઇન કરો.', completeFields:'⚠️ કૃપા કરીને બધી જરૂરી માહિતી ભરો.', orderFailed:'❌ ઓર્ડર પ્લેસ થઈ શક્યો નથી. કૃપા કરીને ફરી પ્રયાસ કરો.', selectDate:'⚠️ કૃપા કરીને પહેલા તારીખ પસંદ કરો.', orderCancelled:'✅ તમારો ઓર્ડર કૅન્સલ થઈ ગયો.', resetLinkBad:'❌ આ રીસેટ લિંક અમાન્ય અથવા સમાપ્ત થઈ ગઈ છે.', confirmCancel:'આ ઓર્ડર કૅન્સલ કરવો છે?', welcomeUser:'🎉 સ્વાગત છે,', errLogin:'આગળ વધવા માટે સાઇન ઇન કરો.',
      tagline:'તાજું • ઘરનું બનાવેલું • ડોરસ્ટેપ ડિલિવરી', secureLogin:'🔐 સુરક્ષિત લોગિન', signInTitle:'ફરી સ્વાગત છે', emailLabel:'ઈમેલ', passwordLabel:'પાસવર્ડ', passwordPh:'તમારો પાસવર્ડ દાખલ કરો', passwordPh6:'ઓછામાં ઓછા 6 અક્ષર', confirmPwLabel:'પાસવર્ડ કન્ફર્મ કરો', confirmPwPh:'પાસવર્ડ ફરીથી દાખલ કરો', errEmail:'સાચું ઈમેલ સરનામું દાખલ કરો.', errPassword:'તમારો પાસવર્ડ દાખલ કરો.', errPassword6:'પાસવર્ડ ઓછામાં ઓછા 6 અક્ષરનો હોવો જોઈએ.', errConfirmPw:'પાસવર્ડ મેચ થતો નથી.', forgotPw:'પાસવર્ડ ભૂલી ગયા?', signInBtn:'સાઇન ઇન કરો', signUpTitle:'એકાઉન્ટ બનાવો', signUpSub:'રોજનું ટિફિન ઓર્ડર કરવા સાઇન અપ કરો.', phoneDeliveryHint:'ડિલિવરી સંપર્ક માટે વપરાશે.', createAccountBtn:'એકાઉન્ટ બનાવો', switchToSignUp:'એકાઉન્ટ નથી? <b onclick="showAuthMode(\'signup\')">સાઇન અપ કરો</b>', switchToSignIn:'પહેલેથી એકાઉન્ટ છે? <b onclick="showAuthMode(\'signin\')">સાઇન ઇન કરો</b>', backToSignIn:'← સાઇન ઇન પર પાછા', forgotTitle:'પાસવર્ડ રીસેટ કરો', forgotSub:'તમારું ઈમેલ દાખલ કરો, અમે રીસેટ લિંક મોકલીશું.', sendResetBtn:'રીસેટ લિંક મોકલો', resetTitle:'નવો પાસવર્ડ સેટ કરો', resetSub:'તમારા એકાઉન્ટ માટે નવો પાસવર્ડ પસંદ કરો.', newPasswordLabel:'નવો પાસવર્ડ', resetBtn:'પાસવર્ડ રીસેટ કરો', orDivider:'અથવા', resetLinkSent:'જો આ ઈમેલ રજિસ્ટર્ડ છે, રીસેટ લિંક મોકલી દેવાઈ છે.', passwordResetDone:'પાસવર્ડ અપડેટ થયો — હવે સાઇન ઇન કરી શકો છો.',
      loginTitle:'લોગિન અથવા સાઇન અપ', mobileLabel:'મોબાઇલ નંબર', mobilePh:'10 અંકનો મોબાઇલ નંબર દાખલ કરો',
      continueBtn2:'આગળ વધો', loginHint:'તમારું Google એકાઉન્ટ પસંદ કરો.', phoneFirstHint:'ફક્ત પહેલી વાર જરૂરી — ડિલિવરી સંપર્ક માટે.', completeSignup:'✓ સાઇન અપ પૂર્ણ કરો',
      verifyTitle:'એક છેલ્લું પગલું', googleWelcome:'✅ Google થી સાઇન ઇન થયું. ડિલિવરી સંપર્ક માટે મોબાઇલ નંબર દાખલ કરો.', nameLabel:'તમારું નામ', namePh:'તમારું પૂરું નામ લખો',
      otpLabel:'વેરિફિકેશન કોડ દાખલ કરો', verifyBtn:'વેરિફાય કરો', changeNum:'બીજું Google એકાઉન્ટ વાપરો', errName:'સાચું નામ દાખલ કરો (ફક્ત અક્ષરો).', errPhone:'સાચો 10 અંકનો મોબાઇલ નંબર દાખલ કરો.', errPickGoogle:'પહેલા Google બટન દબાવીને એકાઉન્ટ પસંદ કરો.',
      badgeFresh:'🌿 ફ્રોઝન નહીં', badgeCustom:'🍳 કસ્ટમાઇઝેબલ', badgeCOD:'💵 કેશ ઓન ડિલિવરી',
      freshStrip:'🌿 એકદમ તાજું: તમારું ભોજન ઓર્ડર પછી જ બને છે — ન ફ્રોઝન, ન વાસી.',
      deliveryDate:'📅 ડિલિવરી તારીખ',
      cutoffNote:'🕒 ઓર્ડર કટ-ઓફ સમય (IST)\n• નાસ્તો — એક રાત પહેલા 10:00 PM સુધી\n• લંચ — તે જ દિવસે 9:00 AM સુધી\n• ડિનર — તે જ દિવસે 3:00 PM સુધી\nકટ-ઓફ પછી આગલા ઉપલબ્ધ દિવસ માટે ઓર્ડર કરો.',
      selectMeals:'🍽️ તમારા મીલ પસંદ કરો', yourCart:'🛒 તમારી કાર્ટ', clearCart:'ખાલી કરો', cartEmpty:'કાર્ટ ખાલી છે. ઉપરથી મીલ ઉમેરો.',
      myOrders:'📋 મારા ઓર્ડર', refresh:'🔄 રિફ્રેશ', viewPast:'🗓️ જૂની તારીખના ઓર્ડર જુઓ', view:'જુઓ',
      cartTotal:'કુલ રકમ', checkout:'ચેકઆઉટ →', viewCart:'કાર્ટ જુઓ →', logout:'લોગઆઉટ',
      checkoutTitle:'📦 ડિલિવરી વિગતો', checkoutSub:'છેલ્લું પગલું — ઓર્ડર કન્ફર્મ કરો', backMenu:'← મેન્યુ પર પાછા',
      autofillNote:'✓ તમારું સાચવેલ સરનામું ઓટો-ફિલ થયું', township:'🏢 ટાઉનશિપ', society:'🏘️ સોસાયટી', flat:'🏠 ફ્લેટ નંબર',
      fullName:'👤 પૂરું નામ', verifiedMobile:'📱 મોબાઇલ નંબર (વેરિફાઇડ ✓)', payMethod:'💰 ચુકવણી પદ્ધતિ',
      payCOD:'💵 કેશ ઓન ડિલિવરી', payCODsub:'ટિફિન મળે ત્યારે કેશ આપો', payUPI:'💳 ઓનલાઇન ચુકવણી (UPI)', payUPIsub:'ઓર્ડર કરતાં જ QR કોડ મળશે', codNote:'કેશ ઓન ડિલિવરી — ટિફિન મળે ત્યારે ચૂકવો.',
      errSociety:'તમારી સોસાયટી પસંદ કરો.', errFlat:'કૃપા કરીને બ્લોક અને ફ્લેટ નંબર દાખલ કરો, દા.ત. D-706.',
      placeOrder:'📤 ઓર્ડર કરો', successTitle:'ઓર્ડર કન્ફર્મ થયો', promoHave:'કૂપન કોડ છે? અહીં દાખલ કરો', promoApply:'લાગુ કરો', promoApplied:'લાગુ થયો', discountLbl:'ડિસ્કાઉન્ટ', promoFirstDateNote:'(પ્રથમ ડિલિવરી તારીખ પર લાગુ)', promoEditNote:'ડિસ્કાઉન્ટવાળા ઓર્ડર એડિટ થઈ શકતા નથી — કૅન્સલ કરીને નવો ઓર્ડર કરો.', promoUseAtCheckout:'કાર્ટમાં કોડ પર ટૅપ કરીને લાગુ કરો', promoNewTag:'નવા ગ્રાહકો', policyTitle:'કૅન્સલેશન અને રિફંડ નીતિ', policyBody:'• ઓર્ડર ડિલિવરીની આગલી રાત્રે 10:00 PM સુધી કૅન્સલ થઈ શકે છે. તે પછી કરેલા ઓર્ડર, ઓર્ડર કર્યાની 30 મિનિટમાં કૅન્સલ થઈ શકે છે. ઓર્ડર એડિટ થઈ શકતો નથી — કૅન્સલ કરીને નવો ઓર્ડર કરો.<br>• જો તમે UPI થી ઓનલાઇન ચુકવણી કરી હોય અને ઓર્ડર કૅન્સલ થાય — ભલે તમે માન્ય સમયમાં કર્યો હોય કે અમે કોઈ કારણસર — પૂરી રકમ 24 કલાકમાં એ જ UPI ખાતામાં રિફંડ થાય છે.<br>• કૂપન ડિસ્કાઉન્ટવાળા ઓર્ડર એડિટ થઈ શકતા નથી; કૃપા કરીને કૅન્સલ કરીને નવો ઓર્ડર કરો.<br>• ભોજનમાં કોઈ સમસ્યા? ડિલિવરીના 2 કલાકમાં ફોટા સાથે WhatsApp કરો — અમે રિપ્લેસમેન્ટ કે પૂરો રિફંડ આપીશું.<br>• સપોર્ટ: 📞 +91 99249 37939 (WhatsApp ઉપલબ્ધ).', waFallback:'ઓર્ડર WhatsApp પર શેર કરો (optional) →', newOrder:'નવો ઓર્ડર કરો', trackOrderBtn:'ઓર્ડર ટ્રૅક કરો', successConfirmNote:'તમારો ઓર્ડર કન્ફર્મ થઈ ગયો છે. તમે તેને ગમે ત્યારે My Orders સેક્શનમાં જોઈ અને ટ્રૅક કરી શકો છો.',
      addToCart:'🛒 કાર્ટમાં ઉમેરો', addedShort:'કાર્ટમાં ઉમેરાયું', addToCart2:'ઉમેરો', payNowUpi:'ઓનલાઇન ચુકવણી', payRefLbl:'પેમેન્ટ રેફરન્સ', srv_dup_date:'આ તારીખનો ઓર્ડર પહેલેથી છે.', srv_qty_limit:'એક દિવસમાં દરેક મીલનું માત્ર 1 ટિફિન. વધુ માટે કિચનનો સંપર્ક કરો.', srv_cancel_window:'આ ઓર્ડરની કેન્સલેશન વિન્ડો બંધ થઈ ગઈ છે.', srv_already_cancelled:'આ ઓર્ડર પહેલેથી કૅન્સલ છે.', srv_cancel_delivered:'ડિલિવર થયેલો ઓર્ડર કૅન્સલ થઈ શકે નહીં.', srv_not_yours:'આ ઓર્ડર તમારા એકાઉન્ટનો નથી.', srv_no_meal:'ઓર્ડર ખાલી છે — ઓછામાં ઓછું એક મીલ પસંદ કરો.', srv_office_off:'ઓફિસ ડિલિવરી હમણાં ઉપલબ્ધ નથી.', srv_home_off:'હોમ ડિલિવરી હમણાં ઉપલબ્ધ નથી.', srv_company_req:'કૃપા કરીને લિસ્ટમાંથી તમારી કંપની પસંદ કરો.', srv_empid_req:'એમ્પ્લોયી ID જરૂરી છે.', srv_blocked:'તમારું એકાઉન્ટ બ્લોક છે. સપોર્ટ: 99249 37939', srv_wrong_pw:'પાસવર્ડ ખોટો છે.', srv_no_account:'આ ઇમેઇલથી કોઈ એકાઉન્ટ મળ્યું નથી.', srv_email_exists:'આ ઇમેઇલથી એકાઉન્ટ પહેલેથી છે — સાઇન ઇન કરો.', srv_phone_taken:'આ મોબાઇલ નંબર બીજા એકાઉન્ટ સાથે જોડાયેલો છે.', srv_use_google:'આ એકાઉન્ટ Google Sign-In નું છે — "Sign in with Google" વાપરો.', srv_reset_sent:'જો આ ઇમેઇલ રજિસ્ટર્ડ છે, તો રીસેટ લિંક મોકલી છે.', srv_reset_bad:'આ રીસેટ લિંક અમાન્ય અથવા સમાપ્ત છે.', srv_reset_expired:'રીસેટ લિંક સમાપ્ત થઈ — નવી વિનંતી કરો.', scanToPay:'કોઈપણ UPI એપથી QR સ્કૅન કરો', copyId:'કૉપિ', pleaseWait:'એક ક્ષણ…', cancelWindowOver:'આ ઓર્ડરની કેન્સલેશન વિન્ડો બંધ થઈ ગઈ છે. કોઈપણ મદદ માટે કિચનનો સંપર્ક કરો.', limitTitle:'એક મીલનું એક ટિફિન', limitBody:'દરેક ગ્રાહક એક દિવસમાં 1 નાસ્તો, 1 લંચ અને 1 ડિનર ઓર્ડર કરી શકે છે. વધુ જથ્થા માટે કૃપા કરીને કિચનનો સંપર્ક કરો — અમે ખુશીથી ગોઠવી આપીશું.', limitCta:'કિચનનો સંપર્ક કરો', limitClose:'સમજાયું', subtotalLbl:'સબટોટલ', deliveryLbl:'ડિલિવરી', infoStripText:'ઓર્ડર સમય — નાસ્તો: આગલી રાત્રે 10 PM સુધી · લંચ: 9 AM સુધી · ડિનર: 3 PM સુધી', subPushLine:'રોજ ઓર્ડર કરો છો? સબ્સ્ક્રિપ્શન સેટ કરો', reorderBtn:'ફરી ઓર્ડર કરો', reorderDone:'આઇટમ તમારા કાર્ટમાં ઉમેરાયા', reorderNoSlot:'આ મીલ આગામી 3 દિવસ ઉપલબ્ધ નથી', lpTagline:'રોજ તાજું, ઘર જેવું ભોજન — સીધું તમારા ડોરસ્ટેપ સુધી.', lpOrderNow:'ઓર્ડર કરો', lpTodays:'આજના મીલ', lpOpen:'ઉપલબ્ધ', lpClosed:'બંધ', lpWhy:'Flying Birds જ કેમ', lpU1t:'રોજ તાજા બેચ', lpU1s:'દરરોજ નાના બેચમાં બને છે — ક્યારેય સ્ટોર કે ફ્રોઝન નહીં.', lpU2t:'ઘર જેવી સામગ્રી', lpU2s:'તાજા દળેલા મસાલા — કોઈ પેકેટ મિક્સ નહીં.', lpU3t:'સુરક્ષિત પેકેજિંગ', lpU3s:'દરેક મીલ સર્ટિફાઇડ ફૂડ-ગ્રેડ કન્ટેનરમાં.', lpSubT:'ડેઇલી ટિફિન સબ્સ્ક્રિપ્શન', lpSubS:'એક વાર સેટ કરો — ટિફિન રોજ આપોઆપ આવશે.', lpHow:'કેવી રીતે કામ કરે છે', lpH1:'મીલ પસંદ કરો અને કસ્ટમાઇઝ કરો', lpH2:'ડિલિવરી તારીખ અને સમય પસંદ કરો', lpH3:'ઓનલાઇન અથવા ડિલિવરી પર ચૂકવો', pubLogin:'લૉગિન', pubBack:'← પાછા', dtypeQ:'ડિલિવરી ક્યાં જોઈએ?', modeTitle:'ટિફિન ક્યાં જોઈએ?', modeSub:'એક વાર પસંદ કરો — ગમે ત્યારે બદલી શકો છો.', modeChange:'બદલો', dtHome:'ઘર', dtHomeSub:'સોસાયટી / ફ્લેટ', dtOffice:'ઓફિસ', dtOfficeSub:'કંપની / એમ્પ્લોયી', companyLbl:'તમારી કંપની પસંદ કરો', companyHint:'કંપની લિસ્ટમાં નથી? કિચનનો સંપર્ક કરો — અમે ઉમેરી દઈશું.', empIdLbl:'એમ્પ્લોયી ID', errCompany:'કૃપા કરીને તમારી કંપની પસંદ કરો', errEmpId:'કૃપા કરીને એમ્પ્લોયી ID દાખલ કરો', pubCta:'મેનૂ જુઓ અને ઓર્ડર કરો', pubCutoffLine:'લંચ બંધ <b>9:00 AM</b> · ડિનર <b>3:00 PM</b>', pubHookQ:'શું હેલ્ધી ભોજન ખરેખર <em>20-મિનિટ ડિલિવરી</em>માં બની શકે?', pubHookA:'ના બની શકે. આટલું ઝડપી આવતું ભોજન <b>તમારા ઓર્ડર પહેલાં જ બનેલું હોય છે</b> — ફરી ગરમ કરીને મોકલાય છે.', cmpUs:'અમારું કિચન', cmpThem:'ડિલિવરી એપ્સ', cmpU1:'ઘરે દળેલા તાજા મસાલા', cmpT1:'બલ્ક પેકેટ મસાલા', cmpU2:'રોજ નવું તેલ', cmpT2:'એ જ તેલ આખો દિવસ', cmpU3:'રોજ મર્યાદિત ઓર્ડર', cmpT3:'અનલિમિટેડ, બલ્ક કુકિંગ', cmpU4:'એ જ રસોઇયો, એ જ સ્વાદ', cmpT4:'દર વખતે અલગ કિચન', cmpU5:'ફિક્સ ભાવ, કોઈ એક્સ્ટ્રા નહીં', cmpT5:'સર્જ + પ્લેટફોર્મ ફી', cmpU6:'હલકું, રોજનું ભોજન', cmpT6:'ભારે રેસ્ટોરન્ટ ફૂડ', cmpU7:'કિચન જે તમે જોઈ શકો', cmpT7:'કિચન જે ક્યારેય નહીં દેખાય', cmpQualT:'ક્વોલિટી, ક્વોન્ટિટી નહીં.', cmpQualS:'અમે રોજના ઓર્ડર મર્યાદિત રાખીએ છીએ અને માત્ર એક ટાઉનશિપ સર્વ કરીએ છીએ — જેથી દરેક ટિફિનને પૂરો સમય મળે.', cmpChip:'📍 માત્ર Godrej Garden City માટે', lpPosT:'આ ફટાફટ-ડિલિવરી એપ નથી', lpPosS:'આ તમારું રોજનું કિચન છે — planned, તાજું અને હંમેશા સમયસર.', lpPos1:'Fixed time slots પર ડિલિવરી — 10-મિનિટવાળી રેસ નહીં.', lpPos2:'હલકું, પોષણભર્યું ઘર જેવું ભોજન — રેસ્ટોરન્ટનું ભારે તેલ-મસાલા નહીં.', lpPos3:'સીધા fixed ભાવ — ના surge, ના hidden કે platform charges.', lpPos4:'રોજ એક જ ભરોસાપાત્ર કિચન — દરેક ટિફિનમાં એ જ અપનાપણ.', navMenuShort:'મેનૂ', navProfileShort:'પ્રોફાઇલ', pfTitle:'👤 મારી પ્રોફાઇલ', pfAddr:'સેવ કરેલું સરનામું', pfFlatLbl:'ફ્લેટ / બ્લોક નં.', pfSave:'સરનામું સેવ કરો', addrSaved:'સરનામું સેવ થયું', pfQuick:'ક્વિક લિંક', pfLang:'ભાષા', payWithUpiBtn:'ચુકવણી કરો', orScan:'અથવા QR કોડ સ્કૅન કરો', upiPayNote:'🔒 UPI થી સુરક્ષિત ચુકવણી. રકમ પહેલેથી ભરેલી છે — બસ તમારી UPI એપમાં અપ્રૂવ કરો.', copied:'UPI ID કૉપિ થઈ', updateCart:'✓ કાર્ટ અપડેટ કરો', addedToCart:'કાર્ટમાં ઉમેરાયું', customizable:'કસ્ટમાઇઝેબલ', chooseSize:'સાઇઝ પસંદ કરો', sizeRequired:'જરૂરી · કોઈ 1 પસંદ કરો', addOns:'એડ-ઓન', dahiShort:'દહીં', extraSabziShort:'એક્સ્ટ્રા શાક', freshCookedDesc:'રોજ નાના બેચમાં તાજું બને છે — ક્યારેય સ્ટોર કે ફ્રોઝન નહીં.', selectSabzi:'શાક પસંદ કરો', rotiType:'રોટી પ્રકાર', plain:'પ્લેન', butter:'બટર', deliveryTime:'⏰ ડિલિવરી સમય', tiffinType:'🍱 તમારું ટિફિન પસંદ કરો', miniTiffin:'મિની ટિફિન', fullTiffin:'ફુલ ટિફિન',
      extraRoti:'એક્સ્ટ્રા રોટી', addDahi:'દહીં ઉમેરો', extraSabzi:'એક્સ્ટ્રા શાક', howMany:'કેટલા ટિફિન?', unitPrice:'યુનિટ ભાવ',
      perTiffin:'/ ટિફિન', specialInstr:'📝 ખાસ સૂચનાઓ (વૈકલ્પિક)', notePh:'દા.ત. ઓછું તીખું, ડુંગળી વગર...',
      backApp:'← એપ પર પાછા', remove:'દૂર કરો', cancelOrder:'✖ રદ કરો', editOrder:'બદલો', editLoaded:'ઓર્ડર લોડ થયો — ફેરફાર કરીને ચેકઆઉટ કરો',
      closedBreakfast:'સેમ-ડે બ્રેકફાસ્ટ ઉપલબ્ધ નથી — એક દિવસ પહેલા ઓર્ડર કરો.', kitchenClosedMsg:'આ તારીખે કિચન બંધ છે — બીજી તારીખ પસંદ કરો.', happyCustomers:'ખુશ ગ્રાહકોએ ઓર્ડર કર્યો', orderedForThisMeal:'ટિફિન અત્યાર સુધી ઓર્ડર થયા', beingPrepared:'હમણાં બની રહ્યા છે', onlyLeftToday:'આજ માટે ફક્ત {n} ઉપલબ્ધ છે', soldOutToday:'આજ માટે સોલ્ડ આઉટ', soldOutTitle:'આ મીલના સ્લોટ ભરાઈ ગયા', soldOutSub:'દરેક ટિફિન તાજું રાખવા અમે મર્યાદિત જથ્થામાં જ બનાવીએ છીએ. બીજું મીલ કે દિવસ પસંદ કરો.',
      closedLunch:'આજના લંચનું બુકિંગ બંધ (9:00 AM સુધી હતું).',
      closedDinner:'આજના ડિનરનું બુકિંગ બંધ (3:00 PM સુધી હતું).', closedBkTom:'આવતીકાલના બ્રેકફાસ્ટનું બુકિંગ બંધ (ગઈકાલે રાત્રે 10:00 PM સુધી હતું).',
      closedTomorrow:'આવતીકાલનું બુકિંગ બંધ (10:00 PM સુધી હતું).',
      cancelClosed:'રદ કરવાની સમયમર્યાદા પૂરી થઈ ગઈ છે.',
      dupMsg:'આ તારીખ માટે ઓર્ડર પહેલેથી છે. ફેરફાર માટે સ્ટોર સપોર્ટને કૉલ કરો: 99249 37939.',
      noUpcoming:'હમણાં કોઈ આગામી ઓર્ડર નથી. મેનૂમાંથી મીલ ઉમેરીને ઓર્ડર કરો.', noHistory:'આ તારીખે કોઈ ઓર્ડર મળ્યો નથી.', navHome:'હોમ', navCart:'કાર્ટ', navPast:'જૂના ઓર્ડર', navAbout:'અમારા વિશે', navSub:'સબ્સ્ક્રિપ્શન', navHomeShort:'હોમ', navCartShort:'કાર્ટ', navSubShort:'સબ્સ્ક્રાઇબ', navOrdersShort:'ઓર્ડર', subTitle:'🔁 સબ્સ્ક્રિપ્શન', subSub:'એક વાર સેટ કરો — તમારું ડેઇલી ટિફિન આપોઆપ ઓર્ડર થઈ જશે.', subActive:'ચાલુ પ્લાન', subDaysWeek:'દિવસ/અઠવાડિયું', subSkipped:'સ્કિપ કર્યા', subSkipBtn:'દિવસ સ્કિપ કરો', subCancelBtn:'પ્લાન રદ કરો', subEditNote:'નીચે બદલીને અપડેટ દબાવો', subPickMeals:'મીલ પસંદ કરો', subPickDays:'દિવસ પસંદ કરો', subWeekdays:'સોમ–શુક્ર', subAllDays:'સાતેય દિવસ', subClear:'સાફ', subDateRange:'તારીખ રેન્જ', subStart:'શરૂ', subEnd:'અંત', subDelivery:'ડિલિવરી', subUpdate:'પ્લાન અપડેટ', subStart2:'સબ્સ્ક્રિપ્શન શરૂ', subAnySabzi:'શેફની પસંદ', subSaved:'સબ્સ્ક્રિપ્શન સફળતાપૂર્વક સેવ થયું.', subCancelled:'સબ્સ્ક્રિપ્શન રદ થયું', subCancelConfirm:'સબ્સ્ક્રિપ્શન રદ કરો?', subSkipDone:'દિવસ સ્કિપ થયો', subUnskipDone:'સ્કિપ દૂર', subPickSkipDate:'સ્કિપ માટે તારીખ પસંદ કરો', subEndAfter:'એન્ડ ડેટ સ્ટાર્ટ પછી હોવી જોઈએ', subStartInfo:'કાલથી આગળ', navContact:'સંપર્ક કરો', contactTitle:'📞 સંપર્ક કરો', contactSub:'તમારી વાત સાંભળવી અમને ગમે છે', contactInfoTitle:'ℹ️ માહિતી', contactAddrLbl:'લોકેશન', contactAreaLbl:'ડિલિવરી વિસ્તાર', contactHoursLbl:'ડિલિવરી સમય',
      aboutTitle:'ℹ️ અમારા વિશે', aboutSub:'અમારું ટિફિન કેમ અલગ છે', aboutSwipe:'← વધુ જોવા માટે સ્વાઇપ કરો →',
      aboutContact:'📞 કોઈ સવાલ? અમે એક કોલ દૂર છીએ.'
    }
  };
  let LANG = 'en';
  function t(k) { return (T[LANG] && T[LANG][k]) || T.en[k] || k; }

  // ═══════ ABOUT US SLIDES ═══════
  const ABOUT_BG = ['var(--accent)','var(--ok)','linear-gradient(135deg,#f7971e,#ffd200)','linear-gradient(135deg,#2193b0,#6dd5ed)','linear-gradient(135deg,#eb3349,#f45c43)'];
  const ABOUT = {
    en: [
      { icon:'🍲', title:'Fresh Batches, Every Single Day', body:'We cook in small batches each morning with same-day ingredients — no frozen stock, no leftovers carried forward. Your tiffin leaves the kitchen within minutes of being prepared.' },
      { icon:'🌿', title:'No Packet Masala', body:'We use fresh, home-style ground spices — never ready-made packet masala. Real ingredients, real taste, every single day.' },
      { icon:'🧼', title:'Cleaned After Every Meal', body:'Our kitchen is cleaned after every service — after breakfast, after lunch, and after dinner. A fresh, hygienic start, three times a day.' },
      { icon:'📦', title:'Food-Grade Packaging Only', body:'Every meal is packed only in certified food-grade containers — never cheap or low-quality plastic. Your health matters more than saving a few rupees.' },
      { icon:'⏱️', title:'Real Fresh Takes Time', body:'Any app promising hot, fresh food in 15–20 minutes is worth a second thought — proper cooking simply can\'t happen that fast. Food delivered that quickly is almost always pre-cooked, frozen, or reheated — which can add up to real health issues over time. We\'d rather take a little longer and get it right.' }
    ],
    hinglish: [
      { icon:'🍲', title:'Har Din Taaze Batches', body:'Hum roz subah ke ingredients se chhote batches mein pakate hain — na frozen stock, na kal ka bacha hua khana. Aapka tiffin banne ke kuch hi minute mein kitchen se nikal jaata hai.' },
      { icon:'🌿', title:'Packet Masala Nahi', body:'Hum sirf taaza, ghar jaise pise hue spices use karte hain — kabhi bhi ready packet masala nahi. Asli ingredients, asli swaad, har din.' },
      { icon:'🧼', title:'Har Meal Ke Baad Safai', body:'Hamari kitchen har service ke baad saaf hoti hai — breakfast ke baad, lunch ke baad, aur dinner ke baad. Din mein teen baar ek fresh, hygienic shuruaat.' },
      { icon:'📦', title:'Sirf Food-Grade Packaging', body:'Har khana hum sirf certified food-grade containers mein pack karte hain — kabhi cheap ya low-quality plastic nahi. Aapki health hamare liye kuch rupaye bachane se zyada important hai.' },
      { icon:'⏱️', title:'Asli Fresh Khana Time Leta Hai', body:'Koi bhi app jo 15–20 minute mein garam, fresh khana dene ka wada kare — ek baar zaroor sochiye, itni jaldi proper khana banna possible nahi hai. Jo khana itni fast pahunchta hai, wo zyadatar pehle se bana, frozen, ya reheat kiya hua hota hai — jo lambe samay mein health issues bhi de sakta hai. Hum thoda time lete hain, lekin sahi tareeke se.' }
    ],
    hi: [
      { icon:'🍲', title:'हर दिन ताज़े बैच', body:'हम रोज़ सुबह की सामग्री से छोटे बैच में पकाते हैं — न फ़्रोज़न स्टॉक, न कल का बचा खाना। आपका टिफ़िन बनने के कुछ ही मिनट में किचन से निकल जाता है।' },
      { icon:'🌿', title:'पैकेट मसाला नहीं', body:'हम सिर्फ़ ताज़े, घर जैसे पिसे हुए मसाले इस्तेमाल करते हैं — कभी भी रेडी पैकेट मसाला नहीं। असली सामग्री, असली स्वाद, हर दिन।' },
      { icon:'🧼', title:'हर मील के बाद सफ़ाई', body:'हमारी किचन हर सर्विस के बाद साफ़ होती है — नाश्ते के बाद, लंच के बाद, और डिनर के बाद। दिन में तीन बार एक ताज़ी, स्वच्छ शुरुआत।' },
      { icon:'📦', title:'सिर्फ़ फ़ूड-ग्रेड पैकेजिंग', body:'हर खाना हम सिर्फ़ सर्टिफ़ाइड फ़ूड-ग्रेड कंटेनर में पैक करते हैं — कभी सस्ता या कम क्वालिटी वाला प्लास्टिक नहीं। आपकी सेहत हमारे लिए कुछ रुपये बचाने से ज़्यादा ज़रूरी है।' },
      { icon:'⏱️', title:'असली ताज़ा खाना समय लेता है', body:'कोई भी ऐप जो 15–20 मिनट में गरम, ताज़ा खाना देने का वादा करे — एक बार ज़रूर सोचिए, इतनी जल्दी सही तरीके से खाना बनना संभव नहीं है। जो खाना इतनी तेज़ी से पहुँचता है, वो ज़्यादातर पहले से बना, फ़्रोज़न, या दोबारा गरम किया हुआ होता है — जो लंबे समय में सेहत की समस्याएँ दे सकता है। हम थोड़ा समय लेते हैं, लेकिन सही तरीके से।' }
    ],
    gu: [
      { icon:'🍲', title:'દરરોજ તાજા બેચ', body:'અમે રોજ સવારની સામગ્રીથી નાના બેચમાં રાંધીએ છીએ — ના ફ્રોઝન સ્ટોક, ના ગઈકાલનું બચેલું. તમારું ટિફિન બન્યાની થોડી જ મિનિટમાં કિચનમાંથી નીકળી જાય છે.' },
      { icon:'🌿', title:'પેકેટ મસાલા નહીં', body:'અમે ફક્ત તાજા, ઘર જેવા દળેલા મસાલા વાપરીએ છીએ — ક્યારેય રેડી પેકેટ મસાલા નહીં. સાચી સામગ્રી, સાચો સ્વાદ, રોજ.' },
      { icon:'🧼', title:'દરેક મીલ પછી સફાઈ', body:'અમારી કિચન દરેક સર્વિસ પછી સાફ થાય છે — નાસ્તા પછી, લંચ પછી, અને ડિનર પછી. દિવસમાં ત્રણ વાર એક તાજી, સ્વચ્છ શરૂઆત.' },
      { icon:'📦', title:'ફક્ત ફૂડ-ગ્રેડ પેકેજિંગ', body:'દરેક ભોજન અમે ફક્ત સર્ટિફાઇડ ફૂડ-ગ્રેડ કન્ટેનરમાં પેક કરીએ છીએ — ક્યારેય સસ્તું કે નબળી ક્વોલિટીનું પ્લાસ્ટિક નહીં. તમારું સ્વાસ્થ્ય અમારા માટે થોડા રૂપિયા બચાવવા કરતાં વધુ મહત્વનું છે.' },
      { icon:'⏱️', title:'સાચું તાજું ભોજન સમય લે છે', body:'કોઈ પણ એપ જે 15–20 મિનિટમાં ગરમ, તાજું ભોજન આપવાનું વચન આપે — એક વાર જરૂર વિચારો, આટલી ઝડપથી યોગ્ય રીતે ભોજન બનવું શક્ય નથી. જે ભોજન આટલી ઝડપથી પહોંચે છે, તે મોટે ભાગે પહેલેથી બનેલું, ફ્રોઝન, અથવા ફરી ગરમ કરેલું હોય છે — જે લાંબા ગાળે સ્વાસ્થ્ય સમસ્યાઓ પણ આપી શકે છે. અમે થોડો સમય લઈએ છીએ, પણ યોગ્ય રીતે.' }
    ]
  };
  function renderAbout(){
    const box=document.getElementById('aboutSlides'); if(!box)return;
    const slides=ABOUT[LANG]||ABOUT.en;
    box.innerHTML=slides.map((s,i)=>`<div class="about-slide" style="background:${ABOUT_BG[i%ABOUT_BG.length]}">
      <div class="as-icon">${s.icon}</div><h3>${s.title}</h3><p>${s.body}</p>
    </div>`).join('');
    const ca=document.getElementById('ctAddr'); if(ca) ca.innerHTML=(CFG.township||'Godrej Garden City')+',<br>Ahmedabad';
    const cr=document.getElementById('ctArea'); if(cr) cr.textContent=(CFG.societies||[]).join(' · ');
    const pb=document.getElementById('policyBox');
    if(pb) pb.innerHTML=`<div class="policy-t">📄 ${t('policyTitle')}</div><div class="policy-b">${t('policyBody')}</div>`;
  }

  function setLang(l) {
    if (!T[l]) l = 'en';
    LANG = l;
    try { localStorage.setItem('fbt_lang', l); } catch(e){}
    document.documentElement.lang = (l === 'hinglish' ? 'en' : l);
    document.getElementById('langSel').value = l;
    document.getElementById('langSelAuth').value = l;
    applyLang();
  }
  function applyLang() {
    document.querySelectorAll('[data-i]').forEach(el => { el.textContent = t(el.getAttribute('data-i')); });
    document.querySelectorAll('[data-i-html]').forEach(el => { el.innerHTML = t(el.getAttribute('data-i-html')); });
    document.querySelectorAll('[data-ph]').forEach(el => { el.placeholder = t(el.getAttribute('data-ph')); });
    if (SESSION && SESSION.name) document.getElementById('profileName').textContent = '👤 ' + SESSION.name;
    renderDateSelector(); renderMealTabs(); renderMenuDateTime(); renderMealPanel(); renderCart(); renderAbout(); renderHome(); renderProfile();
    if (isLoggedIn()) loadMyOrders();
  }
  function initLangSelectors() {
    ['langSel','langSelAuth'].forEach(id => {
      document.getElementById(id).innerHTML = Object.keys(LANGS).map(k => `<option value="${k}">${LANGS[k]}</option>`).join('');
    });
  }

  // ═══════ IST TIME ═══════
  let __istOverride = null;
  function getISTNow() {
    if (__istOverride) return new Date(__istOverride);
    try { return new Date(new Date().toLocaleString('en-US', { timeZone:'Asia/Kolkata' })); } catch(e){ return new Date(); }
  }
  function dateWithOffset(off){ const n=getISTNow(); return new Date(n.getFullYear(),n.getMonth(),n.getDate()+off); }
  function dateWithOffsetStr(off){ return fmtYMD(dateWithOffset(off)); }
  function fmtYMD(d){ const p=x=>String(x).padStart(2,'0'); return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate()); }
  const WEEKDAYS=['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
  function weekdayKey(d){ return WEEKDAYS[d.getDay()]; }
  function fmtLabel(d){ const dd=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],mo=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']; return dd[d.getDay()]+', '+String(d.getDate()).padStart(2,'0')+' '+mo[d.getMonth()]; }

  function mealsAvail(off) {
    const n=getISTNow(); const mins=n.getHours()*60+n.getMinutes();
    const A=(ok,why)=>({ok:ok,why:why||''});
    const dstr=fmtYMD(dateWithOffset(off));
    if((CFG.closedDates||[]).indexOf(dstr)>=0){
      const closedMsg=t('kitchenClosedMsg');
      return { breakfast:A(false,closedMsg), lunch:A(false,closedMsg), dinner:A(false,closedMsg) };
    }
    // Per-meal cutoff (IST), applies to the delivery day:
    //  Breakfast: order by 10:00 PM the night before (never same-day)
    //  Lunch:     order by 9:00 AM on delivery day
    //  Dinner:    order by 3:00 PM on delivery day
    if (off===0) return {
      breakfast: A(false, t('closedBreakfast')),
      lunch:  mins<540 ? A(true) : A(false, t('closedLunch')),
      dinner: mins<900 ? A(true) : A(false, t('closedDinner'))
    };
    if (off===1) return {
      breakfast: mins<1320 ? A(true) : A(false, t('closedBkTom')),
      lunch:  A(true),
      dinner: A(true)
    };
    return { breakfast:A(true), lunch:A(true), dinner:A(true) };
  }
  function anyAvail(off){ const a=mealsAvail(off); return a.breakfast.ok||a.lunch.ok||a.dinner.ok; }
  function canCancel(oOrD){
    const dstr = (typeof oOrD==='object'&&oOrD) ? oOrD.deliveryDate : oOrD;
    const p=String(dstr).split('-').map(Number); if(p.length!==3||!p[0])return false;
    if(getISTNow()<=new Date(p[0],p[1]-1,p[2]-1,22,0,0)) return true;
    // 30-min grace after placing (raat 10PM ke baad / same-day wale orders)
    if(typeof oOrD==='object'&&oOrD&&oOrD.createdIso){
      const c=new Date(oOrD.createdIso);
      if(!isNaN(c.getTime()) && (Date.now()-c.getTime())<=30*60000) return true;
    }
    return false;
  }
  function offsetOfDate(dstr){ const today=fmtYMD(dateWithOffset(0)); for(let o=0;o<=2;o++){ if(fmtYMD(dateWithOffset(o))===dstr) return o; } return today>dstr?-1:3; }

  // ═══════ STATE ═══════
  const MEALS=['breakfast','lunch','dinner'];
  const MEAL_META={ breakfast:{emoji:'🌅',title:'Breakfast',time:'7–9 AM',img:'images/breakfast.jpg'}, lunch:{emoji:'☀️',title:'Lunch',time:'12–2 PM',img:'images/lunch.jpg'}, dinner:{emoji:'🌙',title:'Dinner',time:'7–9 PM',img:'images/dinner.jpg'} };
  // Default (placeholder) images — asli photo na hone tak cards inhe dikhate hain
  const DEFAULT_IMG={ breakfast:'images/breakfast.svg', lunch:'images/lunch.jpg', dinner:'images/dinner.jpg' };
  // Tiffin sizes (lunch/dinner). Images: apni real photos Netlify folder me → images/mini-tiffin.jpg & images/full-tiffin.jpg
  function tiffinBase(m,variantId){ return findVariant(m,variantId).price; }
  function defaultVariantId(m){ return variantsFor(m)[0].id; }
  // Image existence cache — keyed by URL. Missing/empty URLs never enter DOM.
  const IMG_OK={};
  function allImageUrls(){
    const urls=[];
    ['breakfast','lunch','dinner'].forEach(m=>{
      if(CFG.banners&&CFG.banners[m]) urls.push(CFG.banners[m]);
      variantsFor(m).forEach(v=>{ if(v.img) urls.push(v.img); });
    });
    return urls;
  }
  function preloadImgs(){
    // Default placeholder images ko IMG_OK me daal do (bundle me hain, load ho jayengi)
    Object.values(DEFAULT_IMG).forEach(p=>{ if(IMG_OK[p]===undefined){ const im=new Image(); im.onload=()=>{IMG_OK[p]=true;}; im.onerror=()=>{IMG_OK[p]=false;}; im.src=p; IMG_OK[p]=true; } });
    allImageUrls().forEach(p=>{
      if(!p||IMG_OK[p]!==undefined) return;
      const im=new Image();
      im.onload=()=>{ IMG_OK[p]=true; const pg=document.getElementById('page1'); if(pg&&!pg.classList.contains('hidden')) renderMealPanel(); };
      im.onerror=()=>{ IMG_OK[p]=false; };
      im.src=p;
    });
  }
  function mealPhoto(m){ // banner → variant photo → default placeholder
    if(CFG.banners&&CFG.banners[m]&&IMG_OK[CFG.banners[m]]) return CFG.banners[m];
    const v=variantsFor(m).find(v=>v.img&&IMG_OK[v.img]);
    if(v) return v.img;
    return DEFAULT_IMG[m]||'';   // asli photo nahi → default image
  }
  const TIME_SLOTS={ breakfast:['7–8 AM','8–9 AM','9–10 AM'], lunch:['12–1 PM','1–2 PM'], dinner:['7–8 PM','8–9 PM'] };
  function loadTimePrefs(){ return storeGet('fbt_timeprefs')||{}; }
  function saveTimePref(meal,val){ const p=loadTimePrefs(); p[meal]=val; storeSet('fbt_timeprefs',p); }
  function defaultTimeSlot(meal){ const p=loadTimePrefs(); return (p[meal]&&TIME_SLOTS[meal].includes(p[meal]))?p[meal]:TIME_SLOTS[meal][0]; }
  const MEAL_TITLE={ en:{breakfast:'Breakfast',lunch:'Lunch',dinner:'Dinner'}, hinglish:{breakfast:'Breakfast',lunch:'Lunch',dinner:'Dinner'}, hi:{breakfast:'नाश्ता',lunch:'लंच',dinner:'डिनर'}, gu:{breakfast:'નાસ્તો',lunch:'લંચ',dinner:'ડિનર'} };
  function mealTitle(m){ return (MEAL_TITLE[LANG]&&MEAL_TITLE[LANG][m])||MEAL_META[m].title; }

  let dateOffset = 0;
  let activeMeal = 'lunch';
  let builder = freshBuilder();
  function defaultSabzi(m){ try{ const d=MENU[selDayKey()]; return (d&&d[m]&&d[m].sabziOptions&&d[m].sabziOptions[0])||''; }catch(e){ return ''; } }
  function freshBuilder() {
    return {
      breakfast:{ qty:1, tiffinType:defaultVariantId('breakfast'), timeSlot:defaultTimeSlot('breakfast') },
      lunch:{ qty:1, tiffinType:defaultVariantId('lunch'), sabzi:defaultSabzi('lunch'), butterRoti:false, extraRoti:0, dahi:false, extraSabzi:false, timeSlot:defaultTimeSlot('lunch') },
      dinner:{ qty:1, tiffinType:defaultVariantId('dinner'), sabzi:defaultSabzi('dinner'), butterRoti:false, extraRoti:0, dahi:false, extraSabzi:false, timeSlot:defaultTimeSlot('dinner') }
    };
  }
  let cart = [];
  // V2-1: cart restore (refresh/tab-kill pe cart wapas) — purani dates drop
  try{
    const __sc=storeGet('fbt_cart');
    if(Array.isArray(__sc)&&__sc.length){
      const __today=fmtYMD(dateWithOffset(0));
      cart=__sc.filter(it=>it&&it.deliveryDate&&it.deliveryDate>=__today&&it.meal&&it.qty>0);
    }
  }catch(e){}
  const MEAL_ORDER = { breakfast:0, lunch:1, dinner:2 };
  function mealSort(a,b){ if(a.deliveryDate!==b.deliveryDate) return a.deliveryDate<b.deliveryDate?-1:1; if(MEAL_ORDER[a.meal]!==MEAL_ORDER[b.meal]) return MEAL_ORDER[a.meal]-MEAL_ORDER[b.meal]; return String(a.tiffinType||'').localeCompare(String(b.tiffinType||'')); }
  let payment = 'UPI';

  function selDate(){ return dateWithOffset(dateOffset); }
  function selDateStr(){ return fmtYMD(selDate()); }
  function selDayKey(){ return weekdayKey(selDate()); }

  // ═══════ STORAGE + SESSION ═══════
  function storeSet(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch(e){} }
  function storeGet(k){ try{ const v=localStorage.getItem(k); return v?JSON.parse(v):null; }catch(e){ return null; } }
  function storeDel(k){ try{ localStorage.removeItem(k); }catch(e){} }
  let SESSION = storeGet('fbt_session');
  function isLoggedIn(){ return !!(SESSION && SESSION.token && SESSION.phone); }

  // ═══════ HELPERS ═══════
  let __toastT=null;
  // XSS guard — user ka koi bhi text innerHTML me jaane se pehle escape
  function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function showToast(msg,type=''){
    const el=document.getElementById('toast');
    el.textContent=msg; el.className='toast '+type; el.classList.add('show');
    if(__toastT) clearTimeout(__toastT);                    // purana timer cancel (warna naya toast jaldi gayab hota tha)
    __toastT=setTimeout(()=>{ el.classList.remove('show'); __toastT=null; },3800);
  }
  function onlyNumbers(el){ el.value=el.value.replace(/\D/g,''); }
  // ═══ GLOBAL LOADING BAR — har request pe apne aap ═══
  let __busy=0;
  function busyStart(){ __busy++; const b=document.getElementById('topBar'); if(b) b.classList.add('on'); }
  function busyEnd(){ __busy=Math.max(0,__busy-1); if(!__busy){ const b=document.getElementById('topBar'); if(b) b.classList.remove('on'); } }
  (function(){
    const of=window.fetch;
    window.fetch=function(){ busyStart(); return of.apply(this,arguments).finally(busyEnd); };
  })();
  // Button ko turant "working" dikhao (double-tap bhi rukta hai)
  function btnBusy(el, on, label){
    if(!el)return;
    if(on){ el.dataset.old=el.innerHTML; el.disabled=true; el.classList.add('is-busy'); el.innerHTML='<span class="spin"></span> '+(label||t('pleaseWait')); }
    else { el.disabled=false; el.classList.remove('is-busy'); if(el.dataset.old!==undefined) el.innerHTML=el.dataset.old; }
  }
  // Server error → user ki chuni hui language me (code-based translation)
  function srvMsg(j){
    if(j && j.code){ const k='srv_'+j.code; const s=t(k); if(s && s!==k) return s; }
    return (j && j.message) || t('errNetwork');
  }
  function apiPost(p){ return fetch(GOOGLE_SCRIPT_URL,{method:'POST',body:JSON.stringify(p)}).then(r=>r.json()); }

  function unitPrice(meal, cfg) {
    const P = CFG.prices;
    let p = tiffinBase(meal.meal, meal.tiffinType);
    if (meal.meal !== 'breakfast') {
      p += (meal.extraRoti||0) * (meal.butterRoti ? P.extraRotiButter : P.extraRotiPlain);
      if (meal.dahi) p += P.dahi;
      if (meal.extraSabzi) p += P.extraSabzi;
    }
    return p;
  }
  function builderUnitPrice(m) { return unitPrice({ meal:m, ...builder[m] }); }
  let deliveryType='home';
  // ── Delivery mode: order se PEHLE poocha jaata hai, phir poore app me wahi chalta hai ──
  function modesAvailable(){ return { home:(CFG.homeEnabled!==false), office:(CFG.officeEnabled===true)&&((CFG.companies||[]).length>0) }; }
  function openModeModal(dismissable){
    const m=modesAvailable();
    document.getElementById('mc-home').style.display=m.home?'block':'none';
    document.getElementById('mc-office').style.display=m.office?'block':'none';
    document.getElementById('mc-home').classList.toggle('on',deliveryType==='home');
    document.getElementById('mc-office').classList.toggle('on',deliveryType==='office');
    document.getElementById('modeClose').classList.toggle('hidden', !dismissable);
    document.getElementById('modeModal').classList.remove('hidden');
  }
  function closeModeModal(){ document.getElementById('modeModal').classList.add('hidden'); }
  function chooseMode(mode){
    setDeliveryType(mode);
    const a=storeGet('fbt_addr')||{}; a.deliveryType=mode; storeSet('fbt_addr',a);
    closeModeModal(); renderModeChip();
    if(cart.length && !document.getElementById('page2').classList.contains('hidden')) renderSummary();
  }
  function modeReady(){
    const m=modesAvailable();
    if(!m.office) return true;                 // sirf home => pooch-na zaroori nahi
    if(!m.home) { setDeliveryType('office'); return true; }
    const a=storeGet('fbt_addr')||{};
    if(a.deliveryType==='home'||a.deliveryType==='office'){ setDeliveryType(a.deliveryType); return true; }
    return false;                              // dono on hain aur user ne chuna nahi
  }
  function ensureMode(){ if(!modeReady()) openModeModal(false); }
  function renderModeChip(){
    const box=document.getElementById('modeChip'); if(!box)return;
    const m=modesAvailable();
    if(!(m.home&&m.office)){ box.innerHTML=''; return; }   // ek hi mode => chip ka matlab nahi
    const a=storeGet('fbt_addr')||{};
    const isOff=(deliveryType==='office');
    const line=isOff ? ((a.company||'')+(a.empId?(' · '+a.empId):'')) : ((a.society||'')+(a.flatNo?(' · '+a.flatNo):''));
    box.innerHTML=`<div class="mode-chip">
      <span class="mch-i">${isOff?'🏢':'🏠'}</span>
      <span class="mch-x"><span class="mch-t">${isOff?t('dtOffice'):t('dtHome')}</span><div class="mch-s">${line||t(isOff?'dtOfficeSub':'dtHomeSub')}</div></span>
      <span class="mch-c" onclick="openModeModal(true)">${t('modeChange')}</span>
    </div>`;
  }
  function companyByName(n){ return (CFG.companies||[]).find(c=>String(c.name).toLowerCase().trim()===String(n||'').toLowerCase().trim())||null; }
  function setDeliveryType(mode){
    deliveryType=(mode==='office')?'office':'home';
    const ic=document.getElementById('ckModeIc'), ct=document.getElementById('ckModeT'), cs=document.getElementById('ckModeS');
    if(ic){ ic.textContent=(deliveryType==='office')?'🏢':'🏠'; }
    if(ct){ ct.textContent=(deliveryType==='office')?t('dtOffice'):t('dtHome'); }
    if(cs){ cs.textContent=(deliveryType==='office')?t('dtOfficeSub'):t('dtHomeSub'); }
    document.getElementById('homeFields').classList.toggle('hidden',deliveryType==='office');
    document.getElementById('officeFields').classList.toggle('hidden',deliveryType!=='office');
    if(!document.getElementById('page2').classList.contains('hidden')){ renderSummary(); const b=document.getElementById('barTotal2'); if(b) b.textContent='₹'+cartTotalDisplay(); }
  }
  function deliveryFee(){
    if(!cart.length) return 0;
    if(deliveryType==='office'){
      const co=companyByName(document.getElementById('company')?document.getElementById('company').value:'');
      return co ? (co.fee||CFG.deliveryNear||10) : (CFG.deliveryNear||10);
    }
    const soc=(document.getElementById('society')?document.getElementById('society').value:'')||'';
    const far=(CFG.farSocieties||[]).map(s=>String(s).toLowerCase().trim());
    return far.indexOf(String(soc).toLowerCase().trim())>=0 ? (CFG.deliveryFar||20) : (CFG.deliveryNear||10);
  }
  function cartSubtotal(){ return cart.reduce((s,it)=> s + unitPrice(it)*it.qty, 0); }
  function feeDates(){ return new Set(cart.map(x=>x.deliveryDate)).size; }
  function deliveryFeeTotal(){ const n=feeDates(); return n ? n*deliveryFee() : 0; }
  function cartTotal(){ const st=cartSubtotal(); return st>0 ? st + deliveryFeeTotal() : 0; }
  // ── PROMO / COUPON (client = preview only; asli discount SERVER decide karta hai) ──
  let appliedPromo=null;
  try{ const __p=storeGet('fbt_promo'); if(__p&&__p.code&&cart.length) appliedPromo=__p; }catch(e){}
  function firstDateTotal(){
    if(!cart.length) return 0;
    const d0=[...new Set(cart.map(x=>x.deliveryDate))].sort()[0];
    return cart.filter(x=>x.deliveryDate===d0).reduce((s,it)=>s+unitPrice(it)*it.qty,0)+deliveryFee();
  }
  function promoDiscountNow(){ return appliedPromo?Math.min(appliedPromo.discount,firstDateTotal()):0; }
  function cartTotalDisplay(){ return Math.max(0,cartTotal()-promoDiscountNow()); }
  function applyPromo(){
    const inp=document.getElementById('promoCode'); const code=(inp?inp.value:'').trim();
    if(!code){ showToast('⚠️ '+t('promoHave'),'warning'); return; }
    if(!cart.length){ showToast('⚠️ '+t('cartEmpty'),'warning'); return; }
    const pb=document.getElementById('promoApplyBtn'); btnBusy(pb,true);
    apiPost({action:'checkpromo',token:SESSION.token,code:code,amount:firstDateTotal()}).then(j=>{
      btnBusy(pb,false);
      if(j.status==='success'){ appliedPromo={code:j.code,discount:j.discount,label:j.label||''}; renderCart(); renderSummary&&!document.getElementById('page2').classList.contains('hidden')&&renderSummary(); showToast('🎟️ '+j.code+' '+t('promoApplied')+' — −₹'+j.discount,'success'); }
      else if(j.status==='invalid_session'){ forceLogout(); }
      else showToast('❌ '+(j.message||'Invalid coupon')+(feeDates()>1?(' '+t('promoFirstDateNote')):''),'error');
    }).catch(()=>showToast(t('errNetwork'),'error'));
  }
  function pickPromo(code){ const i=document.getElementById('promoCode'); if(i){ i.value=code; applyPromo(); } }
  function removePromo(){ appliedPromo=null; renderCart(); if(!document.getElementById('page2').classList.contains('hidden')){ renderSummary(); document.getElementById('barTotal2').textContent='₹'+cartTotalDisplay(); } }

  // ═══════ DRAWER ═══════
  function openDrawer(){
    document.getElementById('drawerName').textContent = (SESSION&&SESSION.name)||'Guest';
    document.getElementById('drawerPhone').textContent = (SESSION&&SESSION.phone)?('📱 '+SESSION.phone):'';
    document.getElementById('drawerOverlay').classList.add('open');
    document.getElementById('drawer').classList.add('open');
  }
  function closeDrawer(){ document.getElementById('drawerOverlay').classList.remove('open'); document.getElementById('drawer').classList.remove('open'); }
  function drawerGo(where){
    closeDrawer();
    if(where==='logout'){ logout(); return; }
    if(where==='cart'){ showCartPage(); }
    else if(where==='past'){ showOrdersPage(); }
    else if(where==='sub'){ showSubPage(); }
    else if(where==='about'){ showAboutPage(); }
    
    else{ showLanding(); }
  }
  function saveCart(){ try{ storeSet('fbt_cart', cart); storeSet('fbt_promo', appliedPromo||null); }catch(e){} }
  function updateCartBadge(){
    saveCart();
    const n=cart.reduce((s,it)=>s+it.qty,0);
    const b=document.getElementById('cartBadge'); if(b){ b.textContent=n; b.classList.toggle('zero',n===0); }
    const d=document.getElementById('drawerCartBadge'); if(d){ d.textContent=n; d.style.display=n===0?'none':'flex'; }
    const bnb=document.getElementById('bnCartBadge'); if(bnb){ bnb.textContent=n; bnb.classList.toggle('zero',n===0); }
    const mb=document.getElementById('miniBar'); if(mb) mb.style.display=n===0?'none':'flex';
    const bt=document.getElementById('barTotal'); if(bt) bt.textContent='₹'+cartTotalDisplay();
    const cb=document.getElementById('continueBtn'); if(cb) cb.disabled=n===0;
  }

  // ═══════ VIEW NAV ═══════
  function closeAllPopups(){
    ['mealSheet','orderModal','limitModal','modeModal'].forEach(x=>{ const e=document.getElementById(x); if(e) e.classList.add('hidden'); });
  }
  function showView(id){
    closeAllPopups();                                       // page badle to koi popup upar chipka na rahe
    try{ if(['pubView','authPage','homeView','page1','cartView','ordersView','subView','aboutView','profileView','adminPanel'].indexOf(id)>=0) storeSet('fbt_view',id); }catch(e){}
    ['pubView','authPage','homeView','page1','page2','cartView','ordersView','subView','aboutView','profileView','adminLogin','adminPanel'].forEach(v=>document.getElementById(v).classList.toggle('hidden', v!==id)); window.scrollTo(0,0); updateBottomNav(id); }
  // Bottom nav shows only on the 4 main customer screens
  const BN_SCREENS={ homeView:'land', page1:'menu', cartView:'cart', ordersView:'orders', profileView:'profile' };
  function updateBottomNav(viewId){
    const ps=document.querySelector('.pub-sticky'); if(ps) ps.style.display = (viewId==='pubView')?'flex':'none';
    const bn=document.getElementById('bottomNav'); if(!bn)return;
    const show=Object.keys(BN_SCREENS).indexOf(viewId)>=0 && isLoggedIn();
    bn.classList.toggle('hidden', !show);
    const cont=document.querySelector('.container'); if(cont) cont.classList.toggle('has-bottom-nav', show);
    if(show){
      const active=BN_SCREENS[viewId];
      ['land','menu','cart','orders','profile'].forEach(k=>{ const el=document.getElementById('bn-'+k); if(el) el.classList.toggle('active', k===active); });
    }
  }
  function navTo(where){
    if(where==='land') showLanding();
    else if(where==='menu') showHomePage();
    else if(where==='cart') showCartPage();
    else if(where==='orders') showOrdersPage();
    else if(where==='profile') showProfilePage();
  }
  function showLanding(){ showView('homeView'); renderHome(); }
  function showPublic(){
    showView('pubView');
    initGoogleButton();
    try{ if(window.google&&google.accounts&&google.accounts.id) google.accounts.id.prompt(); }catch(e){}
    const ls=document.getElementById('langSelPub'), src=document.getElementById('langSel');
    if(ls&&src&&!ls.options.length) ls.innerHTML=src.innerHTML;
    if(ls) ls.value=LANG;
    document.querySelectorAll('.fssai-line').forEach(e=>{ e.textContent = CFG.fssai ? ('FSSAI Reg. No: '+CFG.fssai) : ''; });
  }
  function showProfilePage(){ showView('profileView'); renderProfile(); }
  function goMenuMeal(m){ showHomePage(); const av=mealsAvail(dateOffset); if(av[m]&&av[m].ok) selectMeal(m); }
  function renderHome(){
    const hv=document.getElementById('homeView'); if(!hv)return;
    renderModeChip();
    const ls=document.getElementById('langSelHome'); const src=document.getElementById('langSel');
    if(ls&&src&&!ls.options.length){ ls.innerHTML=src.innerHTML; } if(ls) ls.value=LANG;
    const hp=document.getElementById('homePromo');
    if(hp){
      const pr=(CFG.promos||[])[0];
      hp.innerHTML=pr?`<div class="home-promo" onclick="showHomePage()">🎟️ <b>${pr.code}</b> — ${pr.label}${pr.firstOnly?(' · 🆕 '+t('promoNewTag')):''}${pr.minOrder?(' · Min ₹'+pr.minOrder):''}<br><small>${t('promoUseAtCheckout')}</small></div>`:'';
    }
  }
  function renderProfile(){
    const nm=document.getElementById('pfName'); if(!nm)return;
    const name=(SESSION&&SESSION.name)||'';
    nm.textContent=name||'—';
    const av=document.getElementById('pfAva'); if(av)av.textContent=(name||'?').charAt(0).toUpperCase();
    const ph=document.getElementById('pfPhone'); if(ph)ph.textContent=(SESSION&&SESSION.phone)?('📞 +91 '+SESSION.phone):'';
    const sel=document.getElementById('pfSociety');
    if(sel){ const saved=storeGet('fbt_addr')||{}; sel.innerHTML=CFG.societies.map(s=>`<option value="${s}" ${saved.society===s?'selected':''}>${s}</option>`).join(''); const fl=document.getElementById('pfFlat'); if(fl)fl.value=saved.flatNo||''; }
    const lp=document.getElementById('langSelProfile'); const src2=document.getElementById('langSel');
    if(lp&&src2&&!lp.options.length){ lp.innerHTML=src2.innerHTML; } if(lp) lp.value=LANG;
  }
  function savePfAddr(){
    const s=document.getElementById('pfSociety').value, f=document.getElementById('pfFlat').value.trim();
    if(!s||!f){ showToast('⚠️ '+t('errFlat'),'warning'); return; }
    saveAddr({society:s,flatNo:f});
    showToast('✅ '+t('addrSaved'),'success');
  }
  function showHomePage(){ showView('page1'); refreshAvailability(); }
  // 1-tap quick add: default variant + default sabzi + default time, sheet khole bina
  function quickAdd(m, ev){
    if(ev&&ev.stopPropagation){ ev.stopPropagation(); }
    if(!isLoggedIn()){ showAuth(); return; }
    const b=freshBuilder()[m];
    if(cart.find(it=>it.deliveryDate===selDateStr()&&it.meal===m)){ openMealSheet(m); return; }  // already hai → customize
    const v=findVariant(m,b.tiffinType);
    cart.push({ id:selDateStr()+'|'+m+'|'+b.tiffinType, deliveryDate:selDateStr(), deliveryLabel:fmtLabel(selDate()), day:selDayKey().charAt(0).toUpperCase()+selDayKey().slice(1),
      meal:m, qty:1, tiffinType:b.tiffinType, variantName:v.name, sabzi:b.sabzi||'',
      butterRoti:false, extraRoti:0, dahi:false, extraSabzi:false, timeSlot:b.timeSlot });
    updateCartBadge(); saveCart();
    showToast('🛒 '+mealTitle(m)+' '+t('addedShort'),'success');
  }
  function showCartPage(){ showView('cartView'); renderCart(); }
  // Cart se seedha order — agar address saved hai to checkout page skip
  function cartCheckout(){
    if(!cart.length) return;
    const a=storeGet('fbt_addr')||{};
    const ready = deliveryType==='office' ? (a.company&&a.empId) : (a.society&&a.flatNo);
    if(ready){ goToCheckout(); setTimeout(()=>placeOrder(),60); }   // ek tap = order
    else goToCheckout();                                          // pehli baar: address bharwao
  }
  function showOrdersPage(){ showView('ordersView'); loadMyOrders();
    const hd=document.getElementById('histDate'); if(hd) hd.max=fmtYMD(dateWithOffset(0));   // history = aaj tak
  }
  function showSubPage(){ if(!isLoggedIn()){ showAuth(); return; } showView('subView'); loadSub(); }
  function showAboutPage(){ showView('aboutView'); renderAbout(); }
  function showContactPage(){ showAboutPage(); }
  

  // ═══════ AUTH (Google Sign-In) ═══════
  let googleCredential=null;
  let authMode='signin';
  let resetToken=null;
  function showAuth(){
    // Pehle se logged in? Login page ka koi matlab nahi — seedha app me.
    if(isLoggedIn() && !new URLSearchParams(location.search).get('reset')){ enterApp(); return; }
    googleCredential=null;
    const gp=document.getElementById('googlePhoneBox'); if(gp)gp.classList.add('hidden');
    const e1=document.getElementById('err-authPhone'); if(e1)e1.classList.remove('show');
    const e2=document.getElementById('authGoogleErr'); if(e2)e2.classList.remove('show');
    // Returning Google user → One Tap khud sign-in kar dega (zero click)
    try{ if(window.google&&google.accounts&&google.accounts.id) google.accounts.id.prompt(); }catch(e){}
    showView('authPage');
    // Password-reset link opened from email? (?reset=TOKEN)
    const urlToken=new URLSearchParams(location.search).get('reset');
    if(urlToken){ resetToken=urlToken; showAuthMode('reset'); }
    else showAuthMode('signin');
    initGoogleButton();
  }
  function enterApp(restore){
    document.getElementById('profileName').textContent='👤 '+(SESSION.name||'');
    const v=restore?storeGet('fbt_view'):null;     // showLanding se PEHLE padho (warna overwrite)
    showLanding(); ensureMode(); refreshAvailability(); renderCart(); loadPublicStats(selDateStr());
    if(restore){                                   // refresh ke baad wahi page wapas kholo
      if(v==='page1') showHomePage();
      else if(v==='cartView') showCartPage();
      else if(v==='ordersView') showOrdersPage();
      else if(v==='subView') showSubPage();
      else if(v==='aboutView') showAboutPage();
      else if(v==='profileView') showProfilePage();
    }
  }

  function showAuthMode(mode){
    authMode=mode;
    const ids={ signin:'authModeSignIn', signup:'authModeSignUp', forgot:'authModeForgot', reset:'authModeReset' };
    Object.keys(ids).forEach(m=>{ const el=document.getElementById(ids[m]); if(el)el.classList.toggle('hidden', m!==mode); });
    const social=document.getElementById('authSocialBlock'); if(social)social.style.display=(mode==='forgot'||mode==='reset')?'none':'block';
    document.querySelectorAll('#authPage .field-error').forEach(e=>e.classList.remove('show'));
  }
  function togglePwd(id,btn){ const el=document.getElementById(id); const show=el.type==='password'; el.type=show?'text':'password'; btn.textContent=show?'🙈':'👁️'; }
  function fieldErr(id,show){ const e=document.getElementById('err-'+id); if(e)e.classList.toggle('show',!!show); const i=document.getElementById(id); if(i)i.classList.toggle('error',!!show); }
  function isValidEmail(v){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v||'').trim()); }

  function doEmailSignIn(){
    const email=document.getElementById('siEmail').value.trim();
    const pw=document.getElementById('siPassword').value;
    let ok=true;
    if(!isValidEmail(email)){ fieldErr('siEmail',true); ok=false; } else fieldErr('siEmail',false);
    if(!pw){ fieldErr('siPassword',true); ok=false; } else fieldErr('siPassword',false);
    if(!ok) return;
    const btn=document.getElementById('siBtn'); btn.disabled=true;
    apiPost({ action:'emailLogin', email:email, password:pw }).then(j=>{
      btn.disabled=false;
      if(j.status!=='success'){ showToast('❌ '+(j.message||'Sign in failed'),'error'); return; }
      SESSION={token:j.token,name:j.name,phone:j.phone}; storeSet('fbt_session',SESSION);
      showToast(t('welcomeUser')+' '+j.name+'!','success'); enterApp();
    }).catch(()=>{ btn.disabled=false; showToast(t('errNetwork'),'error'); });
  }

  function doEmailSignUp(){
    const email=document.getElementById('suEmail').value.trim();
    const pw=document.getElementById('suPassword').value;
    const cpw=document.getElementById('suConfirm').value;
    const phone=document.getElementById('suPhone').value.trim();
    let ok=true;
    if(!isValidEmail(email)){ fieldErr('suEmail',true); ok=false; } else fieldErr('suEmail',false);
    if(pw.length<6){ fieldErr('suPassword',true); ok=false; } else fieldErr('suPassword',false);
    if(cpw!==pw || !cpw){ fieldErr('suConfirm',true); ok=false; } else fieldErr('suConfirm',false);
    if(!/^[6-9]\d{9}$/.test(phone)){ fieldErr('suPhone',true); ok=false; } else fieldErr('suPhone',false);
    if(!ok) return;
    const btn=document.getElementById('suBtn'); btn.disabled=true;
    apiPost({ action:'emailSignup', email:email, password:pw, phone:phone }).then(j=>{
      btn.disabled=false;
      if(j.status!=='success'){ showToast('❌ '+(j.message||'Sign up failed'),'error'); return; }
      SESSION={token:j.token,name:j.name,phone:j.phone}; storeSet('fbt_session',SESSION);
      showToast(t('welcomeUser')+' '+j.name+'!','success'); enterApp();
    }).catch(()=>{ btn.disabled=false; showToast(t('errNetwork'),'error'); });
  }

  function doForgotPassword(){
    const email=document.getElementById('fpEmail').value.trim();
    if(!isValidEmail(email)){ fieldErr('fpEmail',true); return; }
    fieldErr('fpEmail',false);
    const btn=document.getElementById('fpBtn'); btn.disabled=true; btn.textContent='⏳ ...';
    apiPost({ action:'forgotPassword', email:email, origin:location.href.split(/[?#]/)[0] }).then(j=>{
      btn.disabled=false; btn.textContent=t('sendResetBtn');
      showToast('📧 '+t('resetLinkSent'),'success');
      showAuthMode('signin');
    }).catch(()=>{ btn.disabled=false; btn.textContent=t('sendResetBtn'); showToast(t('errNetwork'),'error'); });
  }

  function doResetPassword(){
    const pw=document.getElementById('rpPassword').value;
    const cpw=document.getElementById('rpConfirm').value;
    let ok=true;
    if(pw.length<6){ fieldErr('rpPassword',true); ok=false; } else fieldErr('rpPassword',false);
    if(cpw!==pw || !cpw){ fieldErr('rpConfirm',true); ok=false; } else fieldErr('rpConfirm',false);
    if(!ok) return;
    if(!resetToken){ showToast(t('resetLinkBad'),'error'); return; }
    const btn=document.getElementById('rpBtn'); btn.disabled=true;
    apiPost({ action:'resetPassword', token:resetToken, password:pw }).then(j=>{
      btn.disabled=false;
      if(j.status!=='success'){ showToast('❌ '+(j.message||'Reset failed'),'error'); return; }
      showToast('✅ '+t('passwordResetDone'),'success');
      history.replaceState(null,'',location.pathname); // strip ?reset= from URL
      showAuthMode('signin');
    }).catch(()=>{ btn.disabled=false; showToast(t('errNetwork'),'error'); });
  }

  let __gsiInit=false;
  function initGoogleButton(){
    if(!window.google || !google.accounts || !google.accounts.id) { setTimeout(initGoogleButton, 300); return; }
    if(__gsiInit) return; __gsiInit=true;
    google.accounts.id.initialize({ client_id: GOOGLE_CLIENT_ID, callback: onGoogleCredential, auto_select:true, itp_support:true });
    const box=document.getElementById('googleBtnBox'); if(!box)return;
    box.innerHTML='';
    const w=Math.min(360, Math.max(240, box.offsetWidth||280));
    google.accounts.id.renderButton(box, { theme:'outline', size:'large', shape:'pill', text:'signin_with', logo_alignment:'left', width:w });
  }

  function readAuthPhone(){ const ph=document.getElementById('authPhone').value.trim(); return /^[6-9]\d{9}$/.test(ph)?ph:''; }

  function onGoogleCredential(resp){
    googleCredential=resp.credential;
    const err=document.getElementById('authGoogleErr'); if(err) err.classList.remove('show');
    document.getElementById('err-authPhone').classList.remove('show');
    apiPost({ action:'googleLogin', credential: googleCredential, phone: readAuthPhone() }).then(j=>{
      if(j.status==='success'){
        SESSION={token:j.token,name:j.name,phone:j.phone}; storeSet('fbt_session',SESSION);
        showToast(t('welcomeUser')+' '+j.name+'!','success'); enterApp(); return;
      }
      if(j.status==='need_phone'){
        document.getElementById('googlePhoneBox').classList.remove('hidden');
        document.getElementById('authPhone').focus();
        showToast('📱 '+t('phoneFirstHint'),'warning');
        return;
      }
      showToast('❌ '+(j.message||'Google sign-in failed'),'error');
    }).catch(()=>{ showToast(t('errNetwork'),'error'); });
  }

  function finishGoogleLogin(){
    const ph=readAuthPhone();
    if(!ph){ document.getElementById('err-authPhone').classList.add('show'); document.getElementById('authPhone').focus(); return; }
    document.getElementById('err-authPhone').classList.remove('show');
    if(!googleCredential){ showToast('⚠️ '+t('errPickGoogle'),'warning'); return; }
    const btn=document.getElementById('finishLoginBtn'); btn.textContent='⏳ ...'; btn.disabled=true;
    apiPost({ action:'googleLogin', credential: googleCredential, phone: ph }).then(j=>{
      btn.textContent=t('completeSignup'); btn.disabled=false;
      if(j.status!=='success'){ showToast('❌ '+(j.message||'Login failed'),'error'); return; }
      document.getElementById('googlePhoneBox').classList.add('hidden');
      SESSION={token:j.token,name:j.name,phone:j.phone}; storeSet('fbt_session',SESSION);
      showToast(t('welcomeUser')+' '+j.name+'!','success'); enterApp();
    }).catch(()=>{ btn.textContent=t('completeSignup'); btn.disabled=false; showToast(t('errNetwork'),'error'); });
  }

  function logout(){ if(SESSION&&SESSION.token) apiPost({action:'logout',token:SESSION.token}).catch(()=>{}); SESSION=null; storeDel('fbt_session'); cart=[]; saveCart(); showPublic(); }
  function forceLogout(){ SESSION=null; storeDel('fbt_session'); showToast(t('sessionExpired'),'warning'); showAuth(); }

  // ═══════ DATE ═══════
  function renderDateSelector(){
    const sel=document.getElementById('dateSelect'); if(!sel)return;
    const names={ en:['Today','Tomorrow','Day After Tomorrow'], hinglish:['Aaj','Kal','Parso'], hi:['आज','कल','परसों'], gu:['આજે','આવતીકાલે','પરમ દિવસે'] };
    const nm=names[LANG]||names.en; let html='';
    for(let o=0;o<=2;o++){ const d=dateWithOffset(o); const open=anyAvail(o); html+=`<option value="${o}" ${o===dateOffset?'selected':''} ${open?'':'disabled'}> ${fmtLabel(d)}${open?'':' (Closed)'}</option>`; }
    sel.innerHTML=html;
  }
  function pickDefaultDate(){ for(let o=0;o<=2;o++){ if(anyAvail(o)){ dateOffset=o; return; } } dateOffset=2; }
  function refreshAvailability(){ if(!anyAvail(dateOffset)) pickDefaultDate(); renderDateSelector(); pickActiveMeal(); renderMealTabs(); renderMenuDateTime(); renderMealPanel(); const is=document.getElementById('infoStrip'); if(is)is.classList.toggle('hidden', !!storeGet('fbt_infostrip_x')); }
  function dismissInfoStrip(){ storeSet('fbt_infostrip_x',1); const is=document.getElementById('infoStrip'); if(is)is.classList.add('hidden'); }
  function pickActiveMeal(){ const av=mealsAvail(dateOffset); if(!av[activeMeal].ok){ for(const m of MEALS){ if(av[m].ok){ activeMeal=m; return; } } } }

  // ═══════ LIVE COUNTER ("cooking fresh, for you") ═══════
  const statsCache={};
  function loadPublicStats(dateStr){
    if(GOOGLE_SCRIPT_URL.indexOf('http')!==0) return;
    fetch(GOOGLE_SCRIPT_URL+'?action=publicstats&date='+dateStr).then(r=>r.json()).then(j=>{
      if(j.status==='success'){ statsCache[dateStr]=j.stats; renderStatsBanner(); renderMealPanel(); }
    }).catch(()=>{});
  }
  function renderStatsBanner(){
    const box=document.getElementById('statsBanner'); if(!box)return;
    const s=statsCache[selDateStr()];
    if(!s){ box.innerHTML=''; return; }
    const m=activeMeal; const mm=s[m]||{ordered:0,preparing:0};
    const cap=(CFG.capacity&&CFG.capacity[m])||0;
    let capHtml='';
    if(cap>0){
      const left=Math.max(0,cap-mm.ordered);
      const pct=Math.min(100,Math.round((mm.ordered/cap)*100));
      capHtml=`<div class="stats-cap-bar"><div class="stats-cap-fill ${left<=Math.ceil(cap*0.2)?'hot':''}" style="width:${pct}%;"></div></div>
        <div style="font-size:11.5px;color:var(--muted);margin-top:5px;">${left>0?('⏳ '+t('onlyLeftToday').replace('{n}',left)):('🔴 '+t('soldOutToday'))}</div>`;
    }
    box.innerHTML=`<div class="stats-banner">
      <div class="stats-trust">🎉 ${s.totalCustomers}+ ${t('happyCustomers')}</div>
      <div class="stats-live">🔥 <span class="n">${mm.ordered}</span> ${t('orderedForThisMeal')}${mm.preparing?(' · 👨‍🍳 <span class="n">'+mm.preparing+'</span> '+t('beingPrepared')):''}</div>
      ${capHtml}
    </div>`;
  }
  function capacityReached(m,dstr){
    const cap=(CFG.capacity&&CFG.capacity[m])||0; if(!cap) return false;
    const s=statsCache[dstr]; if(!s) return false;
    return (s[m]||{ordered:0}).ordered>=cap;
  }

  // ═══════ MEAL TABS (horizontal) ═══════
  function renderMealTabs(){
    const av=mealsAvail(dateOffset); const box=document.getElementById('mealTabs'); if(!box)return;
    box.innerHTML=MEALS.map(m=>{
      const inCart=cart.some(it=>it.deliveryDate===selDateStr() && it.meal===m);
      return `<div class="meal-tab ${m===activeMeal?'active':''} ${av[m].ok?'':'closed'} ${inCart?'incart':''}" onclick="selectMeal('${m}')">
        <span class="dot"></span><span class="emoji">${MEAL_META[m].emoji}</span>${mealTitle(m)}</div>`;
    }).join('');
  }
  function selectMeal(m){ activeMeal=m; renderMealTabs(); renderMenuDateTime(); renderMealPanel(); }

  // Date + Time row above tabs (applies to the whole order / active meal's time)
  function renderMenuDateTime(){
    const box=document.getElementById('menuDateTime'); if(!box)return;
    const m=activeMeal, b=builder[m];
    const dayNames={ en:['Today','Tomorrow','Day After'], hinglish:['Aaj','Kal','Parso'], hi:['आज','कल','परसों'], gu:['આજે','આવતીકાલે','પરમ દિવસે'] };
    const dn=dayNames[LANG]||dayNames.en;
    let dateChips=''; for(let o=0;o<=2;o++){ const open=anyAvail(o); dateChips+=`<button type="button" class="dchip ${o===dateOffset?'on':''}" ${open?'':'disabled'} onclick="menuChangeDate(${o})"><b>${dn[o]}</b><span>${fmtLabel(dateWithOffset(o))}</span>${open?'':'<i>✕</i>'}</button>`; }
    const av=mealsAvail(dateOffset)[m];
    let timeCell='';
    if(av.ok){
      const timeOpts=TIME_SLOTS[m].map(s=>`<option value="${s}" ${b.timeSlot===s?'selected':''}>${s}</option>`).join('');
      timeCell=`<div class="mdt-cell"><span class="mdt-lbl">${t('deliveryTime')}</span><select onchange="menuSetTime(this.value)">${timeOpts}</select></div>`;
    }
    box.innerHTML=`<div class="menu-dt" style="flex-direction:column;align-items:stretch;">
      <div class="mdt-cell"><span class="mdt-lbl">${t('deliveryDate')}</span><div class="date-chips">${dateChips}</div></div>
      ${timeCell}
    </div>`;
  }
  function menuChangeDate(v){ const off=parseInt(v,10)||0; if(!anyAvail(off))return; dateOffset=off; builder=freshBuilder(); pickActiveMeal(); if(!statsCache[selDateStr()])loadPublicStats(selDateStr()); renderMealTabs(); renderMenuDateTime(); renderMealPanel(); }
  function menuSetTime(v){ builder[activeMeal].timeSlot=v; saveTimePref(activeMeal,v); }

  // ═══════ MENU AS CARDS ═══════
  function renderMealPanel(){
    const box=document.getElementById('mealPanel'); if(!box)return;
    const m=activeMeal; const av=mealsAvail(dateOffset)[m];
    if(!av.ok){ box.innerHTML=`<div class="menu-closed">⏰ ${av.why}</div>`; return; }
    if(capacityReached(m,selDateStr())){
      box.innerHTML=`<div class="menu-closed">🔴 ${t('soldOutTitle')}<br><span style="font-weight:400;font-size:11.5px;">${t('soldOutSub')}</span></div>`;
      return;
    }
    const name=mealTitle(m);
    const vs=variantsFor(m);
    const pr=priceRange(m);
    const priceLabel = (pr.min===pr.max) ? `₹${pr.min}` : `₹${pr.min} <small>– ₹${pr.max}</small>`;
    // description = items of the richest (highest price) variant
    const rich=vs.reduce((a,b)=>b.price>a.price?b:a,vs[0]);
    const desc=(rich.items&&rich.items.length?rich.items:[]).slice(0,6).join(' · ');
    const emoji=MEAL_META[m].emoji;
    const ph=mealPhoto(m);
    const photo=ph?`<img class="mc-photo" src="${ph}" alt="">`:`<div class="mc-photo">${emoji}</div>`;
    box.innerHTML=`
      <div class="mcard">
        <div class="mc-left" onclick="openMealSheet('${m}')">
          <div class="veg-mark"></div>
          <div class="mc-name">${name}</div>
          <div class="mc-price">${priceLabel}</div>
          <div class="mc-desc">${desc}</div>
        </div>
        <div class="mc-right">
          <div onclick="openMealSheet('${m}')">${photo}</div>
          <div class="mc-add" onclick="quickAdd('${m}',event)">${t('addToCart2')} +</div>
          ${vs.length>1?`<div class="mc-cust" onclick="openMealSheet('${m}')">${t('customizable')}</div>`:''}
        </div>
      </div>`;
  }

  // ═══════ MEAL POPUP (bottom sheet) ═══════
  let sheetMeal='lunch';
  function openMealSheet(m){
    sheetMeal=m;
    builder[m]=freshBuilder()[m];
    renderMealSheet();
    document.getElementById('mealSheet').classList.remove('hidden');
    document.body.style.overflow='hidden';
  }
  function closeMealSheet(){ document.getElementById('mealSheet').classList.add('hidden'); document.body.style.overflow=''; }
  function renderMealSheet(){
    const m=sheetMeal, b=builder[m], d=MENU[selDayKey()];
    const sel=findVariant(m,b.tiffinType);
    const shPh = (sel.img&&IMG_OK[sel.img]) ? sel.img : mealPhoto(m);
    document.getElementById('shPhoto').innerHTML = shPh?`<img src="${shPh}" alt="" style="width:100%;height:100%;object-fit:cover;">`:MEAL_META[m].emoji;
    document.getElementById('shName').textContent=mealTitle(m);
    document.getElementById('shDesc').textContent = t('freshCookedDesc');

    // Variant block — render every variant for this meal. Skip if only one.
    const sizeBox=document.getElementById('shSizeBlock');
    const vs=variantsFor(m);
    if(vs.length<=1){ sizeBox.innerHTML=''; }
    else {
      sizeBox.innerHTML=`<div class="sh-block">
        <div class="sh-block-title">${t('chooseSize')}</div>
        <div class="sh-block-sub">${t('sizeRequired')}</div>
        ${vs.map(v=>`
          <div class="sh-opt ${b.tiffinType===v.id?'sel':''}" onclick="shSetSize('${v.id}')">
            <div><div class="oi-name">${v.name}</div><div class="oi-desc">${(v.items||[]).join(' · ')}</div></div>
            <div class="sh-opt-r"><span class="sh-opt-price">₹${v.price}</span><span class="sh-radio ${b.tiffinType===v.id?'on':''}"></span></div>
          </div>`).join('')}
      </div>`;
    }

    // Customize block
    const custBox=document.getElementById('shCustomBlock');
    let inner='';

    if(m!=='breakfast'){
      const opts=d[m].sabziOptions.map(o=>`<option value="${o}" ${b.sabzi===o?'selected':''}>${o}</option>`).join('');
      inner+=`<div class="sh-block">
        <div class="sh-lbl">${t('selectSabzi')} <span style="color:var(--danger)">*</span></div>
        <select class="sh-select" onchange="shSet('sabzi',this.value)"><option value="">—</option>${opts}</select>
        <div class="sh-lbl">${t('rotiType')}</div>
        <div class="sh-chips">
          <div class="sh-chip ${!b.butterRoti?'on':''}" onclick="shSetRoti(false)">${t('plain')}</div>
          <div class="sh-chip ${b.butterRoti?'on':''}" onclick="shSetRoti(true)">${t('butter')} +₹${CFG.prices.extraRotiButter-CFG.prices.extraRotiPlain}</div>
        </div>
        <div class="sh-lbl">${t('addOns')}</div>
        <div class="sh-addons-row">
          <div class="sh-chip ${b.extraRoti>0?'on':''}" onclick="shToggleExtraRoti()">+ ${t('extraRoti')}${b.extraRoti>0?(' ('+b.extraRoti+')'):''}</div>
          <div class="sh-chip ${b.dahi?'on':''}" onclick="shSet('dahi',!${b.dahi})">+ ${t('dahiShort')} ₹${CFG.prices.dahi}</div>
          <div class="sh-chip ${b.extraSabzi?'on':''}" onclick="shSet('extraSabzi',!${b.extraSabzi})">+ ${t('extraSabziShort')} ₹${CFG.prices.extraSabzi}</div>
        </div>
      </div>`;
    }
    custBox.innerHTML=inner;

    document.getElementById('shQty').textContent=b.qty;
    updateSheetAddBtn();
  }
  function updateSheetAddBtn(){
    const m=sheetMeal, b=builder[m];
    const ex=cart.find(it=>it.deliveryDate===selDateStr()&&it.meal===m&&(m==='breakfast'||it.tiffinType===b.tiffinType));
    document.getElementById('shAddBtn').textContent=(ex?t('updateCart'):t('addToCart'))+' · ₹'+(builderUnitPrice(m)*b.qty);
  }
  function shSetSize(v){ builder[sheetMeal].tiffinType=v; renderMealSheet(); }
  function shSet(k,v){ builder[sheetMeal][k]=v; if(k==='timeSlot')saveTimePref(sheetMeal,v); renderMealSheet(); }
  function shSetRoti(butter){ builder[sheetMeal].butterRoti=butter; renderMealSheet(); }
  function shToggleExtraRoti(){ const b=builder[sheetMeal]; b.extraRoti = b.extraRoti>0?0:1; renderMealSheet(); }
  function shQtyChange(dir){
    if(dir>0){ showLimitPopup(); return; }   // 1:1:1 rule — max 1 per meal per day
    builder[sheetMeal].qty=1; document.getElementById('shQty').textContent=1; updateSheetAddBtn();
  }
  function showLimitPopup(){ document.getElementById('limitModal').classList.remove('hidden'); }
  function closeLimitPopup(){ document.getElementById('limitModal').classList.add('hidden'); }
  function contactKitchen(){
    const msg=encodeURIComponent('Namaste, mujhe ek din me ek se zyada tiffin chahiye. Kripya help karein.');
    window.open('https://wa.me/91'+OWNER_WHATSAPP.replace(/^91/,'')+'?text='+msg,'_blank');
    closeLimitPopup();
  }
  function shAddToCart(){
    const m=sheetMeal, b=builder[m];
    if(m!=='breakfast' && !b.sabzi){ showToast('⚠️ '+t('selectSabzi'),'warning'); return; }
    if(capacityReached(m,selDateStr())){ showToast('🔴 '+t('soldOutTitle'),'error'); closeMealSheet(); renderMealPanel(); return; }
    const v=findVariant(m,b.tiffinType);
    const lineId = selDateStr()+'|'+m+'|'+b.tiffinType;
    const item={ id:lineId, deliveryDate:selDateStr(), deliveryLabel:fmtLabel(selDate()), day:selDayKey().charAt(0).toUpperCase()+selDayKey().slice(1), meal:m, qty:b.qty, timeSlot:b.timeSlot, tiffinType:b.tiffinType, variantName:v.name };
    if(m!=='breakfast'){ item.sabzi=b.sabzi; item.butterRoti=b.butterRoti; item.extraRoti=b.extraRoti; item.dahi=b.dahi; item.extraSabzi=b.extraSabzi; }
    const idx=cart.findIndex(x=>x.id===item.id);
    if(idx>=0) cart[idx]=item; else cart.push(item);
    showToast('🛒 '+mealTitle(m)+' ('+v.name+') '+t('addedToCart'),'success');
    closeMealSheet(); renderMealTabs(); renderMealPanel(); updateCartBadge(); renderCart();
  }
  function changeDate2(v){ builder=freshBuilder(); pickActiveMeal(); renderMealTabs(); renderMealPanel(); if(!statsCache[selDateStr()]) loadPublicStats(selDateStr()); }

  // ═══════ CART ═══════
  function removeCart(id){ cart=cart.filter(x=>x.id!==id); renderMealTabs(); renderMealPanel(); updateCartBadge(); renderCart(); }
  function clearCart(){ if(!cart.length)return; cart=[]; appliedPromo=null; renderMealTabs(); renderMealPanel(); updateCartBadge(); renderCart(); }

  function cartLineDesc(it){
    const timePart=it.timeSlot?('🕐 '+it.timeSlot):'';
    if(it.meal==='breakfast') return timePart;
    const typePart='🍱 '+(it.variantName||it.tiffinType);
    const add=[]; if(it.extraRoti)add.push('+'+it.extraRoti+' '+t('extraRoti')); if(it.dahi)add.push(t('dahiShort')); if(it.extraSabzi)add.push(t('extraSabziShort'));
    const rest=typePart+' · '+it.sabzi+' · '+(it.butterRoti?t('butter'):t('plain'))+(add.length?' · '+add.join(', '):'');
    return timePart?(timePart+' · '+rest):rest;
  }
  function cartTitleLine(it){
    let s=MEAL_META[it.meal].emoji+' '+mealTitle(it.meal);
    s+=' · '+(it.variantName||it.tiffinType);
    return s+' × '+it.qty;
  }
  function renderCart(){
    const box=document.getElementById('cartList'); if(!box)return;
    const cbt=document.getElementById('cartBarTotal'), cbtn=document.getElementById('checkoutBtn');
    if(!cart.length){ box.innerHTML=`<div class="cart-empty">${t('cartEmpty')}</div>`; if(cbt)cbt.textContent='₹0'; if(cbtn)cbtn.disabled=true; updateCartBadge(); return; }
    // Address saved? → button seedha "Place Order" (checkout page skip), warna "Checkout"
    if(cbtn){
      const a=storeGet('fbt_addr')||{};
      const ready = deliveryType==='office' ? (a.company&&a.empId) : (a.society&&a.flatNo);
      cbtn.setAttribute('onclick','cartCheckout()');
      cbtn.textContent = ready ? t('placeOrder') : t('checkout');
    }
    cart.sort(mealSort);
    let html='', lastDate='';
    cart.forEach(it=>{
      if(it.deliveryDate!==lastDate){ lastDate=it.deliveryDate; html+=`<div class="cust-label" style="margin-top:10px;">📅 ${it.deliveryLabel} · ${it.day}</div>`; }
      html+=`<div class="cart-item">
      <div class="ci-top"><span>${cartTitleLine(it)}</span><span class="ci-price">₹${unitPrice(it)*it.qty}</span></div>
      <div class="ci-sub">${cartLineDesc(it)}</div>
      <span class="ci-remove" onclick="removeCart('${it.id}')">✖ ${t('remove')}</span>
    </div>`;
    });
    const pd=promoDiscountNow();
    html+=`<div class="promo-box">${appliedPromo
      ?`<div class="promo-applied"><span>🎟️ ${appliedPromo.code} <b>−₹${pd}</b>${feeDates()>1?`<small>${t('promoFirstDateNote')}</small>`:''}</span><span class="pr-x" onclick="removePromo()">✕</span></div>`
      :`${(CFG.promos&&CFG.promos.length)?`<div class="promo-chips">${CFG.promos.map(pp=>`<span class="promo-chip" onclick="pickPromo('${pp.code}')">🎟️ ${pp.code} · ${pp.label}${pp.firstOnly?' · 🆕':''}</span>`).join('')}</div>`:''}<div class="promo-input"><input id="promoCode" placeholder="${t('promoHave')}" onkeydown="if(event.key==='Enter')applyPromo()"><button id="promoApplyBtn" onclick="applyPromo()">${t('promoApply')}</button></div>`}</div>`;
    html+=`<div class="cart-break"><div class="cb-row"><span>${t('subtotalLbl')}</span><span>₹${cartSubtotal()}</span></div><div class="cb-row"><span>🛵 ${t('deliveryLbl')}${feeDates()>1?(' × '+feeDates()):''}</span><span>₹${deliveryFeeTotal()}</span></div>${appliedPromo?`<div class="cb-row" style="color:var(--ok);"><span>🎟️ ${t('discountLbl')} (${appliedPromo.code})</span><span>−₹${pd}</span></div>`:''}<div class="cb-row total"><span>${t('cartTotal')}</span><span>₹${cartTotalDisplay()}</span></div></div>`;
    box.innerHTML=html;
    if(cbt) cbt.textContent='₹'+cartTotalDisplay();
    if(cbtn) cbtn.disabled=false;
    updateCartBadge();
  }

  // ═══════ CHECKOUT ═══════
  function goToCheckout(){
    if(!isLoggedIn()){ showAuth(); return; }
    if(!cart.length){ showToast('⚠️ '+t('cartEmpty'),'warning'); return; }
    // re-validate cutoff for each cart date/meal
    for(const it of cart){ const off=offsetOfDate(it.deliveryDate); if(off<0||off>2||!mealsAvail(off)[it.meal].ok){ removeCart(it.id); showToast('⚠️ '+mealTitle(it.meal)+' ('+it.deliveryLabel+') booking closed — removed from cart.','warning'); return; } }
    renderSummary();
    document.getElementById('barTotal2').textContent='₹'+cartTotalDisplay();
    document.getElementById('township').value=CFG.township;
    prefillCustomer();
    showView('page2');
  }
  function goToPage1(){ showView('page1'); refreshAvailability(); }

  function prefillCustomer(){
    document.getElementById('phoneNo').value=SESSION.phone;
    if(!document.getElementById('customerName').value) document.getElementById('customerName').value=SESSION.name||'';
    const c=storeGet('fbt_addr'); let filled=false;
    if(c){ if(c.society){ document.getElementById('society').value=c.society; filled=true; } if(c.flatNo){ document.getElementById('flatNo').value=c.flatNo; filled=true; } }
    document.getElementById('savedNote').classList.toggle('show',filled);
  }
  function saveAddr(d){
    const a=storeGet('fbt_addr')||{};
    const isOff=(d.deliveryType||deliveryType)==='office';
    const out={ deliveryType:(d.deliveryType||deliveryType),
      society: isOff?(a.society||''):(d.society||''), flatNo: isOff?(a.flatNo||''):(d.flatNo||''),
      company: isOff?(d.society||d.company||''):(a.company||''), empId: isOff?(d.flatNo||d.empId||''):(a.empId||'') };
    storeSet('fbt_addr',out);
  }

  function renderSummary(){
    let html='', lastDate='';
    cart.slice().sort(mealSort).forEach(it=>{
      if(it.deliveryDate!==lastDate){ lastDate=it.deliveryDate; html+=`<div class="cust-label" style="margin-top:8px;">📅 ${it.deliveryLabel} · ${it.day}</div>`; }
      html+=`<div class="sum-row"><span class="l">${cartTitleLine(it)}</span><span>₹${unitPrice(it)*it.qty}</span></div>`;
      html+=`<div class="sum-sub">${cartLineDesc(it)}</div>`;
    });
    html+=`<div class="sum-row" style="margin-top:6px;"><span class="l">🛵 ${t('deliveryLbl')}${feeDates()>1?(' × '+feeDates()):''}</span><span>₹${deliveryFeeTotal()}</span></div>`;
    html+=`${appliedPromo?`<div class="sum-row" style="color:var(--ok);"><span class="l">🎟️ ${t('discountLbl')} (${appliedPromo.code})</span><span>−₹${promoDiscountNow()}</span></div>`:''}<div class="sum-total"><span>Total</span><span>₹${cartTotalDisplay()}</span></div>`;
    document.getElementById('summaryCard').innerHTML=html;
  }

  // ═══════ VALIDATION ═══════
  function setValid(id,e){ const el=document.getElementById(id); el.classList.remove('error'); el.classList.add('valid'); document.getElementById(e).classList.remove('show'); }
  function setError(id,e){ const el=document.getElementById(id); el.classList.add('error'); el.classList.remove('valid'); document.getElementById(e).classList.add('show'); }
  function clearErr(id,e){ document.getElementById(id).classList.remove('error'); document.getElementById(e).classList.remove('show'); }
  function validateSociety(){ const v=document.getElementById('society').value; v?setValid('society','err-society'):setError('society','err-society'); return !!v; }
  function validateFlat(){ const el=document.getElementById('flatNo'); let v=el.value.trim().toUpperCase().replace(/\s+/g,''); const m=v.match(/^([A-Z]{1,3})[-\/]?(\d{1,4})$/); if(m){ el.value=m[1]+'-'+m[2]; setValid('flatNo','err-flatNo'); return true; } setError('flatNo','err-flatNo'); return false; }
  function validateCompany(){ const v=document.getElementById('company').value; v?setValid('company','err-company'):setError('company','err-company'); return !!v; }
  function validateEmpId(){ const el=document.getElementById('empId'); const v=el.value.trim().toUpperCase(); el.value=v; const ok=v.length>=2; ok?setValid('empId','err-empId'):setError('empId','err-empId'); return ok; }
  function validateName(){ const v=document.getElementById('customerName').value.trim(); const ok=v.length>=2 && /^[a-zA-Z\s]+$/.test(v); ok?setValid('customerName','err-name'):setError('customerName','err-name'); return ok; }
  function setPay(p){ payment=p; document.getElementById('pay-COD').classList.toggle('sel',p==='COD'); document.getElementById('pay-UPI').classList.toggle('sel',p==='UPI'); }

  // ═══════ WHATSAPP ═══════
  function waForDate(dateStr, addr){
    const items=cart.filter(it=>it.deliveryDate===dateStr).sort(mealSort);
    let msg=`🍱 *NEW TIFFIN ORDER*\n━━━━━━━━━━━━━━\n`;
    msg+=`📅 *Delivery:* ${items[0].deliveryLabel} (${items[0].day})\n`;
    msg+=`👤 *Name:* ${addr.name}\n📱 *Phone:* ${addr.phone} ✓\n`;
    msg+=`📍 *Address:* ${addr.society}, ${CFG.township}, Flat ${addr.flatNo}\n━━━━━━━━━━━━━━\n`;
    let tot=0;
    items.forEach(it=>{ const lt=unitPrice(it)*it.qty; tot+=lt; msg+=`${MEAL_META[it.meal].emoji} *${mealTitle(it.meal)} × ${it.qty}* — ₹${lt}\n`; const dsc=cartLineDesc(it); if(dsc)msg+=`   • ${dsc}\n`; });
    if(addr.note) msg+=`📝 *Note:* ${addr.note}\n`;
    msg+=`━━━━━━━━━━━━━━\n💰 *Total: ₹${tot}*\n💳 *Payment:* ${addr.payment==='COD'?'Cash on Delivery':'UPI on Delivery'}`;
    return msg;
  }

  // ═══════ PLACE ORDER (cart → per-date orders) ═══════
  function placeOrder(){
    if(!isLoggedIn()){ showAuth(); return; }
    const okN=validateName();
    const okLoc=(deliveryType==='office') ? (validateCompany() & validateEmpId()) : (validateSociety() & validateFlat());
    if(!okLoc||!okN){ showToast(t('completeFields'),'warning'); return; }
    const isOff=(deliveryType==='office');
    const addr={ society: isOff?document.getElementById('company').value:document.getElementById('society').value,
                 flatNo: isOff?document.getElementById('empId').value.trim():document.getElementById('flatNo').value.trim(),
                 name:document.getElementById('customerName').value.trim(), phone:SESSION.phone,
                 note:document.getElementById('orderNote')?document.getElementById('orderNote').value.trim():'', payment:payment };
    saveAddr(addr);

    const btn=document.getElementById('placeBtn'); btn.textContent='⏳ ...'; btn.disabled=true;
    // Ek order = ek meal. Har (date, meal) combination ka alag payload — teeno meal 3 orders.
    const groups=[];
    [...new Set(cart.map(it=>it.deliveryDate))].sort().forEach(dstr=>{
      MEALS.forEach(m=>{ if(cart.some(it=>it.deliveryDate===dstr && it.meal===m)) groups.push({dstr, meal:m}); });
    });
    const firstKey = groups.length ? (groups[0].dstr+'|'+groups[0].meal) : '';

    const payloads=groups.map(({dstr, meal})=>{
      const lines=cart.filter(it=>it.deliveryDate===dstr && it.meal===meal);
      const p={ action:'order', token:SESSION.token, deliveryDate:dstr, deliveryLabel:lines[0].deliveryLabel, day:lines[0].day,
        society:addr.society, flatNo:addr.flatNo, deliveryType:deliveryType, name:addr.name, note:addr.note, payment:addr.payment, scheme:CFG.township,
        editRow:(editingRow && lines[0].__editRow===editingRow)?editingRow:undefined,
        items:lines.map(it=>({meal:it.meal,tiffinType:it.tiffinType||'',qty:it.qty,sabzi:it.sabzi||'',butterRoti:!!it.butterRoti,extraRoti:it.extraRoti||0,dahi:!!it.dahi,extraSabzi:!!it.extraSabzi,timeSlot:it.timeSlot||''})) };
      // Coupon sirf pehle order (earliest date ka pehla meal) par
      if(appliedPromo && (dstr+'|'+meal)===firstKey){ p.couponCode=appliedPromo.code; p.applyCoupon='1'; }
      // Sirf is meal ki qty; baaki 0
      MEALS.forEach(mm=>{ p[mm+'Qty']=0; });
      const cnt={}; lines.forEach(x=>{ const nm=x.variantName||x.tiffinType||'—'; cnt[nm]=(cnt[nm]||0)+x.qty; });
      const variantStr=Object.keys(cnt).map(nm=>cnt[nm]+' '+nm).join(' + ');
      p[meal+'Qty']= lines.reduce((s,x)=>s+x.qty,0);
      p[meal+'TimeSlot']= [...new Set(lines.map(x=>x.timeSlot).filter(Boolean))].join(' / ');
      if(meal==='breakfast'){
        p.breakfastTiffin=variantStr;
      } else {
        p[meal+'Tiffin']=variantStr;
        const tag=x=>lines.length>1?(' ['+(x.variantName||x.tiffinType)+']'):'';
        p[meal+'Sabzi']=[...new Set(lines.map(x=>x.sabzi+tag(x)))].join(' + ');
        p[meal+'Roti']=[...new Set(lines.map(x=>(x.butterRoti?'Butter':'Plain')+tag(x)))].join(' + ');
        p[meal+'Butter']=lines.some(x=>x.butterRoti)?1:0;
        p[meal+'ExtraRoti']=lines.reduce((s,x)=>s+(x.extraRoti||0)*x.qty,0);
        p[meal+'Dahi']=lines.some(x=>x.dahi)?1:0;
        p[meal+'ExtraSabzi']=lines.some(x=>x.extraSabzi)?1:0;
        const parts=[]; lines.forEach(x=>{ const a=[]; if(x.extraRoti)a.push('+'+x.extraRoti+' Extra Roti'); if(x.dahi)a.push('Dahi'); if(x.extraSabzi)a.push('Extra Sabzi'); if(a.length)parts.push(a.join(', ')+tag(x)); });
        p[meal+'Addons']=parts.join(' · ')||'None';
      }
      return { dstr, meal, p };
    });

    // send sequentially
    let ok=0, dup=0, fail=0, sessionDead=false, serverTotal=0, couponWarn='', promoLine='';
    const results=[];
    (async ()=>{
      for(const {dstr,meal,p} of payloads){
        try{ const j=await apiPost(p);
          if(j.status==='success') { ok++; serverTotal+=Number(j.total)||0; if(j.couponRejected) couponWarn=j.couponRejected; if(j.promo) promoLine=j.promo; results.push({dstr,ok:true}); }
          else if(j.status==='duplicate') { dup++; results.push({dstr,dup:true}); }
          else if(j.status==='invalid_session') { sessionDead=true; break; }
          else { fail++; results.push({dstr,fail:true}); }
        }catch(e){ fail++; results.push({dstr,fail:true}); }
      }
      if(sessionDead){ forceLogout(); return; }

      // WhatsApp for successful dates
      const okDates=results.filter(r=>r.ok).map(r=>r.dstr);
      let waURL='';
      if(okDates.length){ waURL='https://wa.me/'+OWNER_WHATSAPP+'?text='+encodeURIComponent(okDates.map(dd=>waForDate(dd,addr)).join('\n\n')); }

      if(ok>0){
        if(waURL){ document.getElementById('waFallback').href=waURL; window.open(waURL,'_blank'); }
        let m=(LANG==='en')?`Your ${ok} order${ok>1?'s have':' has'} been placed successfully.`:`Aapke ${ok} order successfully place ho gaye hain.`;
        if(dup) m+=(LANG==='en')?` ${dup} date(s) already had an order.`:` ${dup} date par pehle se order maujood tha.`;
        if(promoLine) m+=' 🎟️ '+promoLine+' applied.';
        document.getElementById('successMsg').textContent=m;
        // Server-returned total (authoritative) — exactly jo charge hua
        const grandTotal=serverTotal;
        cart=[]; editingRow=null; appliedPromo=null; saveCart(); payRef=makePayRef();
        document.getElementById('orderFormWrap').classList.add('hidden');
        document.getElementById('page2Bar').classList.add('hidden');
        document.getElementById('successCard').classList.remove('hidden');
        if(payment==='UPI'){ renderUpiPay(grandTotal); }
        else { const bx=document.getElementById('upiPayBox'); if(bx){ bx.classList.remove('hidden'); bx.innerHTML=`<div class="cod-note">💵 ${t('codNote')} <b>₹${grandTotal}</b></div>`; } }
        if(couponWarn) showToast('⚠️ Coupon: '+couponWarn,'warning');
        window.scrollTo(0,0);
      } else {
        btn.textContent=t('placeOrder'); btn.disabled=false;
        if(dup && !fail) showToast('⚠️ '+t('dupMsg'),'warning');
        else showToast(t('orderFailed'),'error');
      }
    })();
  }

  // ═══════ ONLINE UPI PAYMENT (Option A) ═══════
  let payRef='';
  function makePayRef(){
    const d=new Date(), p=(SESSION&&SESSION.phone)?String(SESSION.phone).slice(-4):'0000';
    return 'FBT'+String(d.getDate()).padStart(2,'0')+String(d.getMonth()+1).padStart(2,'0')+p+String(Math.floor(Math.random()*90)+10);
  }
  function upiDeepLink(amount, scheme){
    const pa=encodeURIComponent(CFG.upiId||'');
    const pn=encodeURIComponent(CFG.upiName||'Flying Birds Tiffin');
    const am=encodeURIComponent(Number(amount).toFixed(2));   // 2-decimal — strict PSPs ke liye
    const tn=encodeURIComponent('Tiffin order '+payRef);      // per-order note → bank statement me match
    const tr=encodeURIComponent(payRef);                      // unique transaction ref
    const q=`pa=${pa}&pn=${pn}&am=${am}&cu=INR&tn=${tn}&tr=${tr}`;
    if(scheme==='gpay')   return 'tez://upi/pay?'+q;
    if(scheme==='paytm')  return 'paytmmp://pay?'+q;
    if(scheme==='phonepe')return 'phonepe://pay?'+q;
    return 'upi://pay?'+q;
  }
  function renderUpiPay(amount){
    const box=document.getElementById('upiPayBox'); if(!box)return;
    if(!CFG.upiId || amount<=0){ box.classList.add('hidden'); box.innerHTML=''; return; }
    if(!payRef) payRef=makePayRef();
    const link=upiDeepLink(amount);
    const qr='https://api.qrserver.com/v1/create-qr-code/?size=220x220&data='+encodeURIComponent(link);
    box.classList.remove('hidden');
    box.innerHTML=`
      <div class="upb-title">${t('payNowUpi')}</div>
      <div class="upb-amt">₹${amount}</div>
      <div class="upb-qr"><img src="${qr}" alt="UPI QR" onerror="this.parentElement.style.display='none'"></div>
      <div class="upb-scan">${t('scanToPay')}</div>
      <div class="upb-vpa" onclick="copyUpiId()">${CFG.upiId}<span>${t('copyId')}</span></div>
      <div class="upb-apps">
        <a href="${upiDeepLink(amount,'gpay')}">GPay</a>
        <a href="${upiDeepLink(amount,'paytm')}">Paytm</a>
        <a href="${upiDeepLink(amount,'phonepe')}">PhonePe</a>
      </div>
      <div class="upb-ref">${t('payRefLbl')}: <b>${payRef}</b></div>
      <div class="upb-note">${t('upiPayNote')}</div>`;
  }
  function copyUpiId(){ try{ navigator.clipboard.writeText(CFG.upiId); showToast('📋 '+t('copied'),'success'); }catch(e){} }

  function resetAll(){
    cart=[]; builder=freshBuilder(); pickDefaultDate(); renderDateSelector(); pickActiveMeal();
    setPay('COD');
    document.getElementById('placeBtn').textContent=t('placeOrder'); document.getElementById('placeBtn').disabled=false;
    document.getElementById('orderFormWrap').classList.remove('hidden');
    document.getElementById('page2Bar').classList.remove('hidden');
    document.getElementById('successCard').classList.add('hidden');
    goToPage1(); renderMealTabs(); renderMealPanel(); renderCart(); loadMyOrders();
  }

  // ═══════ SUBSCRIPTION ═══════
  let subState={ meals:{}, days:[], time:{}, startDate:'', endDate:'', society:'', flat:'', payment:'COD' };
  const SUB_DAY_LABEL={ en:{monday:'Mon',tuesday:'Tue',wednesday:'Wed',thursday:'Thu',friday:'Fri',saturday:'Sat',sunday:'Sun'}, hinglish:{monday:'Mon',tuesday:'Tue',wednesday:'Wed',thursday:'Thu',friday:'Fri',saturday:'Sat',sunday:'Sun'}, hi:{monday:'सोम',tuesday:'मंगल',wednesday:'बुध',thursday:'गुरु',friday:'शुक्र',saturday:'शनि',sunday:'रवि'}, gu:{monday:'સોમ',tuesday:'મંગળ',wednesday:'બુધ',thursday:'ગુરુ',friday:'શુક્ર',saturday:'શનિ',sunday:'રવિ'} };
  function subDayLabel(d){ return (SUB_DAY_LABEL[LANG]||SUB_DAY_LABEL.en)[d]; }

  function loadSub(){
    document.getElementById('subActiveBox').innerHTML='<div style="color:#999;font-size:13px;">Loading...</div>';
    document.getElementById('subFormBox').innerHTML='';
    fetch(GOOGLE_SCRIPT_URL+'?action=mySub&token='+encodeURIComponent(SESSION.token)).then(r=>r.json()).then(j=>{
      if(j.status==='invalid_session'){ forceLogout(); return; }
      renderSubActive(j.sub); renderSubForm(j.sub);
    }).catch(()=>{ document.getElementById('subActiveBox').innerHTML='<div style="color:#999;font-size:13px;">Network error.</div>'; });
  }

  function renderSubActive(sub){
    const box=document.getElementById('subActiveBox');
    if(!sub || sub.status!=='Active'){ box.innerHTML=''; return; }
    const mealTxt=Object.keys(sub.meals).map(m=>MEAL_META[m].emoji+' '+mealTitle(m)+(m!=='breakfast'?(' ('+(sub.meals[m].tiffinType==='mini'?t('miniTiffin'):t('fullTiffin'))+')'):'')).join(', ');
    const daysTxt=sub.days.map(subDayLabel).join(' · ');
    const skips=(sub.skipDates||[]).length?('⏭️ '+t('subSkipped')+': '+sub.skipDates.map(fmtDateStr).join(', ')):'';
    box.innerHTML=`<div class="sub-active-card">
      <h3>🔁 ${t('subActive')} <span class="sub-badge">${sub.days.length} ${t('subDaysWeek')}</span></h3>
      <div class="row">🍱 ${mealTxt}</div>
      <div class="row">📅 ${daysTxt}</div>
      <div class="row">🗓️ ${fmtDateStr(sub.startDate)} → ${fmtDateStr(sub.endDate)}</div>
      <div class="row">🏠 ${sub.society} · ${sub.flat} · 💳 ${sub.payment}</div>
      ${skips?`<div class="row">${skips}</div>`:''}
      <div class="sub-skip-row">
        <input type="date" id="subSkipDate" onfocus="this.min=dateWithOffsetStr(1)">
        <button onclick="doSkip()">⏭️ ${t('subSkipBtn')}</button>
      </div>
      <button class="cancel-btn" style="margin-top:10px;background:rgba(255,255,255,0.15);color:#fff;" onclick="doCancelSub()">🚫 ${t('subCancelBtn')}</button>
    </div>
    <div class="cust-label" style="margin-top:6px;">✏️ ${t('subEditNote')}</div>`;
  }

  function renderSubForm(sub){
    // Pre-fill from existing sub or saved address (skip when just re-rendering local edits)
    if(sub && sub.status==='Active' && !sub.__norerender){ subState={ meals:JSON.parse(JSON.stringify(sub.meals)), days:sub.days.slice(), time:Object.assign({},sub.time), startDate:sub.startDate, endDate:sub.endDate, society:sub.society, flat:sub.flat, payment:sub.payment }; }
    else if(!sub){
      const sa=storeGet('fbt_addr')||{};
      subState={ meals:{}, days:[], time:{}, startDate:dateWithOffsetStr(1), endDate:'', society:sa.society||(CFG.societies[0]||''), flat:sa.flatNo||'', payment:'COD' };
      const d=new Date(getISTNow().getTime()+30*86400000); subState.endDate=fmtYMD(d);
    }
    const socOpts=CFG.societies.map(s=>`<option value="${s}" ${subState.society===s?'selected':''}>${s}</option>`).join('');
    const mealCard=(m)=>{
      const on=!!subState.meals[m]; const mm=subState.meals[m]||{};
      const sabziOpts=(m!=='breakfast')?(MENU.monday[m].sabziOptions.map(o=>`<option value="${o}" ${mm.sabzi===o?'selected':''}>${o}</option>`).join('')):'';
      const timeOpts=TIME_SLOTS[m].map(s=>`<option value="${s}" ${(subState.time[m]===s)?'selected':''}>${s}</option>`).join('');
      return `<div class="sub-meal-card ${on?'on':''}">
        <div class="sub-meal-head"><span class="nm">${MEAL_META[m].emoji} ${mealTitle(m)}</span>
          <div class="toggle-switch ${on?'active':''}" onclick="subToggleMeal('${m}')"></div></div>
        ${on?`<div class="sub-meal-body">
          ${m!=='breakfast'?`<div class="tiffin-opts" style="margin-bottom:8px;">
            <div class="tiffin-card ${mm.tiffinType!=='full'?'':'sel'}" style="padding:8px;" onclick="subSetTiffin('${m}','full')"><div class="tc-name">🍱 ${t('fullTiffin')}</div></div>
            <div class="tiffin-card ${mm.tiffinType==='mini'?'sel':''}" style="padding:8px;" onclick="subSetTiffin('${m}','mini')"><div class="tc-name">🥗 ${t('miniTiffin')}</div></div>
          </div>
          <div class="cust-row"><span>${t('selectSabzi')}</span><select onchange="subSetMeal('${m}','sabzi',this.value)"><option value="">${t('subAnySabzi')}</option>${sabziOpts}</select></div>`:''}
          <div class="cust-row"><span>${t('deliveryTime')}</span><select onchange="subSetMeal('${m}','__time',this.value)">${timeOpts}</select></div>
        </div>`:''}
      </div>`;
    };
    document.getElementById('subFormBox').innerHTML=`
      <div class="cust-label">1️⃣ ${t('subPickMeals')}</div>
      ${mealCard('breakfast')}${mealCard('lunch')}${mealCard('dinner')}
      <div class="cust-label">2️⃣ ${t('subPickDays')}</div>
      <div class="sub-quick">
        <button onclick="subQuickDays('weekdays')">${t('subWeekdays')}</button>
        <button onclick="subQuickDays('all')">${t('subAllDays')}</button>
        <button onclick="subQuickDays('clear')">${t('subClear')}</button>
      </div>
      <div class="sub-days">${WEEKDAYS.map(d=>`<div class="sub-day ${subState.days.indexOf(d)>=0?'on':''}" onclick="subToggleDay('${d}')">${subDayLabel(d)}</div>`).join('')}</div>
      <div class="cust-label">3️⃣ ${t('subDateRange')}</div>
      <div class="dt-row">
        <div class="dt-cell"><span class="dt-lbl">${t('subStart')}</span><input type="date" id="subStart" value="${subState.startDate}" min="${dateWithOffsetStr(1)}" onchange="subState.startDate=this.value"></div>
        <div class="dt-cell"><span class="dt-lbl">${t('subEnd')}</span><input type="date" id="subEnd" value="${subState.endDate}" onchange="subState.endDate=this.value"></div>
      </div>
      <div class="cust-label">4️⃣ ${t('subDelivery')}</div>
      <div class="cust-row"><span>${t('society')}</span><select onchange="subState.society=this.value">${socOpts}</select></div>
      <div class="form-group" style="margin-top:8px;"><label>${t('flat')}</label><input type="text" id="subFlat" value="${subState.flat}" placeholder="D-706" maxlength="10" oninput="subState.flat=this.value"></div>
      <button class="admin-btn" style="margin-top:14px;" onclick="doSaveSub()">${sub&&sub.status==='Active'?('💾 '+t('subUpdate')):('✅ '+t('subStart2'))}</button>`;
  }

  function subToggleMeal(m){ if(subState.meals[m])delete subState.meals[m]; else subState.meals[m]={tiffinType:'full',sabzi:'',qty:1}; if(!subState.time[m])subState.time[m]=TIME_SLOTS[m][0]; renderSubForm(currentSubForRerender()); }
  function subSetTiffin(m,v){ if(subState.meals[m])subState.meals[m].tiffinType=v; renderSubForm(currentSubForRerender()); }
  function subSetMeal(m,k,v){ if(!subState.meals[m])return; if(k==='__time')subState.time[m]=v; else subState.meals[m][k]=v; }
  function subToggleDay(d){ const i=subState.days.indexOf(d); if(i>=0)subState.days.splice(i,1); else subState.days.push(d); renderSubForm(currentSubForRerender()); }
  function subQuickDays(w){ if(w==='weekdays')subState.days=['monday','tuesday','wednesday','thursday','friday']; else if(w==='all')subState.days=WEEKDAYS.slice(); else subState.days=[]; renderSubForm(currentSubForRerender()); }
  // keep form in "edit" mode during re-render without refetching
  function currentSubForRerender(){ return { status:'Active', meals:subState.meals, days:subState.days, time:subState.time, startDate:subState.startDate, endDate:subState.endDate, society:subState.society, flat:subState.flat, payment:subState.payment, skipDates:[] , __norerender:true}; }

  function doSaveSub(){
    if(!Object.keys(subState.meals).length){ showToast('⚠️ '+t('subPickMeals'),'warning'); return; }
    if(!subState.days.length){ showToast('⚠️ '+t('subPickDays'),'warning'); return; }
    if(!subState.startDate||!subState.endDate){ showToast('⚠️ '+t('subDateRange'),'warning'); return; }
    if(subState.endDate<subState.startDate){ showToast('⚠️ '+t('subEndAfter'),'warning'); return; }
    if(!subState.flat.trim()){ showToast('⚠️ '+t('flat'),'warning'); return; }
    apiPost({ action:'saveSub', token:SESSION.token, name:SESSION.name, society:subState.society, flat:subState.flat.trim(),
      meals:subState.meals, days:subState.days, time:subState.time, startDate:subState.startDate, endDate:subState.endDate, payment:subState.payment })
      .then(j=>{ if(j.status==='success'){ showToast('✅ '+t('subSaved'),'success'); loadSub(); } else if(j.status==='invalid_session')forceLogout(); else showToast('❌ '+srvMsg(j),'error'); })
      .catch(()=>showToast(t('errNetwork'),'error'));
  }
  function doCancelSub(){ if(!confirm(t('subCancelConfirm')))return;
    apiPost({action:'cancelSub',token:SESSION.token}).then(j=>{ if(j.status==='success'){ showToast('✅ '+t('subCancelled'),'success'); loadSub(); } else if(j.status==='invalid_session')forceLogout(); else showToast('❌ '+srvMsg(j),'error'); }).catch(()=>showToast(t('errNetwork'),'error')); }
  function doSkip(){ const el=document.getElementById('subSkipDate'); el.min=dateWithOffsetStr(1); const d=el.value; if(!d){ showToast('⚠️ '+t('subPickSkipDate'),'warning'); return; }
    apiPost({action:'skipSub',token:SESSION.token,date:d}).then(j=>{ if(j.status==='success'){ showToast(j.skipped?('⏭️ '+t('subSkipDone')):('↩️ '+t('subUnskipDone')),'success'); loadSub(); } else if(j.status==='invalid_session')forceLogout(); else showToast('❌ '+srvMsg(j),'error'); }).catch(()=>showToast(t('errNetwork'),'error')); }

  // ═══════ MY ORDERS ═══════
  function orderMealsText(o){ const tf=v=>v?(' 🍱 '+v):''; const sz=v=>v&&String(v).trim()?v:'Chef\'s choice'; const p=[]; if(Number(o.breakfastQty))p.push('🌅 '+mealTitle('breakfast')+' ×'+o.breakfastQty+(o.breakfastTimeSlot?' · 🕐 '+o.breakfastTimeSlot:'')); if(Number(o.lunchQty))p.push('☀️ '+sz(o.lunchSabzi)+' ×'+o.lunchQty+tf(o.lunchTiffin)+(o.lunchRoti?' ('+o.lunchRoti+')':'')+(o.lunchAddons&&o.lunchAddons!=='None'?' · '+o.lunchAddons:'')+(o.lunchTimeSlot?' · 🕐 '+o.lunchTimeSlot:'')); if(Number(o.dinnerQty))p.push('🌙 '+sz(o.dinnerSabzi)+' ×'+o.dinnerQty+tf(o.dinnerTiffin)+(o.dinnerRoti?' ('+o.dinnerRoti+')':'')+(o.dinnerAddons&&o.dinnerAddons!=='None'?' · '+o.dinnerAddons:'')+(o.dinnerTimeSlot?' · 🕐 '+o.dinnerTimeSlot:'')); return p.join('<br>'); }
  function fmtDateStr(ymd){
    const s=String(ymd);
    const p=s.split('-').map(Number);
    if(p.length===3 && p.every(n=>!isNaN(n))) return fmtLabel(new Date(p[0],p[1]-1,p[2]));
    const d=new Date(s);
    if(!isNaN(d.getTime())) return fmtLabel(d);
    return s;
  }
  const STATUS_LABEL={ Pending:'🕒 Order Received', Preparing:'👨‍🍳 Being Prepared', Delivered:'✅ Delivered', Cancelled:'❌ Cancelled' };
  let myOrdersCache=[], myOrdersIsHist=false;
  function renderMyOrders(list,isHist){
    myOrdersCache=list||[]; myOrdersIsHist=!!isHist;
    const box=document.getElementById('myOrdersList');
    if(!list.length){ box.innerHTML=`<div style="color:#999;font-size:13px;padding:16px 0;text-align:center;">${isHist?t('noHistory'):t('noUpcoming')}</div>`; return; }
    const mealMini=o=>{ const p=[]; if(Number(o.breakfastQty))p.push('🌅'+o.breakfastQty); if(Number(o.lunchQty))p.push('☀️'+o.lunchQty); if(Number(o.dinnerQty))p.push('🌙'+o.dinnerQty); return p.join('  '); };
    const pillColor=s=>({Pending:'background:var(--warnbg);color:var(--warn);',Preparing:'background:var(--accent-soft);color:var(--accent-dark);',Delivered:'background:var(--okbg);color:var(--ok);',Cancelled:'background:var(--dangerbg);color:var(--danger);'}[s]||'background:var(--bg);color:var(--muted);');
    box.innerHTML=list.map((o,i)=>`<div class="ord-row" onclick="openMyOrderModal(${i})">
      <div class="or-date">
        <div class="or-d1">📅 ${fmtDateStr(o.deliveryDate)}</div>
        <div class="or-d2">${mealMini(o)} · 💳 ${o.payment}</div>
        <span class="ord-pill" style="${pillColor(o.status)}">${STATUS_LABEL[o.status]||o.status}</span>${o.paymentStatus==='Paid'?(o.status==='Cancelled'?'<span class="ord-pill" style="background:var(--dangerbg);color:var(--danger);margin-left:4px;">REFUND DUE</span>':'<span class="ord-pill" style="background:var(--okbg);color:var(--ok);margin-left:4px;">PAID</span>'):''}
      </div>
      <div class="or-right"><div class="or-total">${o.total}</div></div>
      ${(myOrdersIsHist||o.status==='Delivered'||o.status==='Cancelled')?`<button class="or-re" title="Reorder" onclick="event.stopPropagation();reorderFromOrder(${i})">🔁</button>`:''}<span class="or-chev">›</span>
    </div>`).join('');
  }
  function reorderFromOrder(i){
    const o=myOrdersCache[i]; if(!o)return;
    const need=['breakfast','lunch','dinner'].filter(m=>Number(o[m+'Qty'])>0);
    if(!need.length)return;
    let off=-1;
    for(let k=0;k<=2;k++){ const av=mealsAvail(k); if(need.every(m=>av[m].ok)){ off=k; break; } }
    if(off<0){ showToast('⚠️ '+t('reorderNoSlot'),'warning'); return; }
    dateOffset=off; const dk=selDayKey(); const d=MENU[dk]||{};
    need.forEach(m=>{
      const vs=variantsFor(m);
      const str=String(o[m+'Tiffin']||'');
      const v=vs.find(x=>str.indexOf(x.name)>=0)||vs[0];
      const qty=1;
      const slotRaw=String(o[m+'TimeSlot']||'').split(' / ')[0];
      const slot=TIME_SLOTS[m].includes(slotRaw)?slotRaw:defaultTimeSlot(m);
      const item={ id:selDateStr()+'|'+m+'|'+v.id, deliveryDate:selDateStr(), deliveryLabel:fmtLabel(selDate()), day:dk.charAt(0).toUpperCase()+dk.slice(1), meal:m, qty:qty, timeSlot:slot, tiffinType:v.id, variantName:v.name };
      if(m!=='breakfast'){
        let sz=String(o[m+'Sabzi']||'').split(' + ')[0].replace(/\s*\[[^\]]*\]\s*$/,'').trim();
        if(!sz||sz==='N/A') sz=(d[m]&&d[m].sabziOptions&&d[m].sabziOptions[0])||'';
        item.sabzi=sz;
        const ad=String(o[m+'Addons']||'');
        item.butterRoti=/Butter/i.test(String(o[m+'Roti']||''));
        const er=ad.match(/\+(\d+)\s*Extra Roti/i);
        item.extraRoti=er?Math.min(6,Math.max(0,Math.round((parseInt(er[1],10)||0)/qty))):0;
        item.dahi=/\bDahi\b/i.test(ad);
        item.extraSabzi=/Extra Sabzi/i.test(ad);
      }
      const ix=cart.findIndex(x=>x.id===item.id); if(ix>=0)cart[ix]=item; else cart.push(item);
    });
    builder=freshBuilder();
    renderMealTabs(); renderMenuDateTime(); renderMealPanel(); updateCartBadge(); renderCart();
    showToast('🛒 '+t('reorderDone'),'success');
    showCartPage();
  }
  // Customer order details (reuses the #orderModal element)
  function openMyOrderModal(i){
    const o=myOrdersCache[i]; if(!o)return;
    document.getElementById('omName').textContent='📅 '+fmtDateStr(o.deliveryDate);
    document.getElementById('omMeta').innerHTML=(STATUS_LABEL[o.status]||o.status);
    const mealBlock=(emoji,title,qty,sabzi,tiffin,roti,addons,time)=>{
      if(!Number(qty))return '';
      const rows=[];
      rows.push(`<div class="om-line"><span class="l">Variant</span><span class="r">${tiffin||'—'}</span></div>`);
      if(title!=='Breakfast') rows.push(`<div class="om-line"><span class="l">Sabzi</span><span class="r">${(sabzi&&String(sabzi).trim())||'Chef&#39;s choice'}</span></div>`);
      if(roti&&title!=='Breakfast') rows.push(`<div class="om-line"><span class="l">Roti</span><span class="r">${roti}</span></div>`);
      if(addons&&addons!=='None') rows.push(`<div class="om-line"><span class="l">Add-ons</span><span class="r">${addons}</span></div>`);
      if(time) rows.push(`<div class="om-line"><span class="l">${t('deliveryTime').replace(/[⏰🕐]\s*/,'')}</span><span class="r">🕐 ${time}</span></div>`);
      return `<div class="om-meal"><div class="omm-head"><span>${emoji} ${title}</span><span class="omm-badge">× ${qty}</span></div>${rows.join('')}</div>`;
    };
    let body='';
    body+=mealBlock('🌅','Breakfast',o.breakfastQty,'',o.breakfastTiffin||mealTitle('breakfast'),'','',o.breakfastTimeSlot);
    body+=mealBlock('☀️','Lunch',o.lunchQty,o.lunchSabzi,o.lunchTiffin,o.lunchRoti,o.lunchAddons,o.lunchTimeSlot);
    body+=mealBlock('🌙','Dinner',o.dinnerQty,o.dinnerSabzi,o.dinnerTiffin,o.dinnerRoti,o.dinnerAddons,o.dinnerTimeSlot);
    if(o.note&&o.note!=='None') body+=`<div class="om-addr">📝 ${esc(o.note)}</div>`;
    body+=`<div class="om-total"><span class="t-lbl">💳 ${o.payment}${o.paymentStatus==='Paid'?(o.status==='Cancelled'?' · ⚠️ REFUND DUE':' · ✓ PAID'):''} · Total</span><span class="t-amt">${o.total}</span></div>`;
    const win=!myOrdersIsHist&&(o.status==='Pending'||o.status==='Preparing')&&canCancel(o);
    if(o.promo) body+=`<div class="om-addr" style="color:var(--ok);">🎟️ <b>${esc(o.promo)}</b></div>`;
    if(win){
      body+=`<div class="om-status-btns">
        <button style="border-color:var(--danger);background:var(--dangerbg);color:var(--danger);" onclick="closeOrderModal();cancelMyOrder(${o.row},'${o.deliveryDate}','${o.createdIso||''}')">${t('cancelOrder')}</button>
      </div>`;
    } else if(!myOrdersIsHist && o.status!=='Cancelled' && o.status!=='Delivered'){
      body+=`<div class="om-addr" style="font-size:11.5px;color:var(--muted);">${t('cancelWindowOver')}</div>`;
    }
    if(myOrdersIsHist||o.status==='Delivered'||o.status==='Cancelled'){
      body+=`<div class="om-status-btns"><button style="border-color:var(--accent);background:var(--accent-soft);color:var(--accent-dark);" onclick="closeOrderModal();reorderFromOrder(${i})">🔁 ${t('reorderBtn')}</button></div>`;
    }
    document.getElementById('omBody').innerHTML=body;
    document.getElementById('orderModal').classList.remove('hidden');
    document.body.style.overflow='hidden';
  }
  // Edit: load order back into cart, remember row so backend replaces it
  let editingRow=null;
  function editMyOrder(o){
    if(!canCancel(o.deliveryDate)){ showToast(t('cancelClosed'),'error'); return; }
    cart=[]; editingRow=o.row;
    const off=dateOffsetFromStr(o.deliveryDate);
    const lbl=fmtDateStr(o.deliveryDate), dayK=o.day||'';
    const push=(meal,tiffin,sabzi,roti,addons,qty,ts)=>{
      if(!Number(qty))return;
      const it={ id:o.deliveryDate+'|'+meal+(meal!=='breakfast'?('|'+(String(tiffin).toLowerCase().indexOf('mini')>=0?'mini':'full')):''), deliveryDate:o.deliveryDate, deliveryLabel:lbl, day:dayK, meal:meal, qty:Number(qty)||1, timeSlot:ts||'' };
      if(meal!=='breakfast'){ it.tiffinType=String(tiffin).toLowerCase().indexOf('mini')>=0?'mini':'full'; it.sabzi=String(sabzi).replace(/\s*\[.*?\]/g,'').split(' + ')[0].trim(); it.butterRoti=/Butter/i.test(String(roti)); const er=String(addons).match(/(\d+)\s*Extra Roti/); it.extraRoti=er?Number(er[1]):0; it.dahi=/Dahi/.test(String(addons)); it.extraSabzi=/Extra Sabzi/.test(String(addons)); }
      cart.push(it);
    };
    push('breakfast','','','','',o.breakfastQty,o.breakfastTimeSlot);
    push('lunch',o.lunchTiffin,o.lunchSabzi,o.lunchRoti,o.lunchAddons,o.lunchQty,o.lunchTimeSlot);
    push('dinner',o.dinnerTiffin,o.dinnerSabzi,o.dinnerRoti,o.dinnerAddons,o.dinnerQty,o.dinnerTimeSlot);
    updateCartBadge(); showToast('✏️ '+t('editLoaded'),'success'); showCartPage();
  }
  function dateOffsetFromStr(dstr){ for(let o=0;o<=2;o++){ if(dateWithOffsetStr(o)===dstr) return o; } return 0; }
  function loadMyOrders(dateOpt){
    if(!isLoggedIn())return; const box=document.getElementById('myOrdersList'); if(!box)return;
    box.innerHTML='<div style="color:#999;font-size:13px;">Loading...</div>';
    let url=GOOGLE_SCRIPT_URL+'?action=myOrders&token='+encodeURIComponent(SESSION.token); if(dateOpt)url+='&date='+encodeURIComponent(dateOpt);
    fetch(url).then(r=>r.json()).then(j=>{ if(j.status==='success')renderMyOrders(j.orders||[],!!dateOpt); else if(j.status==='invalid_session')forceLogout(); else box.innerHTML='<div style="color:#999;font-size:13px;">Could not load orders.</div>'; }).catch(()=>{ box.innerHTML='<div style="color:#999;font-size:13px;">Network error.</div>'; });
  }
  function viewHistory(){ const d=document.getElementById('histDate').value; if(!d){ showToast(t('selectDate'),'warning'); return; } loadMyOrders(d); }
  function cancelMyOrder(row,dd,createdIso){ if(!isLoggedIn()){ showAuth(); return; } if(!canCancel({deliveryDate:dd,createdIso:createdIso||''})){ showToast(t('cancelClosed'),'error'); return; } if(!confirm(t('confirmCancel')))return;
    apiPost({action:'cancelOrder',token:SESSION.token,row:row}).then(j=>{ if(j.status==='success'){ showToast(t('orderCancelled'),'success'); loadMyOrders(); } else if(j.status==='invalid_session')forceLogout(); else showToast(j.message||'Could not cancel.','error'); }).catch(()=>showToast(t('errNetwork'),'error')); }

  // ═══════ ADMIN ═══════
  let adminCreds=null, adminMenuWorking=null, adminPrevDay='monday', adminOrders=[], adminUsers=[], orderFilter='All';
  function showAdminLogin(){ showView('adminLogin'); }
  function hideAdmin(){ isLoggedIn()?showLanding():showPublic(); }
  function adminLogout(){ adminCreds=null; storeDel('fbt_admin'); stopAlertPolling(); stopRing(); hideAdmin(); }
  function adminTab(tb){ ['orders','users','menu','config','stats','variants','promos'].forEach(x=>{ const v=document.getElementById('aview-'+x); const b=document.getElementById('atab-'+x); if(v)v.classList.toggle('hidden',x!==tb); if(b)b.classList.toggle('active',x===tb); }); if(tb==='variants') openVariantsEditor(); if(tb==='promos') loadPromos(); }

  // ═══════ ADMIN PROMOS ═══════
  let adminPromos=[];
  function loadPromos(){
    if(!adminCreds)return;
    fetch(`${GOOGLE_SCRIPT_URL}?action=getpromos&user=${encodeURIComponent(adminCreds.user)}&pass=${encodeURIComponent(adminCreds.pass)}`)
      .then(r=>r.json()).then(j=>{ if(j.status==='success'){ adminPromos=j.promos||[]; renderPromoList(); } })
      .catch(()=>{ document.getElementById('promoList').innerHTML='<p style="text-align:center;color:#999;">Network error.</p>'; });
  }
  function renderPromoList(){
    const box=document.getElementById('promoList'); if(!box)return;
    if(!adminPromos.length){ box.innerHTML='<p style="text-align:center;color:#999;font-size:12px;">Abhi koi promo nahi. Upar se pehla banao 👆</p>'; return; }
    box.innerHTML=adminPromos.map((p,i)=>`
      <div class="pf-box" style="margin-bottom:10px;${p.active?'':'opacity:0.55;'}">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:15px;font-weight:900;">🎟️ ${p.code}</span>
          <span style="font-size:12px;font-weight:800;color:var(--accent-dark);">${p.type==='PERCENT'?(p.value+'% off'+(p.maxDiscount?(' · max ₹'+p.maxDiscount):'')):('₹'+p.value+' off')}</span>
        </div>
        <div style="font-size:11px;color:var(--muted);margin-top:5px;line-height:1.6;">
          ${p.visible?'📢 Visible · ':''}${p.minOrder?('Min ₹'+p.minOrder+' · '):''}${p.firstOnly?'🆕 First order only · ':''}Used: <b>${p.used}</b>${p.totalLimit?('/'+p.totalLimit):''} · Per-user: ${p.perUser}${p.expiry?(' · Exp: '+p.expiry):''}
        </div>
        <div style="display:flex;gap:8px;margin-top:10px;">
          <button class="inp-mini" style="cursor:pointer;font-weight:800;${p.active?'border-color:var(--ok);color:var(--ok);background:var(--okbg);':'color:var(--muted);'}" onclick="togglePromoFE(${i})">${p.active?'✓ Active':'Inactive'}</button>
          <button class="inp-mini" style="cursor:pointer;font-weight:800;" onclick="editPromoFE(${i})">✏️ Edit</button>
          <button class="inp-mini" style="cursor:pointer;font-weight:800;border-color:var(--danger);color:var(--danger);" onclick="delPromoFE(${i})">🗑️</button>
        </div>
      </div>`).join('');
  }
  function promoFormData(){
    return { action:'savepromo', user:adminCreds.user, pass:adminCreds.pass,
      code:document.getElementById('pmCode').value, type:document.getElementById('pmType').value,
      value:document.getElementById('pmValue').value, maxDiscount:document.getElementById('pmMaxD').value,
      minOrder:document.getElementById('pmMinO').value, expiry:document.getElementById('pmExp').value,
      perUser:document.getElementById('pmPerU').value||'1', totalLimit:document.getElementById('pmTotL').value||'0',
      firstOnly:document.getElementById('pmFirst').checked?'1':'0', visible:document.getElementById('pmVisible').checked?'1':'0', active:'1' };
  }
  function savePromoFE(){
    const d=promoFormData();
    if(!d.code.trim()||!(parseInt(d.value,10)>0)){ showToast('⚠️ Code and value are both required.','warning'); return; }
    const btn=document.getElementById('pmSaveBtn'); btn.disabled=true; btn.textContent='⏳ Saving…';
    apiPost(d).then(j=>{
      btn.disabled=false; btn.textContent='💾 Save Promo';
      if(j.status==='success'){ adminPromos=j.promos||[]; renderPromoList(); ['pmCode','pmValue','pmMaxD','pmMinO','pmExp','pmPerU','pmTotL'].forEach(id=>document.getElementById(id).value=''); document.getElementById('pmFirst').checked=false; document.getElementById('pmVisible').checked=false; showToast('✅ Promo saved','success'); }
      else showToast('❌ '+(j.message||'Failed'),'error');
    }).catch(()=>{ btn.disabled=false; btn.textContent='💾 Save Promo'; showToast(t('errNetwork'),'error'); });
  }
  function editPromoFE(i){
    const p=adminPromos[i]; if(!p)return;
    document.getElementById('pmCode').value=p.code; document.getElementById('pmType').value=p.type;
    document.getElementById('pmValue').value=p.value; document.getElementById('pmMaxD').value=p.maxDiscount||'';
    document.getElementById('pmMinO').value=p.minOrder||''; document.getElementById('pmExp').value=p.expiry||'';
    document.getElementById('pmPerU').value=p.perUser; document.getElementById('pmTotL').value=p.totalLimit||'';
    document.getElementById('pmFirst').checked=p.firstOnly;
    document.getElementById('pmVisible').checked=!!p.visible;
    window.scrollTo(0,0);
  }
  function togglePromoFE(i){
    const p=adminPromos[i]; if(!p)return;
    apiPost({ action:'savepromo', user:adminCreds.user, pass:adminCreds.pass, code:p.code, type:p.type, value:p.value, maxDiscount:p.maxDiscount, minOrder:p.minOrder, expiry:p.expiry, perUser:p.perUser, totalLimit:p.totalLimit, firstOnly:p.firstOnly?'1':'0', visible:p.visible?'1':'0', active:p.active?'0':'1' })
      .then(j=>{ if(j.status==='success'){ adminPromos=j.promos||[]; renderPromoList(); } });
  }
  function delPromoFE(i){
    const p=adminPromos[i]; if(!p)return;
    if(!confirm('Delete promo '+p.code+'?'))return;
    apiPost({action:'deletepromo',user:adminCreds.user,pass:adminCreds.pass,code:p.code})
      .then(j=>{ if(j.status==='success'){ adminPromos=j.promos||[]; renderPromoList(); showToast('🗑️ Deleted',''); } });
  }

  function adminLogin(){
    const u=document.getElementById('adminUser').value.trim(), p=document.getElementById('adminPass').value;
    if(!u||!p){ showToast('⚠️ Enter username and password.','warning'); return; }
    const btn=document.getElementById('loginBtn'); btn.textContent='⏳ ...'; btn.disabled=true;
    fetch(`${GOOGLE_SCRIPT_URL}?action=stats&user=${encodeURIComponent(u)}&pass=${encodeURIComponent(p)}`).then(r=>r.json()).then(j=>{
      btn.textContent='🔓 Login'; btn.disabled=false;
      if(j.status!=='success'){ showToast('❌ Invalid username or password.','error'); return; }
      adminCreds={user:u,pass:p}; storeSet('fbt_admin',adminCreds);
      showView('adminPanel'); fillStats(j); initMenuEditor(); initConfigEditor(); adminTab('orders'); loadOrders(); loadUsers(); updateAlertToggleUI(); startAlertPolling(); checkNewOrders();
    }).catch(()=>{ btn.textContent='🔓 Login'; btn.disabled=false; showToast(t('errNetwork'),'error'); });
  }
  // Refresh ke baad admin panel tabhi restore karo jab refresh se pehle admin panel hi khula tha.
  function restoreAdmin(){
    const a=storeGet('fbt_admin'); if(!a||!a.user||!a.pass) return false;
    adminCreds=a;                                  // creds cached — password dobara nahi maangega
    if(storeGet('fbt_view')!=='adminPanel') return false;   // customer/public page par tha => admin mat kholo
    fetch(`${GOOGLE_SCRIPT_URL}?action=stats&user=${encodeURIComponent(a.user)}&pass=${encodeURIComponent(a.pass)}`).then(r=>r.json()).then(j=>{
      if(j.status!=='success'){ adminCreds=null; storeDel('fbt_admin'); return; }
      showView('adminPanel'); fillStats(j); initMenuEditor(); initConfigEditor(); adminTab('orders'); loadOrders(); loadUsers(); updateAlertToggleUI(); startAlertPolling(); checkNewOrders();
    }).catch(()=>{ /* offline: creds set, panel dikha do */ showView('adminPanel'); initMenuEditor(); initConfigEditor(); adminTab('orders'); });
    return true;
  }

  let adminDateOffset=0;
  function setOrderDate(off){
    adminDateOffset=off;
    [0,1,2].forEach(o=>{ const b=document.getElementById('odt-'+o); if(b)b.classList.toggle('active',o===off); });
    loadOrders();
  }
  function adminDateLabels(){
    const names={en:['Today','Tomorrow','Day After']}; const dn=names.en;
    [0,1,2].forEach(o=>{ const b=document.getElementById('odt-'+o); if(b) b.innerHTML=dn[o]+'<br><span style="font-size:9.5px;font-weight:600;opacity:0.85;">'+fmtLabel(dateWithOffset(o))+'</span>'; });
  }
  function loadOrders(){ if(!adminCreds)return; adminDateLabels(); fillSocFilter();
    const dateStr=fmtYMD(dateWithOffset(adminDateOffset));
    document.getElementById('ordersList').innerHTML='<div style="text-align:center;color:#999;padding:20px;">Loading...</div>';
    fetch(`${GOOGLE_SCRIPT_URL}?action=orders&date=${dateStr}&user=${encodeURIComponent(adminCreds.user)}&pass=${encodeURIComponent(adminCreds.pass)}`).then(r=>r.json()).then(j=>{ if(j.status!=='success'){ showToast('❌ '+(j.message||'Load failed'),'error'); return; } adminOrders=j.orders||[]; renderOrders(); renderKitchen(); }).catch(()=>showToast(t('errNetwork'),'error')); }
  function setOrderFilter(f){ orderFilter=f; const c=document.getElementById('filterChips').children; for(let i=0;i<c.length;i++)c[i].classList.toggle('sel',c[i].getAttribute('data-f')===f); renderOrders(); }
  let socFilter='All';
  function fillSocFilter(){
    const sel=document.getElementById('ordSocFilter'); if(!sel)return;
    const socs=(CFG.societies||[]).map(s=>({v:s,l:'🏠 '+s}));
    const comps=(CFG.companies||[]).map(c=>({v:c.name,l:'🏢 '+c.name}));
    const opts=[{v:'All',l:'📍 All Locations'}].concat(socs,comps);
    sel.innerHTML=opts.map(o=>`<option value="${o.v}" ${socFilter===o.v?'selected':''}>${o.l}</option>`).join('');
  }
  function setSocFilter(v){ socFilter=v; renderOrders(); }
  function renderBulkBar(){
    const bar=document.getElementById('bulkBar'); if(!bar)return;
    const pend=adminOrders.filter(o=>o.status==='Pending'&&socMatch(o));
    const prep=adminOrders.filter(o=>o.status==='Preparing'&&socMatch(o));
    let html='';
    if(pend.length) html+=`<button class="bb-prep" onclick="bulkStatus('Pending','Preparing')">👨‍🍳 Sab Pending → Preparing (${pend.length})</button>`;
    if(prep.length) html+=`<button class="bb-done" onclick="bulkStatus('Preparing','Delivered')">✅ Sab Preparing → Delivered (${prep.length})</button>`;
    bar.innerHTML=html;
    bar.style.display=html?'flex':'none';
  }
  function bulkStatus(from,to){
    const rows=adminOrders.filter(o=>o.status===from&&socMatch(o)).map(o=>o.row);
    if(!rows.length)return;
    if(!confirm(rows.length+' order(s) → '+to+'?'))return;
    apiPost({action:'setstatusbulk',user:adminCreds.user,pass:adminCreds.pass,rows:rows,status:to}).then(j=>{
      if(j.status==='success'){
        adminOrders.forEach(o=>{ if(rows.indexOf(o.row)>=0) o.status=to; });
        renderOrders(); renderKitchen();
        showToast('✅ '+j.updated+' orders → '+to,'success');
      } else showToast('❌ '+(j.message||'Failed'),'error');
    }).catch(()=>showToast(t('errNetwork'),'error'));
  }
  function renderKitchen(){
    const active=adminOrders.filter(o=>o.status==='Pending'||o.status==='Preparing');
    const sum={bQty:0,soc:{}}; ['lunch','dinner'].forEach(m=>sum[m]={qty:0,mini:0,full:0,sabzi:{},butter:0,extraRoti:0,dahi:0,extraSabzi:0});
    active.forEach(o=>{ sum.bQty+=Number(o.breakfastQty)||0; const s2=o.society||'?'; sum.soc[s2]=(sum.soc[s2]||0)+1;
      ['lunch','dinner'].forEach(m=>{ const q=Number(o[m+'Qty'])||0; if(!q)return; const s=sum[m]; s.qty+=q; const tstr=String(o[m+'Tiffin']||''); const mm=tstr.match(/(\d+)\s*Mini/i); const mf=tstr.match(/(\d+)\s*Full/i); if(mm)s.mini+=Number(mm[1]); if(mf)s.full+=Number(mf[1]); if(!mm&&!mf)s.full+=q; const sb=(o[m+'Sabzi']&&String(o[m+'Sabzi']).trim())||'Chef\'s choice'; s.sabzi[sb]=(s.sabzi[sb]||0)+q; if(/Butter/i.test(String(o[m+'Roti'])))s.butter+=q; const ad=String(o[m+'Addons']||''); let exSum=0; const exAll=ad.match(/\+?(\d+)\s*Extra Roti/gi); if(exAll)exAll.forEach(x=>{const n=x.match(/(\d+)/); if(n)exSum+=Number(n[1]);}); s.extraRoti+=exSum; if(/Dahi/.test(ad))s.dahi+=q; if(/Extra Sabzi/.test(ad))s.extraSabzi+=q; }); });
    const sl=o=>Object.keys(o).map(k=>`<b>${o[k]}×</b> ${k}`).join(', ')||'—';
    const soc=Object.keys(sum.soc).map(k=>`${k}: <b>${sum.soc[k]}</b>`).join(' · ')||'—';
    const addonLine=(s)=>{ const a=[]; if(s.butter)a.push('Butter '+s.butter); if(s.extraRoti)a.push('+'+s.extraRoti+' Roti'); if(s.dahi)a.push('Dahi '+s.dahi); if(s.extraSabzi)a.push('Extra Sabzi '+s.extraSabzi); return a.length?a.join(' · '):'—'; };
    document.getElementById('kitchenSummary').innerHTML=`
      <div class="ks-head">👨‍🍳 Kitchen Summary <span class="ks-sub">Pending + Preparing</span></div>
      <div class="ks-grid">
        <div class="ks-cell"><div class="ks-n">${sum.bQty}</div><div class="ks-l">🌅 Breakfast</div></div>
        <div class="ks-cell"><div class="ks-n">${sum.lunch.qty}</div><div class="ks-l">☀️ Lunch</div></div>
        <div class="ks-cell"><div class="ks-n">${sum.dinner.qty}</div><div class="ks-l">🌙 Dinner</div></div>
      </div>
      ${sum.lunch.qty?`<div class="ks-row"><span class="ks-tag">☀️ Lunch</span> 🥗${sum.lunch.mini} Mini · 🍱${sum.lunch.full} Full<br><span class="ks-dim">${sl(sum.lunch.sabzi)}</span><br><span class="ks-dim">${addonLine(sum.lunch)}</span></div>`:''}
      ${sum.dinner.qty?`<div class="ks-row"><span class="ks-tag">🌙 Dinner</span> 🥗${sum.dinner.mini} Mini · 🍱${sum.dinner.full} Full<br><span class="ks-dim">${sl(sum.dinner.sabzi)}</span><br><span class="ks-dim">${addonLine(sum.dinner)}</span></div>`:''}
      <div class="ks-row"><span class="ks-tag">🏘️ Societies</span> ${soc}</div>`;
  }
  function socMatch(o){ return socFilter==='All' || o.society===socFilter; }
  function renderOrders(){
    const list=adminOrders.filter(o=>(orderFilter==='All'||o.status===orderFilter)&&socMatch(o)); const box=document.getElementById('ordersList');
    renderBulkBar();
    if(!list.length){ box.innerHTML='<div style="text-align:center;color:#999;padding:20px;">No orders ('+orderFilter+(socFilter!=='All'?(' · '+socFilter):'')+').</div>'; return; }
    box.innerHTML=list.map(o=>`<div class="oc" onclick="openOrderModal(${o.row})"><div class="oc-top"><span class="oc-name">${esc(o.name)}</span><span class="oc-status st-${o.status}">${STATUS_LABEL[o.status]||o.status}</span></div>
      <div class="oc-meal-box">${orderMealsText(o)}${o.note&&o.note!=='None'?'<br><span style="color:var(--muted);">📝 '+o.note+'</span>':''}${o.promo?'<br><span style="color:var(--ok);font-weight:800;">🎟️ '+o.promo+'</span>':''}</div>
      <div class="oc-info"><span>${o.deliveryType==='office'?`🏢 ${esc(o.society)} · Emp ${esc(o.flat)}`:`🏠 ${esc(o.society)} ${esc(o.flat)}`}</span><span>📞 <a href="tel:+91${o.phone}" onclick="event.stopPropagation()">${o.phone}</a></span></div>
      <div class="oc-info"><span>🕐 ${o.time}</span><span>💳 ${o.payment}${o.paymentStatus==='Paid'?(o.status==='Cancelled'?' <span class="paid-badge" style="background:var(--dangerbg);color:var(--danger);">REFUND DUE</span>':' <span class="paid-badge">PAID</span>'):''} · 💰 <b>${o.total}</b></span></div>
      <div class="oc-tap-hint">👆 Tap for details & status update</div></div>`).join('');
  }

  // ═══════ ADMIN ORDER DETAILS MODAL ═══════
  function openOrderModal(row){
    const o=adminOrders.find(x=>x.row===row); if(!o)return;
    document.getElementById('omName').textContent='👤 '+o.name;
    document.getElementById('omMeta').innerHTML=(STATUS_LABEL[o.status]||o.status)+' · 📅 '+fmtDateStr(o.deliveryDate);
    const mealBlock=(emoji,title,qty,sabzi,tiffin,roti,addons,time)=>{
      if(!Number(qty))return '';
      const rows=[];
      rows.push(`<div class="om-line"><span class="l">Variant</span><span class="r">${tiffin||'—'}</span></div>`);
      if(title!=='Breakfast') rows.push(`<div class="om-line"><span class="l">Sabzi</span><span class="r">${(sabzi&&String(sabzi).trim())||'Chef&#39;s choice'}</span></div>`);
      if(roti&&title!=='Breakfast') rows.push(`<div class="om-line"><span class="l">Roti</span><span class="r">${roti}</span></div>`);
      if(addons&&addons!=='None') rows.push(`<div class="om-line"><span class="l">Add-ons</span><span class="r">${addons}</span></div>`);
      if(time) rows.push(`<div class="om-line"><span class="l">Delivery time</span><span class="r">🕐 ${time}</span></div>`);
      return `<div class="om-meal"><div class="omm-head"><span>${emoji} ${title}</span><span class="omm-badge">× ${qty}</span></div>${rows.join('')}</div>`;
    };
    let body='';
    body+=mealBlock('🌅','Breakfast',o.breakfastQty,'',o.breakfastTiffin||'Breakfast','','',o.breakfastTimeSlot);
    body+=mealBlock('☀️','Lunch',o.lunchQty,o.lunchSabzi,o.lunchTiffin,o.lunchRoti,o.lunchAddons,o.lunchTimeSlot);
    body+=mealBlock('🌙','Dinner',o.dinnerQty,o.dinnerSabzi,o.dinnerTiffin,o.dinnerRoti,o.dinnerAddons,o.dinnerTimeSlot);
    if(o.note&&o.note!=='None') body+=`<div class="om-addr">📝 <b>Note:</b> ${esc(o.note)}</div>`;
    if(o.promo) body+=`<div class="om-addr" style="color:var(--ok);">🎟️ <b>${esc(o.promo)}</b></div>`;
    body+=`<div class="om-addr">${o.deliveryType==='office'?'🏢':'🏠'} <b>${esc(o.society)} ${esc(o.flat)}</b><br>📞 <a href="tel:+91${encodeURIComponent(o.phone)}">${esc(o.phone)}</a><br>🕐 Ordered: ${esc(o.time)}</div>`;
    body+=`<div class="om-total"><span class="t-lbl">💳 ${o.payment}${o.paymentStatus==='Paid'?(o.status==='Cancelled'?' · ⚠️ REFUND DUE':' · ✓ PAID'):''} · Total</span><span class="t-amt">${o.total}</span></div>`;
    if(o.status!=='Cancelled'){
      body+=`<div class="om-status-btns">
        <button class="sb-pend ${o.status==='Pending'?'act':''}" style="${o.status==='Pending'?'border-color:var(--warn);background:var(--warnbg);color:var(--warn);':''}" onclick="updateStatus(${o.row},'Pending');openOrderModal(${o.row})">🕒 Pending</button>
        <button class="sb-prep ${o.status==='Preparing'?'act':''}" style="${o.status==='Preparing'?'border-color:var(--accent);background:var(--accent-soft);color:var(--accent-dark);':''}" onclick="updateStatus(${o.row},'Preparing');openOrderModal(${o.row})">👨‍🍳 Preparing</button>
        <button class="sb-done ${o.status==='Delivered'?'act':''}" style="${o.status==='Delivered'?'border-color:var(--ok);background:var(--okbg);color:var(--ok);':''}" onclick="updateStatus(${o.row},'Delivered');openOrderModal(${o.row})">✅ Done</button>
      </div>`;
    }
    body+=`<div class="om-status-btns" style="margin-top:8px;">
      <button style="${o.paymentStatus==='Paid'?'border-color:var(--ok);background:var(--okbg);color:var(--ok);':''}" onclick="togglePaid(${o.row},'${o.paymentStatus||'Unpaid'}')">${o.paymentStatus==='Paid'?'✓ Paid — Mark Unpaid':'💳 Mark as Paid'}</button>
      <button onclick="waUpdate(${o.row})">📲 WhatsApp Update</button>
    </div>`;
    document.getElementById('omBody').innerHTML=body;
    document.getElementById('orderModal').classList.remove('hidden');
    document.body.style.overflow='hidden';
  }
  function closeOrderModal(){ document.getElementById('orderModal').classList.add('hidden'); document.body.style.overflow=''; }
  function togglePaid(row,cur){
    const nv=cur==='Paid'?'0':'1';
    apiPost({action:'setpaid',user:adminCreds.user,pass:adminCreds.pass,row:row,paid:nv}).then(j=>{
      if(j.status==='success'){ const o=adminOrders.find(x=>x.row===row); if(o)o.paymentStatus=j.paymentStatus; renderOrders(); openOrderModal(row); showToast('✅ '+(j.paymentStatus==='Paid'?'Marked as Paid':'Marked as Unpaid'),'success'); }
      else showToast('❌ '+(j.message||'Failed'),'error');
    }).catch(()=>showToast(t('errNetwork'),'error'));
  }
  function waUpdate(row){
    const o=adminOrders.find(x=>x.row===row); if(!o)return;
    const dt=fmtDateStr(o.deliveryDate);
    const msgs={Pending:'Your order for '+dt+' has been received. — Flying Birds Tiffin',Preparing:'Your order for '+dt+' is being prepared and will be delivered in your selected time slot. — Flying Birds Tiffin',Delivered:'Your order for '+dt+' has been delivered. Thank you for ordering with Flying Birds Tiffin!'};
    window.open('https://wa.me/91'+o.phone+'?text='+encodeURIComponent(msgs[o.status]||msgs.Pending),'_blank');
  }

  // ═══════ ADMIN ORDER ALERTS (poll + ringtone + notification) ═══════
  let alertTimer=null, ringCtx=null, ringTimer=null;
  function alertsOn(){ return !!storeGet('fbt_alerts_on'); }
  function updateAlertToggleUI(){ const b=document.getElementById('alertToggle'); if(!b)return; b.textContent=alertsOn()?'🔔 Alerts: ON':'🔕 Alerts: OFF'; b.classList.toggle('on',alertsOn()); }
  function startRing(){
    stopRing();
    try{
      ringCtx = ringCtx || new (window.AudioContext||window.webkitAudioContext)();
      if(ringCtx.resume) ringCtx.resume();
      const beep=(t,f)=>{ const o=ringCtx.createOscillator(), g=ringCtx.createGain(); o.type='square'; o.frequency.value=f; o.connect(g); g.connect(ringCtx.destination); g.gain.setValueAtTime(0.001,t); g.gain.exponentialRampToValueAtTime(0.6,t+0.02); g.gain.exponentialRampToValueAtTime(0.001,t+0.38); o.start(t); o.stop(t+0.42); };
      const cycle=()=>{ try{ const t=ringCtx.currentTime; beep(t,880); beep(t+0.5,880); beep(t+1.0,988); navigator.vibrate&&navigator.vibrate([350,150,350]); }catch(e){} };
      cycle(); ringTimer=setInterval(cycle,1800);
    }catch(e){}
  }
  function stopRing(){ if(ringTimer){ clearInterval(ringTimer); ringTimer=null; } }
  function toggleAlerts(){
    if(alertsOn()){ storeDel('fbt_alerts_on'); stopRing(); stopAlertPolling(); updateAlertToggleUI(); showToast('🔕 Order alerts OFF',''); return; }
    try{ if(window.Notification&&Notification.permission!=='granted') Notification.requestPermission(); }catch(e){}
    try{ ringCtx = ringCtx || new (window.AudioContext||window.webkitAudioContext)(); if(ringCtx.resume) ringCtx.resume(); }catch(e){}
    storeSet('fbt_alerts_on',1); updateAlertToggleUI();
    if(!adminCreds){ return; }
    fetch(`${GOOGLE_SCRIPT_URL}?action=lastorder&user=${encodeURIComponent(adminCreds.user)}&pass=${encodeURIComponent(adminCreds.pass)}`)
      .then(r=>r.json()).then(j=>{ if(j.status==='success') storeSet('fbt_lastrow', j.lastRow||0); })
      .catch(()=>{})
      .finally(()=>{ startAlertPolling(); showToast('🔔 Order alerts ON — keep this panel open','success'); });
  }
  function startAlertPolling(){ stopAlertPolling(); if(!alertsOn()||!adminCreds)return; alertTimer=setInterval(checkNewOrders,40000); }
  function stopAlertPolling(){ if(alertTimer){ clearInterval(alertTimer); alertTimer=null; } }
  function checkNewOrders(){
    if(!adminCreds||!alertsOn())return;
    fetch(`${GOOGLE_SCRIPT_URL}?action=lastorder&user=${encodeURIComponent(adminCreds.user)}&pass=${encodeURIComponent(adminCreds.pass)}`)
      .then(r=>r.json()).then(j=>{
        if(j.status!=='success')return;
        const prev=parseInt(storeGet('fbt_lastrow')||0,10)||0;
        if(j.lastRow>prev){ storeSet('fbt_lastrow',j.lastRow); showNewOrderAlert(j.latest||{}, j.lastRow-prev); }
      }).catch(()=>{});
  }
  function showNewOrderAlert(o,count){
    startRing();
    try{ if(window.Notification&&Notification.permission==='granted') new Notification('🆕 New Order — '+(o.total||''),{ body:(o.name||'')+' · '+(o.society||'')+' '+(o.flat||''), tag:'fbt-order' }); }catch(e){}
    const nm=document.getElementById('nobName'); if(nm)nm.textContent=o.name||'New order';
    const inf=document.getElementById('nobInfo'); if(inf)inf.textContent=((o.society||'')+' '+(o.flat||'')).trim()+(o.deliveryDate?(' · '+fmtDateStr(o.deliveryDate)):'')+(count>1?(' · +'+(count-1)+' more'):'');
    const tt=document.getElementById('nobTotal'); if(tt)tt.textContent=o.total||'';
    const b=document.getElementById('newOrderBanner'); if(b)b.classList.remove('hidden');
  }
  function dismissNewOrder(){ stopRing(); const b=document.getElementById('newOrderBanner'); if(b)b.classList.add('hidden'); setOrderDate(0); }
  function updateStatus(row,status){ const o=adminOrders.find(x=>x.row===row); if(!o||!adminCreds)return; const old=o.status; o.status=status; renderOrders(); renderKitchen();
    apiPost({action:'setStatus',user:adminCreds.user,pass:adminCreds.pass,row:row,phone:o.phone,status:status}).then(j=>{ if(j.status!=='success'){ o.status=old; renderOrders(); renderKitchen(); showToast('❌ '+(j.message||'Update failed'),'error'); } }).catch(()=>{ o.status=old; renderOrders(); renderKitchen(); showToast(t('errNetwork'),'error'); }); }

  function loadUsers(){ if(!adminCreds)return; document.getElementById('usersList').innerHTML='<div style="text-align:center;color:#999;padding:20px;">Loading...</div>';
    fetch(`${GOOGLE_SCRIPT_URL}?action=users&user=${encodeURIComponent(adminCreds.user)}&pass=${encodeURIComponent(adminCreds.pass)}`).then(r=>r.json()).then(j=>{ if(j.status!=='success'){ showToast('❌ '+(j.message||'Load failed'),'error'); return; } adminUsers=j.users||[]; renderUsers(); }).catch(()=>showToast(t('errNetwork'),'error')); }
  function renderUsers(){
    const q=(document.getElementById('userSearch').value||'').toLowerCase().trim();
    const list=adminUsers.filter(u=>!q||u.name.toLowerCase().includes(q)||u.phone.includes(q)||(u.email||'').toLowerCase().includes(q));
    document.getElementById('usersCount').textContent=list.length+' / '+adminUsers.length+' users'+(q?' (filtered)':'');
    const box=document.getElementById('usersList');
    if(!list.length){ box.innerHTML='<div style="text-align:center;color:#999;padding:20px;">No users found.</div>'; return; }
    box.innerHTML=list.map(u=>`<div class="oc"><div class="oc-top"><span>👤 ${esc(u.name)}</span><span class="oc-status st-${u.status}">${u.status}</span></div>
      <div class="oc-sub">📞 <a href="tel:+91${u.phone}">${u.phone}</a>${u.email?' · ✉️ '+u.email:''} · 🧾 ${u.orders} orders<br>Joined: ${u.created} · Last login: ${u.lastLogin}</div>
      <button class="block-btn ${u.status==='Blocked'?'un':''}" onclick="toggleUserBlock('${u.phone}','${u.status==='Blocked'?'Active':'Blocked'}')">${u.status==='Blocked'?'✅ Unblock':'🚫 Block'}</button></div>`).join('');
  }
  function toggleUserBlock(phone,ns){ if(!adminCreds)return; if(!confirm((ns==='Blocked'?'Block':'Unblock')+' '+phone+'?'))return;
    apiPost({action:'setUserStatus',user:adminCreds.user,pass:adminCreds.pass,phone:phone,status:ns}).then(j=>{ if(j.status==='success'){ const u=adminUsers.find(x=>x.phone===phone); if(u)u.status=ns; renderUsers(); showToast('✅ Updated.','success'); } else showToast('❌ '+(j.message||'Failed'),'error'); }).catch(()=>showToast(t('errNetwork'),'error')); }

  function loadStats(){ if(!adminCreds)return; fetch(`${GOOGLE_SCRIPT_URL}?action=stats&user=${encodeURIComponent(adminCreds.user)}&pass=${encodeURIComponent(adminCreds.pass)}`).then(r=>r.json()).then(j=>{ if(j.status==='success'){ fillStats(j); showToast('🔄 Refreshed.','success'); } }).catch(()=>showToast('❌ Refresh failed.','error')); }
  function fillStats(j){ document.getElementById('st-todayCount').textContent=j.today.count; document.getElementById('st-todayRev').textContent='₹'+j.today.revenue; document.getElementById('st-weekCount').textContent=j.week.count; document.getElementById('st-totalCount').textContent=j.total.count;
    const tb=document.querySelector('#recentTable tbody'); if(!j.recent||!j.recent.length){ tb.innerHTML='<tr><td colspan="6" style="text-align:center;color:#999;">No orders yet.</td></tr>'; return; }
    const stPill={Pending:'background:var(--warnbg);color:var(--warn);',Preparing:'background:var(--accent-soft);color:var(--accent-dark);',Delivered:'background:var(--okbg);color:var(--ok);'};
    tb.innerHTML=j.recent.map(o=>`<tr><td>${o.time}</td><td>${esc(o.name)}</td><td>${o.society?o.society.charAt(0)+'-':''}${esc(o.flat)}</td><td><b>${o.total}</b></td><td>${o.payment}</td><td><span class="ord-pill" style="${stPill[o.status]||''}">${o.status||''}</span></td></tr>`).join(''); }

  // Menu editor
  function initMenuEditor(){ adminMenuWorking=JSON.parse(JSON.stringify(MENU)); adminPrevDay=document.getElementById('adminDaySelect').value; loadEditorDay(adminPrevDay); }
  function loadEditorDay(day){ const d=adminMenuWorking[day]; document.getElementById('ed-breakfast').value=d.breakfast.join('\n'); document.getElementById('ed-lunchSabzi').value=d.lunch.sabziOptions.join('\n'); document.getElementById('ed-lunchFixed').value=d.lunch.fixedItems.join('\n'); document.getElementById('ed-dinnerSabzi').value=d.dinner.sabziOptions.join('\n'); document.getElementById('ed-dinnerFixed').value=d.dinner.fixedItems.join('\n'); }
  function readEditorInto(day){ const L=id=>document.getElementById(id).value.split('\n').map(s=>s.trim()).filter(Boolean); adminMenuWorking[day]={ breakfast:L('ed-breakfast'), lunch:{sabziOptions:L('ed-lunchSabzi'),fixedItems:L('ed-lunchFixed')}, dinner:{sabziOptions:L('ed-dinnerSabzi'),fixedItems:L('ed-dinnerFixed')} }; }
  function adminChangeDay(){ readEditorInto(adminPrevDay); adminPrevDay=document.getElementById('adminDaySelect').value; loadEditorDay(adminPrevDay); }
  function saveMenu(){ readEditorInto(adminPrevDay);
    for(const day of Object.keys(adminMenuWorking)){ const d=adminMenuWorking[day]; if(!d.breakfast.length||!d.lunch.sabziOptions.length||!d.lunch.fixedItems.length||!d.dinner.sabziOptions.length||!d.dinner.fixedItems.length){ showToast('⚠️ '+day+' menu incomplete.','warning'); return; } }
    const btn=document.getElementById('saveMenuBtn'); btn.textContent='⏳ Saving...'; btn.disabled=true;
    apiPost({action:'saveMenu',user:adminCreds.user,pass:adminCreds.pass,menu:adminMenuWorking}).then(j=>{ btn.textContent='💾 Save Menu'; btn.disabled=false; if(j.status==='success'){ MENU=JSON.parse(JSON.stringify(adminMenuWorking)); storeSet('fbt_menu',MENU); renderMealPanel(); showToast('✅ Menu saved!','success'); } else showToast('❌ '+(j.message||'Save failed'),'error'); }).catch(()=>{ btn.textContent='💾 Save Menu'; btn.disabled=false; showToast(t('errNetwork'),'error'); }); }

  // Config editor (prices + society + township + closed dates + capacity)
  const PRICE_LABELS={ breakfast:'🌅 Breakfast', lunch:'☀️ Lunch (Full Tiffin)', dinner:'🌙 Dinner (Full Tiffin)', tiffinMini:'🥗 Mini Tiffin (Lunch/Dinner)', extraRotiPlain:'Extra Roti (Plain)', extraRotiButter:'Extra Roti (Butter)', dahi:'Dahi / Curd', extraSabzi:'Extra Sabzi' };
  const CAPACITY_LABELS={ breakfast:'🌅 Breakfast', lunch:'☀️ Lunch', dinner:'🌙 Dinner' };
  let workingClosedDates=[];
  // ═══════ ADMIN: VARIANTS EDITOR ═══════
  let varDraft=null, varActiveMeal='lunch';
  function openVariantsEditor(){
    varDraft=JSON.parse(JSON.stringify(CFG.variants||defaultVariantsFE()));
    ['breakfast','lunch','dinner'].forEach(m=>{ if(!Array.isArray(varDraft[m]))varDraft[m]=defaultVariantsFE()[m]; });
    renderVariantsEditor();
  }
  function renderVariantsEditor(){
    const tabsBox=document.getElementById('varMealTabs'); if(!tabsBox)return;
    const meals=[['breakfast','🌅 Breakfast'],['lunch','☀️ Lunch'],['dinner','🌙 Dinner']];
    tabsBox.innerHTML=meals.map(([m,lbl])=>`<button class="${m===varActiveMeal?'on':''}" onclick="varSetMeal('${m}')">${lbl}</button>`).join('');
    const list=varDraft[varActiveMeal]||[];
    const box=document.getElementById('varList');
    box.innerHTML=list.map((v,i)=>{
      const img=v.img?`<img src="${v.img}" alt="">`:'🍱';
      return `<div class="var-card">
        <div class="vc-top">
          <div class="var-photo" onclick="pickVariantPhoto(${i})">${img}<div class="vp-edit">📷 Photo</div></div>
          <div class="var-fields">
            <input type="text" value="${(v.name||'').replace(/"/g,'&quot;')}" placeholder="Variant name (e.g. Full Thali)" oninput="varEdit(${i},'name',this.value)">
            <div class="var-row2">
              <input type="number" value="${v.price}" placeholder="Price ₹" oninput="varEdit(${i},'price',this.value)">
            </div>
            <textarea placeholder="Items (ek line me ek — e.g.&#10;Roti (5)&#10;Daal&#10;Chawal)" oninput="varEdit(${i},'itemsText',this.value)">${(v.items||[]).join('\n')}</textarea>
            <div class="var-up-status" id="varUp${i}"></div>
          </div>
        </div>
        <button class="var-del" onclick="delVariant(${i})">🗑️ Delete this variant</button>
      </div>`;
    }).join('') || `<p style="font-size:12px;color:var(--muted);text-align:center;padding:20px;">Koi variant nahi. "Add New Variant" dabao.</p>`;
  }
  function varSetMeal(m){ varActiveMeal=m; renderVariantsEditor(); }
  function varEdit(i,field,val){
    const v=varDraft[varActiveMeal][i]; if(!v)return;
    if(field==='name') v.name=val;
    else if(field==='price') v.price=parseInt(val,10)||0;
    else if(field==='itemsText') v.items=val.split('\n').map(s=>s.trim()).filter(Boolean);
    // don't re-render on every keystroke (keeps focus); price/name update in memory
  }
  function addVariant(){
    if(!varDraft)openVariantsEditor();
    const list=varDraft[varActiveMeal];
    if(list.length>=10){ showToast('⚠️ Max 10 variants per meal','warning'); return; }
    const id='v'+Date.now().toString(36);
    list.push({ id:id, name:'New Variant', price:0, items:[], img:'' });
    renderVariantsEditor();
  }
  function delVariant(i){
    const list=varDraft[varActiveMeal];
    if(list.length<=1){ showToast('⚠️ At least 1 variant is required','warning'); return; }
    if(!confirm('Delete this variant?'))return;
    list.splice(i,1); renderVariantsEditor();
  }
  const MAX_UPLOAD_MB=5, ALLOWED_IMG=['image/jpeg','image/png','image/webp'];
  function pickVariantPhoto(i){
    const inp=document.createElement('input');
    inp.type='file'; inp.accept='image/jpeg,image/png,image/webp';
    inp.onchange=()=>{
      const f=inp.files[0]; if(!f) return;
      // Type check — sirf standard image formats
      if(ALLOWED_IMG.indexOf(f.type)<0){ showToast('⚠️ Only JPG, PNG or WebP images are allowed.','warning'); return; }
      // Size check — max 5MB (bade file browser me hi crash kar sakte hain)
      const mb=f.size/(1024*1024);
      if(mb>MAX_UPLOAD_MB){ showToast('⚠️ Image is '+mb.toFixed(1)+'MB — please use one under '+MAX_UPLOAD_MB+'MB.','warning'); return; }
      compressAndUpload(f,i);
    };
    inp.click();
  }
  // Client-side compress → JPEG ~1MB se neeche guaranteed (performance ke liye).
  const TARGET_KB=900;   // stored image ka target: 900KB (1MB se safe neeche)
  function dataUrlKB(u){ return Math.round((u.length*3/4)/1024); }  // base64 → KB approx
  function compressAndUpload(file,i){
    const st=document.getElementById('varUp'+i); if(st)st.textContent='⏳ Compressing…';
    const reader=new FileReader();
    reader.onload=e=>{
      const img=new Image();
      img.onload=()=>{
        let max=1000;                       // start 1000px wide
        function encode(mx,q){
          let w=img.width,h=img.height;
          if(w>h && w>mx){ h=Math.round(h*mx/w); w=mx; }
          else if(h>mx){ w=Math.round(w*mx/h); h=mx; }
          const cv=document.createElement('canvas'); cv.width=w; cv.height=h;
          cv.getContext('2d').drawImage(img,0,0,w,h);
          return cv.toDataURL('image/jpeg',q);
        }
        // Pehle quality ghatao (0.8→0.5), phir zaroorat pade to dimension ghatao (1000→800→640)
        let dataUrl=encode(max,0.8);
        const dims=[1000,800,640], qs=[0.8,0.7,0.6,0.5];
        outer:
        for(const mx of dims){ for(const q of qs){ dataUrl=encode(mx,q); if(dataUrlKB(dataUrl)<=TARGET_KB) break outer; } }
        if(st)st.textContent='⏳ Uploading… ('+dataUrlKB(dataUrl)+'KB)';
        apiPost({ action:'uploadimage', user:adminCreds.user, pass:adminCreds.pass, dataUrl:dataUrl, name:varActiveMeal+'-'+i })
          .then(j=>{
            if(j.status==='success'){
              varDraft[varActiveMeal][i].img=j.url;
              IMG_OK[j.url]=true;
              if(st)st.textContent='✅ Uploaded';
              renderVariantsEditor();
            } else { if(st)st.textContent='❌ '+(j.message||'Upload failed'); }
          })
          .catch(()=>{ if(st)st.textContent='❌ Network error'; });
      };
      img.onerror=()=>{ if(st)st.textContent='❌ Invalid image'; };
      img.src=e.target.result;
    };
    reader.readAsDataURL(file);
  }
  function saveVariants(){
    if(!varDraft)return;
    const btn=document.getElementById('saveVarBtn'); const old=btn.textContent; btn.textContent='⏳ Saving…'; btn.disabled=true;
    apiPost({ action:'savevariants', user:adminCreds.user, pass:adminCreds.pass, variants:varDraft, banners:CFG.banners||{} })
      .then(j=>{
        btn.textContent=old; btn.disabled=false;
        if(j.status==='success'){
          CFG.variants=j.variants; storeSet('fbt_cfg',CFG); preloadImgs();
          showToast('✅ Variants saved!','success');
        } else { showToast('❌ '+(j.message||'Save failed'),'error'); }
      })
      .catch(()=>{ btn.textContent=old; btn.disabled=false; showToast(t('errNetwork'),'error'); });
  }

  function initConfigEditor(){
    document.getElementById('priceEditor').innerHTML=Object.keys(PRICE_LABELS).map(k=>`<div class="price-row"><label>${PRICE_LABELS[k]}</label><div class="inp">₹<input type="number" id="pr-${k}" value="${CFG.prices[k]}" min="0" max="2000"></div></div>`).join('');
    document.getElementById('cfg-township').value=CFG.township;
    document.getElementById('cfg-societies').value=CFG.societies.join('\n');
    const ce=document.getElementById('cfg-companies');
    if(ce) ce.value=(CFG.companies||[]).map(c=>[c.name,c.building||'',c.fee].join(' | ')).join('\n');
    const he=document.getElementById('cfg-homeEnabled'); if(he) he.checked=(CFG.homeEnabled!==false);
    const oe=document.getElementById('cfg-officeEnabled'); if(oe) oe.checked=(CFG.officeEnabled===true);
    const uid=document.getElementById('cfg-upiId'); if(uid)uid.value=CFG.upiId||'';
    const unm=document.getElementById('cfg-upiName'); if(unm)unm.value=CFG.upiName||'Flying Birds Tiffin';
    const ufs=document.getElementById('cfg-fssai'); if(ufs)ufs.value=CFG.fssai||'';
    document.getElementById('capacityEditor').innerHTML=Object.keys(CAPACITY_LABELS).map(k=>`<div class="price-row"><label>${CAPACITY_LABELS[k]}</label><div class="inp"><input type="number" id="cap-${k}" value="${(CFG.capacity&&CFG.capacity[k])||0}" min="0" max="500"></div></div>`).join('');
    workingClosedDates=(CFG.closedDates||[]).slice();
    renderClosedDatesList();
  }
  function renderClosedDatesList(){
    const box=document.getElementById('closedDatesList');
    if(!workingClosedDates.length){ box.innerHTML='<div style="font-size:12.5px;color:#999;">No closed dates set.</div>'; return; }
    box.innerHTML=workingClosedDates.slice().sort().map(d=>`<div class="oc" style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;margin-bottom:6px;"><span style="font-weight:800;">📅 ${fmtDateStr(d)}</span><span style="color:var(--danger);font-weight:800;cursor:pointer;" onclick="removeClosedDate('${d}')">✖ Remove</span></div>`).join('');
  }
  function addClosedDate(){
    const v=document.getElementById('closedDateInput').value;
    if(!v){ showToast('⚠️ Pick a date first.','warning'); return; }
    if(workingClosedDates.indexOf(v)>=0){ showToast('⚠️ Already added.','warning'); return; }
    workingClosedDates.push(v);
    document.getElementById('closedDateInput').value='';
    renderClosedDatesList();
  }
  function removeClosedDate(d){ workingClosedDates=workingClosedDates.filter(x=>x!==d); renderClosedDatesList(); }
  function saveConfig(){
    const prices={}; let bad=false;
    Object.keys(PRICE_LABELS).forEach(k=>{ const v=parseInt(document.getElementById('pr-'+k).value,10); if(isNaN(v)||v<0){bad=true;} prices[k]=v; });
    if(bad){ showToast('⚠️ Enter valid prices.','warning'); return; }
    const capacity={};
    Object.keys(CAPACITY_LABELS).forEach(k=>{ const v=parseInt(document.getElementById('cap-'+k).value,10); capacity[k]=isNaN(v)||v<0?0:v; });
    const township=document.getElementById('cfg-township').value.trim()||'Godrej Garden City';
    const societies=document.getElementById('cfg-societies').value.split('\n').map(s=>s.trim()).filter(Boolean);
    if(!societies.length){ showToast('⚠️ Add at least one society.','warning'); return; }
    // Companies: "Name | Building | Fee" per line
    const companies=(document.getElementById('cfg-companies')?document.getElementById('cfg-companies').value:'').split('\n').map(l=>l.trim()).filter(Boolean).map(l=>{
      const p=l.split('|').map(x=>x.trim());
      let fee=parseInt(p[2],10); if(isNaN(fee)||fee<0) fee=CFG.deliveryNear||10;
      return { name:p[0], building:p[1]||'', fee:fee };
    }).filter(c=>c.name);
    const homeEnabled=document.getElementById('cfg-homeEnabled')?document.getElementById('cfg-homeEnabled').checked:true;
    const officeEnabled=document.getElementById('cfg-officeEnabled')?document.getElementById('cfg-officeEnabled').checked:false;
    if(!homeEnabled&&!officeEnabled){ showToast('⚠️ Keep at least one delivery mode ON.','warning'); return; }
    if(officeEnabled&&!companies.length){ showToast('⚠️ Add at least one company for office delivery.','warning'); return; }
    const cfg={ prices, township, societies, deliveryNear:CFG.deliveryNear, deliveryFar:CFG.deliveryFar, farSocieties:CFG.farSocieties, closedDates:workingClosedDates, capacity:capacity, companies:companies, homeEnabled:homeEnabled, officeEnabled:officeEnabled, upiId:(document.getElementById('cfg-upiId')?document.getElementById('cfg-upiId').value.trim():CFG.upiId), upiName:(document.getElementById('cfg-upiName')?document.getElementById('cfg-upiName').value.trim():CFG.upiName), fssai:(document.getElementById('cfg-fssai')?document.getElementById('cfg-fssai').value.trim():CFG.fssai) };
    const btn=document.getElementById('saveConfigBtn'); btn.textContent='⏳ Saving...'; btn.disabled=true;
    apiPost({action:'saveConfig',user:adminCreds.user,pass:adminCreds.pass,config:cfg}).then(j=>{ btn.textContent='💾 Save Setup'; btn.disabled=false; if(j.status==='success'){ cfg.variants=CFG.variants; cfg.banners=CFG.banners; CFG=cfg; storeSet('fbt_cfg',CFG); applyConfigToUI(); refreshAvailability(); showToast('✅ Setup saved!','success'); } else showToast('❌ '+(j.message||'Save failed'),'error'); }).catch(()=>{ btn.textContent='💾 Save Setup'; btn.disabled=false; showToast(t('errNetwork'),'error'); }); }

  function applyConfigToUI(){
    const sel=document.getElementById('society'); const cur=sel.value;
    sel.innerHTML='<option value="">— '+t('society')+' —</option>'+CFG.societies.map(s=>`<option value="${s}">${s}</option>`).join('');
    if(cur && CFG.societies.includes(cur)) sel.value=cur;
    // Company dropdown + home/office toggle
    const cs=document.getElementById('company');
    if(cs){ const cc=cs.value;
      cs.innerHTML='<option value="">— '+t('companyLbl')+' —</option>'+(CFG.companies||[]).map(c=>`<option value="${c.name}">${c.name}${c.building?(' — '+c.building):''}</option>`).join('');
      if(cc) cs.value=cc;
    }
    const m=modesAvailable();
    const wrap=document.getElementById('dtypeWrap');
    if(wrap) wrap.classList.toggle('hidden', !(m.home&&m.office));
    if(!m.home && m.office) setDeliveryType('office');
    else if(m.home && !m.office) setDeliveryType('home');
    renderModeChip();
    const puOpt=document.getElementById('pay-UPI');
    if(puOpt){ const hasUpi=!!CFG.upiId; puOpt.classList.toggle('hidden',!hasUpi); if(!hasUpi&&payment==='UPI')setPay('COD'); }
    document.getElementById('township').value=CFG.township;
    document.querySelectorAll('.fssai-line').forEach(e=>{ e.textContent = CFG.fssai ? ('FSSAI Reg. No: '+CFG.fssai) : ''; });
  }

  // ═══════ INIT ═══════
  (function init(){
    const cl=storeGet('fbt_lang'); if(cl&&T[cl])LANG=cl;
    const cm=storeGet('fbt_menu'); if(cm&&cm.monday)MENU=cm;
    const cc=storeGet('fbt_cfg'); if(cc&&cc.prices)CFG=cc;

    initLangSelectors();
    preloadImgs();
    pickDefaultDate(); pickActiveMeal();
    applyConfigToUI();
    setLang(LANG);
    // Boot loader hatao — UI ready (network calls background me chalti rahengi)
    const __bl=document.getElementById('bootLoader');
    if(__bl){ __bl.classList.add('gone'); setTimeout(()=>__bl.remove(),400); }

    if(restoreAdmin()){
      // admin panel restore ho gaya — customer auth skip
    }
    else if(isLoggedIn()){
      enterApp(true);   // refresh ke baad wahi page wapas
      // Background session refresh — user ko sirf tab logout karo jab backend
      // PAKKA 'invalid_session' bole. Network error/timeout pe andar hi rehne do
      // (warna offline ya slow net pe logged-in user bewajah login page dekhega).
      if(GOOGLE_SCRIPT_URL.indexOf('http')===0){
        fetch(GOOGLE_SCRIPT_URL+'?action=me&token='+encodeURIComponent(SESSION.token))
          .then(r=>r.json())
          .then(j=>{
            if(j.status==='invalid_session'){ forceLogout(); }
            else if(j.status==='success'&&j.name){ SESSION.name=j.name; storeSet('fbt_session',SESSION); document.getElementById('profileName').textContent='👤 '+j.name; }
          })
          .catch(()=>{ /* network error — session localStorage me hai, andar rehne do */ });
      }
    }
    else showPublic();

    // ═══════ MOBILE BACK BUTTON ═══════
    // Pehle koi khula popup/drawer band karo; phir sub-page se home; home pe hi
    // ho to hi app se bahar jaane do.
    history.pushState({fbt:true}, '');
    window.addEventListener('popstate', function(){
      const sheet=document.getElementById('mealSheet');
      if(sheet && !sheet.classList.contains('hidden')){ closeMealSheet(); history.pushState({fbt:true},''); return; }
      const om=document.getElementById('orderModal');
      if(om && !om.classList.contains('hidden')){ closeOrderModal(); history.pushState({fbt:true},''); return; }
      const drawer=document.getElementById('drawer');
      if(drawer && drawer.classList.contains('open')){ closeDrawer(); history.pushState({fbt:true},''); return; }
      const onHome=!document.getElementById('homeView').classList.contains('hidden');
      const onAuth=!document.getElementById('authPage').classList.contains('hidden')||!document.getElementById('pubView').classList.contains('hidden');
      const onAdmin=!document.getElementById('adminPanel').classList.contains('hidden');
      // checkout/cart/orders/sub/about/adminPanel → back goes to home (or admin→app)
      if(onAdmin){ hideAdmin(); history.pushState({fbt:true},''); return; }
      const onAuthPage=!document.getElementById('authPage').classList.contains('hidden');
      if(onAuthPage && !isLoggedIn()){ showPublic(); history.pushState({fbt:true},''); return; }
      if(!onHome && !onAuth){ if(isLoggedIn())showLanding(); else showPublic(); history.pushState({fbt:true},''); return; }
      // on home/auth → allow the browser to actually go back (exit)
      history.back();
    });

    if(GOOGLE_SCRIPT_URL.indexOf('http')===0){
      fetch(GOOGLE_SCRIPT_URL+'?action=bootstrap').then(r=>r.json()).then(j=>{
        if(j.status==='success'){ if(j.menu&&j.menu.monday){ MENU=j.menu; storeSet('fbt_menu',MENU); } if(j.config&&j.config.prices){ CFG=j.config; CFG.promos=j.promos||[]; storeSet('fbt_cfg',CFG); applyConfigToUI(); preloadImgs(); } else if(j.promos){ CFG.promos=j.promos; storeSet('fbt_cfg',CFG); } const pg=document.getElementById('page1'); if(pg&&!pg.classList.contains('hidden')){ renderMenuDateTime&&renderMenuDateTime(); renderMealPanel(); } const hv=document.getElementById('homeView'); if(hv&&!hv.classList.contains('hidden')) renderHome(); if(!document.getElementById('cartView').classList.contains('hidden')) renderCart(); }
      }).catch(()=>{});
    }

    setInterval(()=>{ if(!document.getElementById('page1').classList.contains('hidden')) refreshAvailability(); },60000);
  })();
