/* Flying Birds Tiffin — Service Worker
   Install ke liye zaroori. Static assets cache karta hai (fast load + offline shell),
   par backend/API calls hamesha network se (fresh data). */

const CACHE = 'fbt-v6';
const ASSETS = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './manifest.json',
  './images/lunch.jpg',
  './images/dinner.jpg',
  './images/breakfast.svg',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

// Install — app shell cache karo
self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

// Activate — purane cache saaf karo
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch strategy:
//  - Google Apps Script / API / Google accounts  → hamesha network (kabhi cache nahi, warna stale data)
//  - baaki static assets                         → cache-first, background me update
self.addEventListener('fetch', (e) => {
  const url = e.request.url;

  // Kabhi cache mat karo: backend, google auth, QR generator, drive
  if (
    url.includes('script.google.com') ||
    url.includes('accounts.google.com') ||
    url.includes('googleusercontent') ||
    url.includes('api.qrserver.com') ||
    e.request.method !== 'GET'
  ) {
    return; // browser normal network se laayega
  }

  // Static: cache-first
  e.respondWith(
    caches.match(e.request).then((cached) => {
      const network = fetch(e.request).then((res) => {
        if (res && res.status === 200 && res.type === 'basic') {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(e.request, copy));
        }
        return res;
      }).catch(() => cached);
      return cached || network;
    })
  );
});
